/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.21-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: opendk_demo
-- ------------------------------------------------------
-- Server version	10.3.38-MariaDB-1:10.3.38+maria~ubu2004

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `albums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(191) NOT NULL,
  `gambar` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0=tidak aktif, 1=aktif',
  `slug` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `albums_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;

--
-- Table structure for table `das_akib`
--

DROP TABLE IF EXISTS `das_akib`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_akib` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `aki` int(11) NOT NULL COMMENT 'Anggka Kematian Ibu',
  `akb` int(11) NOT NULL COMMENT 'Angka Kematian Bayi',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_akib`
--

/*!40000 ALTER TABLE `das_akib` DISABLE KEYS */;
INSERT INTO `das_akib` VALUES (1,'53.06.13.2001',4,2025,4,32,NULL,NULL);
/*!40000 ALTER TABLE `das_akib` ENABLE KEYS */;

--
-- Table structure for table `das_anggaran_desa`
--

DROP TABLE IF EXISTS `das_anggaran_desa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_anggaran_desa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(15) NOT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `no_akun` varchar(10) NOT NULL,
  `nama_akun` varchar(255) NOT NULL,
  `jumlah` double(16,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_anggaran_desa`
--

/*!40000 ALTER TABLE `das_anggaran_desa` DISABLE KEYS */;
INSERT INTO `das_anggaran_desa` VALUES (1,'53.06.13.2001',4,2025,'412-01','Pengelolaan Tanah Kas Desa',2000000.00,NULL,NULL),(2,'53.06.13.2001',4,2025,'412-02','Tambatan Perahu',1500000.00,NULL,NULL),(3,'53.06.13.2001',4,2025,'412-03','Pasar Desa',500000.00,NULL,NULL),(4,'53.06.13.2001',4,2025,'412-04','Tempat Pemandian Umum',3900000.00,NULL,NULL),(5,'53.06.13.2001',4,2025,'412-05','Jaringan Irigasi Desa',235000.00,NULL,NULL);
/*!40000 ALTER TABLE `das_anggaran_desa` ENABLE KEYS */;

--
-- Table structure for table `das_anggaran_realisasi`
--

DROP TABLE IF EXISTS `das_anggaran_realisasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_anggaran_realisasi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profil_id` int(11) DEFAULT 1,
  `tahun` int(11) NOT NULL,
  `bulan` int(11) NOT NULL,
  `total_anggaran` double(16,2) NOT NULL,
  `total_belanja` double(16,2) NOT NULL,
  `belanja_pegawai` double(16,2) NOT NULL,
  `belanja_barang_jasa` double(16,2) NOT NULL,
  `belanja_modal` double(16,2) NOT NULL,
  `belanja_tidak_langsung` double(16,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_anggaran_realisasi`
--

/*!40000 ALTER TABLE `das_anggaran_realisasi` DISABLE KEYS */;
INSERT INTO `das_anggaran_realisasi` VALUES (1,1,2025,4,2500000000.00,2359257351.00,207625000.00,509258519.00,8982250.00,1633391582.00,'2025-04-23 08:02:13','2025-04-23 08:02:13'),(2,1,2025,4,2500000000.00,2557755861.00,143025000.00,730261765.00,24263235.00,1660205861.00,'2025-04-23 08:02:13','2025-04-23 08:02:13'),(3,1,2025,4,2500000000.00,2160740668.00,160625000.00,239100476.00,52087661.00,1708927531.00,'2025-04-23 08:02:13','2025-04-23 08:02:13');
/*!40000 ALTER TABLE `das_anggaran_realisasi` ENABLE KEYS */;

--
-- Table structure for table `das_apbdes`
--

DROP TABLE IF EXISTS `das_apbdes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_apbdes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `tahun` int(11) DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `nama_file` varchar(255) DEFAULT NULL,
  `id_apbdes` int(11) DEFAULT NULL,
  `desa_id` char(13) DEFAULT NULL,
  `imported_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_apbdes`
--

/*!40000 ALTER TABLE `das_apbdes` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_apbdes` ENABLE KEYS */;

--
-- Table structure for table `das_artikel`
--

DROP TABLE IF EXISTS `das_artikel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_artikel` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_kategori` bigint(20) unsigned DEFAULT NULL,
  `slug` varchar(191) NOT NULL,
  `judul` varchar(191) NOT NULL,
  `kategori_id` bigint(20) unsigned DEFAULT NULL,
  `gambar` varchar(191) DEFAULT NULL,
  `isi` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_artikel_slug_unique` (`slug`),
  KEY `das_artikel_id_kategori_foreign` (`id_kategori`),
  KEY `das_artikel_kategori_id_foreign` (`kategori_id`),
  CONSTRAINT `das_artikel_id_kategori_foreign` FOREIGN KEY (`id_kategori`) REFERENCES `das_artikel_kategori` (`id_kategori`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_artikel`
--

/*!40000 ALTER TABLE `das_artikel` DISABLE KEYS */;
INSERT INTO `das_artikel` VALUES (1,NULL,'consequatur-autem-nemo-doloribus-exercitationem','Consequatur autem nemo doloribus exercitationem.',NULL,'/img/no-image.png','Et repudiandae maiores dolorem officia sed et. Sit odit fugiat non fugiat. Nam non est eum non incidunt ut impedit. Consequatur inventore qui autem voluptatibus doloribus.',1,'2025-02-10 11:20:30','2025-03-11 05:09:21'),(2,NULL,'sapiente-amet-laboriosam-sapiente-repudiandae-assumenda-sed','Sapiente amet laboriosam sapiente repudiandae assumenda sed.',NULL,'/img/no-image.png','Sed aut tempore et corrupti voluptas in molestiae. At nihil dolor explicabo dolor iste dolorem. Delectus ut ipsum ut consequuntur sequi veniam excepturi.',1,'2025-01-07 02:56:16','2025-04-04 00:36:53'),(3,NULL,'sint-nostrum-aut-enim-voluptate-totam-aut-dolorem','Sint nostrum aut enim voluptate totam aut dolorem.',NULL,'/img/no-image.png','Harum consequuntur rerum aspernatur et voluptatibus nemo aliquam nihil. Possimus qui officia voluptatibus. Necessitatibus et recusandae ab necessitatibus occaecati. Dolores sed et nulla sunt omnis ex adipisci. Quisquam nesciunt ut sed esse fugiat et.',1,'2025-03-21 12:04:28','2025-01-06 16:55:59'),(4,NULL,'doloribus-unde-ut-voluptatem-doloribus','Doloribus unde ut voluptatem doloribus.',NULL,'/img/no-image.png','Itaque eaque beatae ut error nisi fuga iste. Sunt nesciunt qui id aut reprehenderit aut suscipit. Aut omnis id recusandae iure reprehenderit dolorem illo ut.',1,'2025-01-30 23:36:43','2025-02-23 01:14:21'),(5,NULL,'itaque-hic-iste-qui-similique-non','Itaque hic iste qui similique non.',NULL,'/img/no-image.png','Quia inventore molestiae eum non. Distinctio est blanditiis reprehenderit veritatis dolore rerum beatae. Molestiae commodi eos veritatis blanditiis similique. Qui voluptatem et natus veniam qui praesentium.',1,'2025-03-27 19:34:49','2025-04-03 03:10:13'),(6,NULL,'nulla-quas-omnis-non-quis-eum-quaerat','Nulla quas omnis non quis eum quaerat.',NULL,'/img/no-image.png','Non fuga facilis quia et praesentium. Minus voluptatem adipisci aspernatur mollitia. In et magnam deserunt voluptates eveniet.',1,'2025-04-09 00:33:56','2025-03-03 20:16:38'),(7,NULL,'quia-nemo-officiis-iure-voluptatem-iusto-neque','Quia nemo officiis iure voluptatem iusto neque.',NULL,'/img/no-image.png','Molestiae nihil nihil inventore amet cum voluptas dolores et. Delectus dolores aut omnis. Earum ratione incidunt et aut molestiae.',1,'2025-02-12 15:39:21','2025-01-16 17:01:14'),(8,NULL,'veritatis-ipsa-doloremque-deleniti-quisquam-libero','Veritatis ipsa doloremque deleniti quisquam libero.',NULL,'/img/no-image.png','Dolorem vitae placeat eos et perferendis aut minima beatae. Libero non ut in harum. Perferendis aut autem illum nesciunt asperiores voluptatem.',1,'2025-03-04 17:26:11','2025-01-21 03:53:41'),(9,NULL,'eveniet-nemo-praesentium-et-dolores-dolor-nemo','Eveniet nemo praesentium et dolores dolor nemo.',NULL,'/img/no-image.png','Modi ut voluptate eaque. Pariatur sed et vitae ex velit asperiores neque. Illo ut cum ipsa maiores aut. Quisquam voluptatem eum eligendi omnis distinctio voluptatem sed ut.',1,'2025-01-05 21:19:31','2025-01-27 15:47:27'),(10,NULL,'perspiciatis-nostrum-nihil-vitae-mollitia-ea','Perspiciatis nostrum nihil vitae mollitia ea.',NULL,'/img/no-image.png','Animi magnam asperiores est ut. Repellat quos assumenda mollitia quod voluptatem molestias neque perferendis. Doloremque autem dolorem ducimus omnis.',1,'2025-04-03 14:25:58','2025-04-08 13:00:44'),(11,NULL,'et-autem-labore-sit-est-et-voluptatum-necessitatibus','Et autem labore sit est et voluptatum necessitatibus.',NULL,'/img/no-image.png','Illum quo omnis nam. Iste alias sed harum provident nesciunt quam. Accusantium sed dolores ad ipsum qui dolorem. Omnis libero nam cupiditate sint non praesentium et.',1,'2025-02-09 08:45:55','2025-02-05 05:06:21'),(12,NULL,'ut-et-corrupti-et','Ut et corrupti et.',NULL,'/img/no-image.png','Esse saepe nihil nihil eos ea harum. Reiciendis esse non perferendis quia praesentium dolore vero. Eum sit sed aut natus sequi ea a. Vel aliquam ut rerum ut perferendis aut corrupti.',1,'2025-01-13 06:51:59','2025-03-13 00:38:27'),(13,NULL,'ut-voluptatibus-sunt-aut-illum-optio-voluptas-consequuntur-harum','Ut voluptatibus sunt aut illum optio voluptas consequuntur harum.',NULL,'/img/no-image.png','In rerum et dolor facere quae rem dignissimos. Et ducimus voluptatem minus voluptatem. Expedita nemo voluptates pariatur rerum quia quidem ut. Itaque magnam ut quia consequatur sunt quis earum.',1,'2025-04-02 22:20:58','2025-02-10 12:49:41'),(14,NULL,'inventore-vel-est-eum-rem','Inventore vel est eum rem.',NULL,'/img/no-image.png','Iure ex nulla voluptates occaecati quo voluptatem sint. Aspernatur reprehenderit reprehenderit rem fugiat aut. Et delectus dolor explicabo ab. Quia eius saepe at ducimus.',1,'2025-02-19 18:31:58','2025-01-03 03:25:01'),(15,NULL,'asperiores-et-voluptatem-quia-ducimus','Asperiores et voluptatem quia ducimus.',NULL,'/img/no-image.png','Voluptatum aut aut molestiae et dolores. Qui debitis voluptatem deserunt rerum sint et et quo. Iusto et blanditiis tenetur nisi consectetur adipisci quas.',1,'2025-04-14 14:49:52','2025-03-05 10:06:30'),(16,NULL,'officiis-pariatur-optio-nihil-voluptates-omnis','Officiis pariatur optio nihil voluptates omnis.',NULL,'/img/no-image.png','Praesentium provident placeat beatae aut. Aut dicta quisquam perspiciatis explicabo odit. Rem eum sunt omnis quia necessitatibus debitis. Deserunt id nisi voluptas.',1,'2025-02-24 05:37:37','2025-02-19 07:55:38'),(17,NULL,'facilis-ex-quidem-aliquam-rerum-deleniti-esse','Facilis ex quidem aliquam rerum deleniti esse.',NULL,'/img/no-image.png','Est ipsa doloribus sint quidem. Est dolores id error omnis. Magnam veniam facere expedita. Modi iste at nam.',1,'2025-02-18 15:23:00','2025-04-05 15:44:07'),(18,NULL,'id-quisquam-architecto-nam-quis-quibusdam','Id quisquam architecto nam quis quibusdam.',NULL,'/img/no-image.png','Repudiandae animi iste reprehenderit commodi libero qui. Repellat dolores aut et in deleniti harum. Facilis aliquam dolorum et harum molestias assumenda. Ut omnis sed consequatur sunt accusantium eum.',1,'2025-01-15 03:50:21','2025-02-12 15:27:34'),(19,NULL,'fugiat-et-earum-natus-recusandae-non','Fugiat et earum natus recusandae non.',NULL,'/img/no-image.png','Nam aut eligendi aut recusandae aut cupiditate temporibus. Mollitia quos ducimus accusantium. Minima et veniam minima porro natus consequatur id. Voluptas distinctio consectetur voluptatem eaque perspiciatis sunt.',1,'2025-01-08 18:03:10','2025-04-07 12:46:44'),(20,NULL,'ea-dolorem-eligendi-est','Ea dolorem eligendi est.',NULL,'/img/no-image.png','Eum ex odit maxime corrupti eos est. Excepturi at facilis consectetur in repellendus. Debitis expedita rerum eveniet molestiae. Nostrum rerum eius quod velit.',1,'2025-04-08 13:31:56','2025-03-10 21:08:53');
/*!40000 ALTER TABLE `das_artikel` ENABLE KEYS */;

--
-- Table structure for table `das_artikel_comment`
--

DROP TABLE IF EXISTS `das_artikel_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_artikel_comment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `das_artikel_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) DEFAULT NULL,
  `nama` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `body` text NOT NULL,
  `comment_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `device` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `das_artikel_comment_das_artikel_id_foreign` (`das_artikel_id`),
  KEY `das_artikel_comment_comment_id_foreign` (`comment_id`),
  CONSTRAINT `das_artikel_comment_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `das_artikel_comment` (`id`) ON DELETE CASCADE,
  CONSTRAINT `das_artikel_comment_das_artikel_id_foreign` FOREIGN KEY (`das_artikel_id`) REFERENCES `das_artikel` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_artikel_comment`
--

/*!40000 ALTER TABLE `das_artikel_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_artikel_comment` ENABLE KEYS */;

--
-- Table structure for table `das_artikel_kategori`
--

DROP TABLE IF EXISTS `das_artikel_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_artikel_kategori` (
  `id_kategori` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `status` enum('Ya','Tidak') NOT NULL DEFAULT 'Ya',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_kategori`),
  UNIQUE KEY `das_artikel_kategori_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_artikel_kategori`
--

/*!40000 ALTER TABLE `das_artikel_kategori` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_artikel_kategori` ENABLE KEYS */;

--
-- Table structure for table `das_counter_page`
--

DROP TABLE IF EXISTS `das_counter_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_counter_page` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_counter_page_page_unique` (`page`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_counter_page`
--

/*!40000 ALTER TABLE `das_counter_page` DISABLE KEYS */;
INSERT INTO `das_counter_page` VALUES (1,'beranda'),(4,'profil.letak-geografis'),(2,'profil.sejarah'),(5,'profil.struktur-pemerintahan'),(6,'profil.visi-misi'),(3,'publik.publikasi.album'),(7,'statistik.pendidikan'),(8,'unduhan.form-dokumen');
/*!40000 ALTER TABLE `das_counter_page` ENABLE KEYS */;

--
-- Table structure for table `das_counter_page_visitor`
--

DROP TABLE IF EXISTS `das_counter_page_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_counter_page_visitor` (
  `page_id` bigint(20) unsigned NOT NULL,
  `visitor_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  KEY `das_counter_page_visitor_page_id_index` (`page_id`),
  KEY `das_counter_page_visitor_visitor_id_index` (`visitor_id`),
  CONSTRAINT `das_counter_page_visitor_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `das_counter_page` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `das_counter_page_visitor_visitor_id_foreign` FOREIGN KEY (`visitor_id`) REFERENCES `das_counter_visitor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_counter_page_visitor`
--

/*!40000 ALTER TABLE `das_counter_page_visitor` DISABLE KEYS */;
INSERT INTO `das_counter_page_visitor` VALUES (1,1,'2025-04-23 08:26:00'),(2,1,'2025-04-23 08:22:18'),(3,1,'2025-04-23 08:05:25'),(4,1,'2025-04-23 08:22:02'),(5,1,'2025-04-23 08:22:22'),(6,1,'2025-04-23 08:22:27'),(7,1,'2025-04-23 08:22:46'),(8,1,'2025-04-23 08:22:56'),(1,2,'2025-04-23 08:30:56'),(1,3,'2025-04-23 08:31:24');
/*!40000 ALTER TABLE `das_counter_page_visitor` ENABLE KEYS */;

--
-- Table structure for table `das_counter_visitor`
--

DROP TABLE IF EXISTS `das_counter_visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_counter_visitor` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `visitor` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_counter_visitor_visitor_unique` (`visitor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_counter_visitor`
--

/*!40000 ALTER TABLE `das_counter_visitor` DISABLE KEYS */;
INSERT INTO `das_counter_visitor` VALUES (2,'34bf21a553a375414b7165dca9106c340247af576755e0f01ced89a7b2d6f916'),(1,'4c2b295351233e2dd99ec84dc954a36a010d63be723cc6e4abe80a213f48281c'),(3,'e634a1860de4c2f14960d51ccf0b78f143199fed7ff178393cfee1480d01c197');
/*!40000 ALTER TABLE `das_counter_visitor` ENABLE KEYS */;

--
-- Table structure for table `das_data_desa`
--

DROP TABLE IF EXISTS `das_data_desa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_data_desa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profil_id` int(11) DEFAULT 1,
  `desa_id` char(13) DEFAULT NULL,
  `nama` varchar(255) NOT NULL,
  `sebutan_desa` varchar(191) DEFAULT 'desa',
  `website` varchar(255) DEFAULT NULL,
  `path` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `luas_wilayah` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_data_desa`
--

/*!40000 ALTER TABLE `das_data_desa` DISABLE KEYS */;
INSERT INTO `das_data_desa` VALUES (1,1,'53.06.13.2001','Bedalewun','desa','https://bana.opendesa.id/',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(2,1,'53.06.13.2002','Lebanuba','desa','https://natairaya.com/',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(3,1,'53.06.13.2003','Rianwale','desa','https://bantal.desa.id/',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(4,1,'53.06.13.2004','Bungalawan','desa','https://berputar.opensid.or.id/',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(5,1,'53.06.13.2005','Lamawolo','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(6,1,'53.06.13.2006','Helanlangowuyo','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(7,1,'53.06.13.2007','Lewopao','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(8,1,'53.06.13.2008','Nelereren','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(9,1,'53.06.13.2009','Boleng','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(10,1,'53.06.13.2010','Neleblolong','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(11,1,'53.06.13.2011','Duablolong','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(12,1,'53.06.13.2012','Lewokeleng','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(13,1,'53.06.13.2013','Nelelamawangi','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(14,1,'53.06.13.2014','Harubala','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(15,1,'53.06.13.2015','Nelelamadike','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(16,1,'53.06.13.2016','Lamabayung','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(17,1,'53.06.13.2017','Lewat','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(18,1,'53.06.13.2018','Dokeng','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(19,1,'53.06.13.2019','Bayuntaa','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(20,1,'53.06.13.2020','Nobo','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12'),(21,1,'53.06.13.2021','Nelelamawangi Dua','desa','',NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12');
/*!40000 ALTER TABLE `das_data_desa` ENABLE KEYS */;

--
-- Table structure for table `das_data_umum`
--

DROP TABLE IF EXISTS `das_data_umum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_data_umum` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profil_id` int(11) DEFAULT NULL,
  `tipologi` longtext DEFAULT NULL,
  `sejarah` longtext DEFAULT NULL,
  `ketinggian` int(11) DEFAULT NULL,
  `sumber_luas_wilayah` int(10) unsigned NOT NULL DEFAULT 1 COMMENT '1:Input Manual,2:Dari Luas Desa',
  `luas_wilayah` double DEFAULT NULL,
  `bts_wil_utara` varchar(255) DEFAULT NULL,
  `bts_wil_timur` varchar(255) DEFAULT NULL,
  `bts_wil_selatan` varchar(255) DEFAULT NULL,
  `bts_wil_barat` varchar(255) DEFAULT NULL,
  `jml_puskesmas` int(11) DEFAULT NULL,
  `jml_puskesmas_pembantu` int(11) DEFAULT NULL,
  `jml_posyandu` int(11) DEFAULT NULL,
  `jml_pondok_bersalin` int(11) DEFAULT NULL,
  `jml_paud` int(11) DEFAULT NULL,
  `jml_sd` int(11) DEFAULT NULL,
  `jml_smp` int(11) DEFAULT NULL,
  `jml_sma` int(11) DEFAULT NULL,
  `jml_masjid_besar` int(11) DEFAULT NULL,
  `jml_mushola` int(11) DEFAULT NULL,
  `jml_gereja` int(11) DEFAULT NULL,
  `jml_pasar` int(11) DEFAULT NULL,
  `jml_balai_pertemuan` int(11) DEFAULT NULL,
  `embed_peta` longtext DEFAULT NULL,
  `path` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `lat` varchar(20) DEFAULT NULL,
  `lng` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_data_umum`
--

/*!40000 ALTER TABLE `das_data_umum` DISABLE KEYS */;
INSERT INTO `das_data_umum` VALUES (1,1,NULL,'Contoh sejarah kecamatan.',1,1,0,'Kecamatan A','Kecamatan B','Kecamatan C','Kecamatan D',0,0,0,0,0,0,0,0,0,1,0,0,0,'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127672.75772082225!2d100.61093321349074!3d-0.27103862950004254!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e2ab5bbf8396485%3A0x56587edf579fe503!2sLuak%2C+Kabupaten+Lima+Puluh+Kota%2C+Sumatera+Barat!5e0!3m2!1sid!2sid!4v1557908807791!5m2!1sid!2sid',NULL,NULL,NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12');
/*!40000 ALTER TABLE `das_data_umum` ENABLE KEYS */;

--
-- Table structure for table `das_epidemi_penyakit`
--

DROP TABLE IF EXISTS `das_epidemi_penyakit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_epidemi_penyakit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `penyakit_id` int(11) NOT NULL,
  `jumlah_penderita` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_epidemi_penyakit`
--

/*!40000 ALTER TABLE `das_epidemi_penyakit` DISABLE KEYS */;
INSERT INTO `das_epidemi_penyakit` VALUES (1,'53.06.13.2001',4,2025,1,34,NULL,NULL),(2,'53.06.13.2002',4,2025,1,44,NULL,NULL),(3,'53.06.13.2003',4,2025,1,12,NULL,NULL),(4,'53.06.13.2004',4,2025,1,3,NULL,NULL),(5,'53.06.13.2005',4,2025,1,67,NULL,NULL),(6,'53.06.13.2006',4,2025,1,3,NULL,NULL),(7,'53.06.13.2007',4,2025,1,3,NULL,NULL),(8,'53.06.13.2008',4,2025,1,3,NULL,NULL);
/*!40000 ALTER TABLE `das_epidemi_penyakit` ENABLE KEYS */;

--
-- Table structure for table `das_events`
--

DROP TABLE IF EXISTS `das_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `attendants` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `status` varchar(10) NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_events_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_events`
--

/*!40000 ALTER TABLE `das_events` DISABLE KEYS */;
INSERT INTO `das_events` VALUES (1,'Jana Cassin','jana-cassin','1989-02-05 10:32:16','1974-11-29 01:23:04','Camat','<p>Anabelle Treutel</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(2,'Casey Von','casey-von','1985-07-30 09:49:45','2006-01-10 14:07:58','Camat','<p>Johnson Bosco</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(3,'Zackary Simonis','zackary-simonis','2011-03-19 16:59:23','1981-08-25 11:05:20','Camat','<p>Lionel Ruecker</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(4,'Myrtice Murray','myrtice-murray','1975-09-05 17:31:34','1985-01-08 03:30:22','Camat','<p>Mrs. Kimberly Sauer</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(5,'Molly Grimes','molly-grimes','1996-02-16 14:13:18','1994-01-16 13:11:28','Camat','<p>Dr. Kamren Marks III</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(6,'Prof. Delta Oberbrunner','prof-delta-oberbrunner','1970-06-16 05:12:29','1976-11-01 17:27:17','Camat','<p>Jeffry Marquardt</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(7,'Dillan Volkman','dillan-volkman','1976-02-06 04:35:11','2007-07-25 21:16:42','Camat','<p>Betty Daugherty</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(8,'Gwen Spencer','gwen-spencer','2011-08-21 19:55:36','1980-03-07 15:48:30','Camat','<p>Adonis McLaughlin</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(9,'Novella Doyle PhD','novella-doyle-phd','1990-07-01 11:25:48','2022-03-15 15:05:04','Camat','<p>Tavares Carroll IV</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(10,'Harvey Schmeler','harvey-schmeler','1992-11-23 17:14:14','2007-01-29 20:37:48','Camat','<p>Trace Gibson</p>','OPEN',NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_events` ENABLE KEYS */;

--
-- Table structure for table `das_faq`
--

DROP TABLE IF EXISTS `das_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_faq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `answer` longtext NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_faq`
--

/*!40000 ALTER TABLE `das_faq` DISABLE KEYS */;
INSERT INTO `das_faq` VALUES (1,'Apa itu OpenDK?','<p>OpenDK [Dashboard Kecamatan Terbuka] adalah aplikasi yang bisa digunakan oleh Pemerintah Kecamatan di Seluruh Indonesia. Aplikasi ini sangat berguna untuk menampilkan statistik di wilayah Kecamatan, diantaranya adalah statistik Penduduk, statistik Kesehatan, Statistik Pendidikan dan Statistik lainnya. Upaya ini adalah sebagai bentuk transparansi dan Keterbukaan Informasi Publik yang dilakukan Pemerintah Kecamatan kepada seluruh rakyat di wilayahnya.</p>',1,'2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_faq` ENABLE KEYS */;

--
-- Table structure for table `das_fasilitas_paud`
--

DROP TABLE IF EXISTS `das_fasilitas_paud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_fasilitas_paud` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `semester` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `jumlah_paud` int(11) NOT NULL,
  `jumlah_guru_paud` int(11) NOT NULL,
  `jumlah_siswa_paud` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_fasilitas_paud`
--

/*!40000 ALTER TABLE `das_fasilitas_paud` DISABLE KEYS */;
INSERT INTO `das_fasilitas_paud` VALUES (1,'53.06.13.2001',1,2025,34,23,12,'2025-04-23 08:02:14','2025-04-23 08:02:14');
/*!40000 ALTER TABLE `das_fasilitas_paud` ENABLE KEYS */;

--
-- Table structure for table `das_form_dokumen`
--

DROP TABLE IF EXISTS `das_form_dokumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_form_dokumen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama_dokumen` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `file_dokumen` varchar(255) NOT NULL,
  `jenis_dokumen_id` int(10) unsigned DEFAULT NULL,
  `jenis_dokumen` varchar(191) DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT 1,
  `published_at` datetime DEFAULT NULL,
  `retention_days` int(11) DEFAULT 0,
  `expired_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `das_form_dokumen_jenis_dokumen_id_foreign` (`jenis_dokumen_id`),
  CONSTRAINT `das_form_dokumen_jenis_dokumen_id_foreign` FOREIGN KEY (`jenis_dokumen_id`) REFERENCES `das_jenis_dokumen` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_form_dokumen`
--

/*!40000 ALTER TABLE `das_form_dokumen` DISABLE KEYS */;
INSERT INTO `das_form_dokumen` VALUES (1,'Panduan OpenDK',NULL,'storage/template_upload/Panduan_Pengguna_Kecamatan_Dashboard.pdf',NULL,NULL,1,NULL,0,NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_form_dokumen` ENABLE KEYS */;

--
-- Table structure for table `das_imunisasi`
--

DROP TABLE IF EXISTS `das_imunisasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_imunisasi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `cakupan_imunisasi` int(11) NOT NULL COMMENT 'cakupan_imunisasi',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_imunisasi`
--

/*!40000 ALTER TABLE `das_imunisasi` DISABLE KEYS */;
INSERT INTO `das_imunisasi` VALUES (1,'53.06.13.2001',4,2025,34,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(2,'53.06.13.2002',4,2025,44,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(3,'53.06.13.2003',4,2025,12,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(4,'53.06.13.2004',4,2025,3,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(5,'53.06.13.2005',4,2025,67,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(6,'53.06.13.2006',4,2025,3,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(7,'53.06.13.2007',4,2025,3,'2025-04-23 08:02:14','2025-04-23 08:02:14'),(8,'53.06.13.2008',4,2025,3,'2025-04-23 08:02:14','2025-04-23 08:02:14');
/*!40000 ALTER TABLE `das_imunisasi` ENABLE KEYS */;

--
-- Table structure for table `das_jawab_komplain`
--

DROP TABLE IF EXISTS `das_jawab_komplain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_jawab_komplain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `komplain_id` int(11) NOT NULL,
  `penjawab` varchar(20) NOT NULL,
  `jawaban` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_jawab_komplain`
--

/*!40000 ALTER TABLE `das_jawab_komplain` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_jawab_komplain` ENABLE KEYS */;

--
-- Table structure for table `das_jenis_dokumen`
--

DROP TABLE IF EXISTS `das_jenis_dokumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_jenis_dokumen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_jenis_dokumen`
--

/*!40000 ALTER TABLE `das_jenis_dokumen` DISABLE KEYS */;
INSERT INTO `das_jenis_dokumen` VALUES (1,'Tersedia setiap saat','tersedia-setiap-saat','2025-04-23 08:02:06','2025-04-23 08:02:06'),(2,'Serta merta','serta-merta','2025-04-23 08:02:06','2025-04-23 08:02:06'),(3,'Secara Berkala','secara-berkala','2025-04-23 08:02:06','2025-04-23 08:02:06');
/*!40000 ALTER TABLE `das_jenis_dokumen` ENABLE KEYS */;

--
-- Table structure for table `das_kategori_komplain`
--

DROP TABLE IF EXISTS `das_kategori_komplain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_kategori_komplain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_kategori_komplain`
--

/*!40000 ALTER TABLE `das_kategori_komplain` DISABLE KEYS */;
INSERT INTO `das_kategori_komplain` VALUES (1,'infrastruktur-sanitasi-air','Infrastruktur (Sanitasi & Air)','2025-04-23 08:02:11','2025-04-23 08:02:11'),(3,'pendidikan','Pendidikan','2025-04-23 08:02:11','2025-04-23 08:02:11'),(4,'kesehatan','Kesehatan','2025-04-23 08:02:11','2025-04-23 08:02:11'),(5,'anggaran-desa','Anggaran Desa','2025-04-23 08:02:11','2025-04-23 08:02:11'),(6,'lainnya','Lainnya','2025-04-23 08:02:11','2025-04-23 08:02:11');
/*!40000 ALTER TABLE `das_kategori_komplain` ENABLE KEYS */;

--
-- Table structure for table `das_keluarga`
--

DROP TABLE IF EXISTS `das_keluarga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_keluarga` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profil_id` int(11) DEFAULT 1,
  `no_kk` varchar(16) DEFAULT NULL,
  `nik_kepala` varchar(16) DEFAULT NULL,
  `tgl_daftar` date DEFAULT NULL,
  `kelas_sosial` int(11) DEFAULT NULL,
  `tgl_cetak_kk` datetime DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `dusun` varchar(50) DEFAULT NULL,
  `rt` varchar(10) DEFAULT NULL,
  `rw` varchar(10) DEFAULT NULL,
  `id_cluster` int(11) DEFAULT NULL,
  `desa_id` char(13) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_keluarga`
--

/*!40000 ALTER TABLE `das_keluarga` DISABLE KEYS */;
INSERT INTO `das_keluarga` VALUES (1,1,'0','5201142003136994','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(2,1,'5201140104126994','5201142005716996','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'MANGSIT','004','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(3,1,'5201140104126995','5201141003666996','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(4,1,'5201140104166999','5201140107867064','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'KERANDANGAN','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(5,1,'5201140105136997','5201143112797117','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','003','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(6,1,'5201140106166996','5201145211486994','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(7,1,'5201140106167002','5201141210906998','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'KERANDANGAN','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(8,1,'5201140106167003','5201142911936995','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','003','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(9,1,'5201140107126996','5201140607636994','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(10,1,'5201140108146995','5201142210806997','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(11,1,'5201140109126996','5201143112707040','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'MANGSIT','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(12,1,'5201140109156994','5201141206886994','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'MANGSIT','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(13,1,'5201140110137011','5201143112897123','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(14,1,'5201140110137038','5201147112767266','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(15,1,'5201140110156997','5201145905936994','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','005','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(16,1,'5201140111126997','5201147112587053','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'KERANDANGAN','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(17,1,'5201140111126999','5201143112837098','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','003','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(18,1,'5201140112107003','5201140507916996','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'KERANDANGAN','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(19,1,'5201140112126998','5201143112677056','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(20,1,'5201140202167000','5201140107917031','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','004','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(21,1,'5201140202167002','5201141704876995','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','004','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(22,1,'5201140203136994','5201144112726996','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(23,1,'5201140203136995','5201143105926995','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','003','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(24,1,'5201140203167003','5201143112417056','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'SENGGIGI','004','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(25,1,'5201140204166994','5201145505946996','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(26,1,'5201140205156994','5201143112957094','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'MANGSIT','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(27,1,'5201140205156995','5201144209766995','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'MANGSIT','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(28,1,'5201140205156996','5201141607936996','2025-04-23',NULL,'2025-04-23 08:02:14',NULL,'LOCO','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:14','2025-04-23 08:02:14'),(29,1,'5201140205156997','5201141303906995','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'LOCO','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(30,1,'5201140206157000','5201143112667000','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'KERANDANGAN','001','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(31,1,'5201140206157004','5201140312896994','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'KERANDANGAN','004','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(32,1,'5201140207156998','5201141506856997','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'MANGSIT','003','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(33,1,'5201140207157000','5201145909946994','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'SENGGIGI','006','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(34,1,'5201140209156996','5201145003546994','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'KERANDANGAN','006','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(35,1,'5201140210137022','5201143112707180','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'SENGGIGI','006','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(36,1,'5201140211117001','5201143112617096','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'SENGGIGI','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(37,1,'5201140211117002','5201141707776994','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'SENGGIGI','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(38,1,'5201140211117003','5201141212816996','2025-04-23',NULL,'2025-04-23 08:02:15',NULL,'SENGGIGI','002','-',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15');
/*!40000 ALTER TABLE `das_keluarga` ENABLE KEYS */;

--
-- Table structure for table `das_komplain`
--

DROP TABLE IF EXISTS `das_komplain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_komplain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `komplain_id` int(11) NOT NULL,
  `kategori` varchar(200) NOT NULL,
  `nik` char(16) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `detail_penduduk` text DEFAULT NULL,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `laporan` text NOT NULL,
  `status` varchar(15) NOT NULL,
  `dilihat` int(11) NOT NULL,
  `lampiran1` varchar(255) DEFAULT NULL,
  `lampiran2` varchar(255) DEFAULT NULL,
  `lampiran3` varchar(255) DEFAULT NULL,
  `lampiran4` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `anonim` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_komplain`
--

/*!40000 ALTER TABLE `das_komplain` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_komplain` ENABLE KEYS */;

--
-- Table structure for table `das_laporan_penduduk`
--

DROP TABLE IF EXISTS `das_laporan_penduduk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_laporan_penduduk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `id_laporan_penduduk` int(11) NOT NULL,
  `desa_id` char(13) NOT NULL,
  `imported_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_laporan_penduduk`
--

/*!40000 ALTER TABLE `das_laporan_penduduk` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_laporan_penduduk` ENABLE KEYS */;

--
-- Table structure for table `das_lembaga`
--

DROP TABLE IF EXISTS `das_lembaga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_lembaga` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lembaga_kategori_id` bigint(20) unsigned NOT NULL,
  `penduduk_id` int(10) unsigned DEFAULT NULL,
  `nama` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `kode` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_lembaga_slug_unique` (`slug`),
  UNIQUE KEY `das_lembaga_kode_unique` (`kode`),
  KEY `das_lembaga_lembaga_kategori_id_foreign` (`lembaga_kategori_id`),
  CONSTRAINT `das_lembaga_lembaga_kategori_id_foreign` FOREIGN KEY (`lembaga_kategori_id`) REFERENCES `das_lembaga_kategori` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_lembaga`
--

/*!40000 ALTER TABLE `das_lembaga` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_lembaga` ENABLE KEYS */;

--
-- Table structure for table `das_lembaga_anggota`
--

DROP TABLE IF EXISTS `das_lembaga_anggota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_lembaga_anggota` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lembaga_id` bigint(20) unsigned NOT NULL,
  `penduduk_id` int(10) unsigned NOT NULL,
  `no_anggota` varchar(191) DEFAULT NULL,
  `jabatan` varchar(191) DEFAULT NULL,
  `no_sk_jabatan` varchar(191) DEFAULT NULL,
  `periode` varchar(191) DEFAULT NULL,
  `no_sk_pengangkatan` varchar(191) DEFAULT NULL,
  `tgl_sk_pengangkatan` date DEFAULT NULL,
  `no_sk_pemberhentian` varchar(191) DEFAULT NULL,
  `tgl_sk_pemberhentian` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `das_lembaga_anggota_lembaga_id_foreign` (`lembaga_id`),
  KEY `das_lembaga_anggota_penduduk_id_foreign` (`penduduk_id`),
  CONSTRAINT `das_lembaga_anggota_lembaga_id_foreign` FOREIGN KEY (`lembaga_id`) REFERENCES `das_lembaga` (`id`) ON DELETE CASCADE,
  CONSTRAINT `das_lembaga_anggota_penduduk_id_foreign` FOREIGN KEY (`penduduk_id`) REFERENCES `das_penduduk` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_lembaga_anggota`
--

/*!40000 ALTER TABLE `das_lembaga_anggota` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_lembaga_anggota` ENABLE KEYS */;

--
-- Table structure for table `das_lembaga_kategori`
--

DROP TABLE IF EXISTS `das_lembaga_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_lembaga_kategori` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(191) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_lembaga_kategori`
--

/*!40000 ALTER TABLE `das_lembaga_kategori` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_lembaga_kategori` ENABLE KEYS */;

--
-- Table structure for table `das_log_surat`
--

DROP TABLE IF EXISTS `das_log_surat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_log_surat` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `nik` char(16) NOT NULL,
  `pengurus_id` int(10) unsigned NOT NULL,
  `tanggal` date NOT NULL,
  `nomor` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `file` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `log_verifikasi` tinyint(4) NOT NULL DEFAULT 1,
  `verifikasi_operator` tinyint(4) NOT NULL DEFAULT 2,
  `verifikasi_sekretaris` tinyint(4) NOT NULL DEFAULT 1,
  `verifikasi_camat` tinyint(4) NOT NULL DEFAULT 2,
  `status_tte` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_log_surat_nomor_unique` (`nomor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_log_surat`
--

/*!40000 ALTER TABLE `das_log_surat` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_log_surat` ENABLE KEYS */;

--
-- Table structure for table `das_log_tte`
--

DROP TABLE IF EXISTS `das_log_tte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_log_tte` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pesan_error` text NOT NULL,
  `jenis` varchar(150) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_log_tte`
--

/*!40000 ALTER TABLE `das_log_tte` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_log_tte` ENABLE KEYS */;

--
-- Table structure for table `das_media_sosial`
--

DROP TABLE IF EXISTS `das_media_sosial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_media_sosial` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `nama` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_media_sosial`
--

/*!40000 ALTER TABLE `das_media_sosial` DISABLE KEYS */;
INSERT INTO `das_media_sosial` VALUES (1,'/img/fb.png','https://www.facebook.com/groups/OpenDK/','Grup Facebook',1,'2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_media_sosial` ENABLE KEYS */;

--
-- Table structure for table `das_menu`
--

DROP TABLE IF EXISTS `das_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `url` varchar(191) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_menu`
--

/*!40000 ALTER TABLE `das_menu` DISABLE KEYS */;
INSERT INTO `das_menu` VALUES (1,'0','Data','data','fa-book','data',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(2,'1','Kecamatan','data-kecamatan','fa-book','data/kecamatan',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(3,'1','Penduduk','data-penduduk','fa-book','data/penduduk',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(4,'1','Kesehatan','data-kesehatan','fa-book','data/kesehatan',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(5,'1','Pendidikan','data-pendidikan','fa-book','data/pendidikan',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(6,'1','Program Bantuan','data-programbantuan','fa-book','data/program-bantuan',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(7,'1','Anggaran & Realisasi','data-anggaranrealisasi','fa-book','data/anggaran-realisasi',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(8,'1','Anggaran Desa','data-anggarandesa','fa-book','data/anggaran-desa',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(9,'1','Layanan Kecamatan','data-layanan','fa-book','data/layanan',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(10,'0','Admin Keluhan','adminsikoma','fa-book','admin-komplain',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(11,'0','Pengaturan','setting','fa-book','settings',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(12,'11','Kategori Komplain','setting-kategorikomplain','fa-book','setting/kategori-komplain',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(13,'11','Tipe Regulasi','setting-tiperegulasi','fa-book','setting/tipe-regulasi',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(14,'11','Jenis Penyakit','setting-jenispenyakit','fa-book','setting/jenis-penyakit',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(15,'11','COA','setting-coa','fa-book','setting/coa',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(16,'11','Grup Pengguna','setting-gruppengguna','fa-book','setting/role',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(17,'11','Pengguna','setting-pengguna','fa-book','setting/user',1,'2025-04-23 08:02:11','2025-04-23 08:02:11'),(18,'11','Halaman Beranda','setting-dashboard','fa-book','setting/user',1,'2025-04-23 08:02:11','2025-04-23 08:02:11');
/*!40000 ALTER TABLE `das_menu` ENABLE KEYS */;

--
-- Table structure for table `das_navigation`
--

DROP TABLE IF EXISTS `das_navigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_navigation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `nav_type` enum('system','external') DEFAULT NULL,
  `url` varchar(191) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `type` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_navigation_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_navigation`
--

/*!40000 ALTER TABLE `das_navigation` DISABLE KEYS */;
INSERT INTO `das_navigation` VALUES (22,NULL,'Beranda','beranda',NULL,'http://localhost:8000',1,1,0,NULL,NULL),(23,NULL,'Berita Desa','berita-desa',NULL,'http://localhost:8000/berita-desa',2,1,0,NULL,NULL),(24,NULL,'Profil','profil',NULL,'#',3,1,0,NULL,NULL),(25,NULL,'Desa','desa',NULL,'#',4,1,0,NULL,NULL),(26,NULL,'Potensi','potensi',NULL,'#',5,1,0,NULL,NULL),(27,NULL,'Statistik','statistik',NULL,'#',6,1,0,NULL,NULL),(28,NULL,'Unduhan','unduhan',NULL,'#',7,1,0,NULL,NULL),(29,NULL,'FAQ','faq',NULL,'http://localhost:8000/faq',8,1,0,NULL,NULL),(30,24,'Sejarah','profil-sejarah',NULL,'profil/sejarah',1,1,1,NULL,NULL),(31,24,'Letak Geografis','profil-letak-geografis',NULL,'profil/letak-geografis',2,1,1,NULL,NULL),(32,24,'Struktur Pemerintahan','profil-struktur-pemerintahan',NULL,'profil/struktur-pemerintahan',3,1,1,NULL,NULL),(33,24,'Visi & Misi','profil-visi-misi',NULL,'profil/visi-misi',4,1,1,NULL,NULL),(34,27,'Penduduk','statistik-penduduk',NULL,'statistik/kependudukan',1,1,3,NULL,NULL),(35,27,'Pendidikan','statistik-pendidikan',NULL,'statistik/pendidikan',2,1,3,NULL,NULL),(36,27,'Kesehatan','statistik-kesehatan',NULL,'statistik/kesehatan',3,1,3,NULL,NULL),(37,27,'Program dan Bantuan','statistik-program-dan-bantuan',NULL,'statistik/program-dan-bantuan',4,1,3,NULL,NULL),(38,27,'Anggaran dan Realisasi','statistik-anggaran-dan-realisasi',NULL,'statistik/anggaran-dan-realisasi',5,1,3,NULL,NULL),(39,27,'Anggaran Desa','statistik-anggaran-desa',NULL,'statistik/anggaran-desa',6,1,3,NULL,NULL),(40,28,'Prosedur','unduhan-prosedur',NULL,'unduhan/prosedur',1,1,5,NULL,NULL),(41,28,'Regulasi','unduhan-regulasi',NULL,'unduhan/regulasi',2,1,5,NULL,NULL),(42,28,'Dokumen','unduhan-dokumen',NULL,'unduhan/form-dokumen',3,1,5,NULL,NULL),(43,25,'Desa Bedalewun','desa-bedalewun',NULL,'desa/desa-bedalewun',1,1,2,NULL,NULL),(44,25,'Desa Lebanuba','desa-lebanuba',NULL,'desa/desa-lebanuba',2,1,2,NULL,NULL),(45,25,'Desa Rianwale','desa-rianwale',NULL,'desa/desa-rianwale',3,1,2,NULL,NULL),(46,25,'Desa Bungalawan','desa-bungalawan',NULL,'desa/desa-bungalawan',4,1,2,NULL,NULL),(47,25,'Desa Lamawolo','desa-lamawolo',NULL,'desa/desa-lamawolo',5,1,2,NULL,NULL),(48,25,'Desa Helanlangowuyo','desa-helanlangowuyo',NULL,'desa/desa-helanlangowuyo',6,1,2,NULL,NULL),(49,25,'Desa Lewopao','desa-lewopao',NULL,'desa/desa-lewopao',7,1,2,NULL,NULL),(50,25,'Desa Nelereren','desa-nelereren',NULL,'desa/desa-nelereren',8,1,2,NULL,NULL),(51,25,'Desa Boleng','desa-boleng',NULL,'desa/desa-boleng',9,1,2,NULL,NULL),(52,25,'Desa Neleblolong','desa-neleblolong',NULL,'desa/desa-neleblolong',10,1,2,NULL,NULL),(53,25,'Desa Duablolong','desa-duablolong',NULL,'desa/desa-duablolong',11,1,2,NULL,NULL),(54,25,'Desa Lewokeleng','desa-lewokeleng',NULL,'desa/desa-lewokeleng',12,1,2,NULL,NULL),(55,25,'Desa Nelelamawangi','desa-nelelamawangi',NULL,'desa/desa-nelelamawangi',13,1,2,NULL,NULL),(56,25,'Desa Harubala','desa-harubala',NULL,'desa/desa-harubala',14,1,2,NULL,NULL),(57,25,'Desa Nelelamadike','desa-nelelamadike',NULL,'desa/desa-nelelamadike',15,1,2,NULL,NULL),(58,25,'Desa Lamabayung','desa-lamabayung',NULL,'desa/desa-lamabayung',16,1,2,NULL,NULL),(59,25,'Desa Lewat','desa-lewat',NULL,'desa/desa-lewat',17,1,2,NULL,NULL),(60,25,'Desa Dokeng','desa-dokeng',NULL,'desa/desa-dokeng',18,1,2,NULL,NULL),(61,25,'Desa Bayuntaa','desa-bayuntaa',NULL,'desa/desa-bayuntaa',19,1,2,NULL,NULL),(62,25,'Desa Nobo','desa-nobo',NULL,'desa/desa-nobo',20,1,2,NULL,NULL),(63,25,'Desa Nelelamawangi Dua','desa-nelelamawangi-dua',NULL,'desa/desa-nelelamawangi-dua',21,1,2,NULL,NULL),(64,26,'Kategori 1','potensi-kategori-1',NULL,'potensi/kategori-1',1,1,4,NULL,NULL),(65,26,'Kategori 2','potensi-kategori-2',NULL,'potensi/kategori-2',2,1,4,NULL,NULL);
/*!40000 ALTER TABLE `das_navigation` ENABLE KEYS */;

--
-- Table structure for table `das_pembangunan`
--

DROP TABLE IF EXISTS `das_pembangunan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_pembangunan` (
  `id` int(11) NOT NULL,
  `desa_id` char(13) NOT NULL,
  `lokasi` varchar(255) DEFAULT NULL,
  `sumber_dana` varchar(255) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `volume` varchar(255) DEFAULT NULL,
  `tahun_anggaran` year(4) DEFAULT NULL,
  `pelaksana_kegiatan` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `anggaran` double(65,2) DEFAULT NULL,
  `perubahan_anggaran` double(65,2) DEFAULT NULL,
  `sumber_biaya_pemerintah` double(65,2) DEFAULT NULL,
  `sumber_biaya_provinsi` double(65,2) DEFAULT NULL,
  `sumber_biaya_kab_kota` double(65,2) DEFAULT NULL,
  `sumber_biaya_swadaya` double(65,2) DEFAULT NULL,
  `sumber_biaya_jumlah` double(65,2) DEFAULT NULL,
  `manfaat` varchar(100) DEFAULT NULL,
  `waktu` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `das_pembangunan_id_desa_id_unique` (`id`,`desa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_pembangunan`
--

/*!40000 ALTER TABLE `das_pembangunan` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_pembangunan` ENABLE KEYS */;

--
-- Table structure for table `das_pembangunan_dokumentasi`
--

DROP TABLE IF EXISTS `das_pembangunan_dokumentasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_pembangunan_dokumentasi` (
  `id` int(11) NOT NULL,
  `id_pembangunan` int(11) NOT NULL,
  `desa_id` char(13) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `persentase` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `das_pembangunan_dokumentasi_id_desa_id_id_pembangunan_unique` (`id`,`desa_id`,`id_pembangunan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_pembangunan_dokumentasi`
--

/*!40000 ALTER TABLE `das_pembangunan_dokumentasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_pembangunan_dokumentasi` ENABLE KEYS */;

--
-- Table structure for table `das_penduduk`
--

DROP TABLE IF EXISTS `das_penduduk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_penduduk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `nik` char(16) NOT NULL,
  `id_kk` int(11) DEFAULT NULL,
  `kk_level` tinyint(4) DEFAULT NULL,
  `id_rtm` varchar(30) DEFAULT NULL,
  `rtm_level` int(11) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `agama_id` int(11) DEFAULT NULL,
  `pendidikan_kk_id` int(11) DEFAULT NULL,
  `pendidikan_id` int(11) DEFAULT NULL,
  `pendidikan_sedang_id` int(11) DEFAULT NULL,
  `pekerjaan_id` int(11) DEFAULT NULL,
  `status_kawin` tinyint(4) DEFAULT NULL,
  `warga_negara_id` int(11) DEFAULT NULL,
  `dokumen_pasport` varchar(45) DEFAULT NULL,
  `dokumen_kitas` varchar(45) DEFAULT NULL,
  `ayah_nik` varchar(16) DEFAULT NULL,
  `ibu_nik` varchar(16) DEFAULT NULL,
  `nama_ayah` varchar(100) DEFAULT NULL,
  `nama_ibu` varchar(100) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `golongan_darah_id` int(11) DEFAULT NULL,
  `id_cluster` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `alamat_sebelumnya` varchar(255) DEFAULT NULL,
  `alamat_sekarang` varchar(255) DEFAULT NULL,
  `status_dasar` tinyint(4) NOT NULL,
  `hamil` int(11) DEFAULT NULL,
  `cacat_id` int(11) DEFAULT NULL,
  `sakit_menahun_id` int(11) DEFAULT NULL,
  `akta_lahir` varchar(40) DEFAULT NULL,
  `akta_perkawinan` varchar(40) DEFAULT NULL,
  `tanggal_perkawinan` date DEFAULT NULL,
  `akta_perceraian` varchar(40) DEFAULT NULL,
  `tanggal_perceraian` date DEFAULT NULL,
  `cara_kb_id` tinyint(4) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `tanggal_akhir_pasport` date DEFAULT NULL,
  `no_kk` varchar(30) DEFAULT NULL,
  `no_kk_sebelumnya` varchar(30) DEFAULT NULL,
  `ktp_el` tinyint(4) DEFAULT NULL,
  `status_rekam` tinyint(4) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `dusun` varchar(255) DEFAULT NULL,
  `rw` varchar(10) DEFAULT NULL,
  `rt` varchar(10) DEFAULT NULL,
  `desa_id` char(13) DEFAULT NULL,
  `tahun` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `id_pend_desa` int(11) DEFAULT NULL,
  `imported_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_penduduk`
--

/*!40000 ALTER TABLE `das_penduduk` DISABLE KEYS */;
INSERT INTO `das_penduduk` VALUES (1,'SITI PAOZIAH','5201146312161724',NULL,3,NULL,NULL,2,'SENGGIGI','2006-12-23',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'SYARIFUL KALAM','SITI AISYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2020-12-22 12:04:20',NULL,'2025-04-23 08:02:14'),(2,'WAYAN EKA PRAWATA','5201142003136994',NULL,1,NULL,NULL,1,'GUNUNG SARI','2012-03-20',1,1,NULL,18,1,2,1,NULL,NULL,NULL,NULL,'WAHID ALIAS H. MAHSUN','ULFA WIDIAWATI','5201142003136994-96.jpg',13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2020-12-22 17:12:01',NULL,'2025-04-23 08:02:14'),(3,'AHLUL','5201142005716996',NULL,1,NULL,NULL,1,'MANGSIT','1970-05-20',1,3,NULL,18,26,2,1,NULL,NULL,NULL,NULL,'ARFAH','RAISAH',NULL,13,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126994',NULL,NULL,NULL,NULL,'MANGSIT','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2020-12-22 12:13:25',NULL,'2025-04-23 08:02:14'),(4,'AHMAD HABIB','5201140301916995',NULL,4,NULL,NULL,1,'MANGSIT','1990-01-03',1,3,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'AHLUL','RUSDAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126994',NULL,NULL,NULL,NULL,'MANGSIT','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2020-07-30 11:36:12',NULL,'2025-04-23 08:02:14'),(5,'AHMAD ALLIF RIZKI','5201140706966997',NULL,4,NULL,NULL,1,'MANGSIT','1995-06-07',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'AHLUL','RUSDAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126994',NULL,NULL,NULL,NULL,'MANGSIT','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(6,'ADINI SEPTIA LISTA','5201145003976995',NULL,4,NULL,NULL,2,'MANGSIT','1996-03-10',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'AHLUL','RUSDAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126994',NULL,NULL,NULL,NULL,'MANGSIT','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(7,'AHYAR','5201141003666996',NULL,1,NULL,NULL,1,'JAKARTA','1965-03-10',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'PAIMUN','SUPINAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126995',NULL,NULL,NULL,NULL,'SENGGIGI','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(8,'ALIYAH','5201144609786995',NULL,3,NULL,NULL,2,'BEKASI','1977-09-06',1,5,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'TAGOR SIPAHUTAR','AMAHWATI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126995',NULL,NULL,NULL,NULL,'SENGGIGI','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(9,'APTA MADA RIZKY ALAMSYAH','5201141412121724',NULL,4,NULL,NULL,1,'DEPOK','2002-12-14',1,2,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'AHYAR','ALIYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126995',NULL,NULL,NULL,NULL,'SENGGIGI','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(10,'ALPIANI','5201144301171725',NULL,4,NULL,NULL,2,'BOGOR','2007-01-03',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'AHYAR','ALIYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104126995',NULL,NULL,NULL,NULL,'SENGGIGI','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(11,'BACHTIAR HADI','5201142210181724',NULL,4,NULL,NULL,1,'MATARAM','2008-10-22',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'ASHARI','ANGGUN LESTARI PRATAMA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104166999',NULL,NULL,NULL,NULL,'KERANDANGAN','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(12,'ASHARI','5201140107867064',NULL,1,NULL,NULL,1,'KERANDANGAN','1985-12-30',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'H. ABDUL KARIM','RADIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104166999',NULL,NULL,NULL,NULL,'KERANDANGAN','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2020-07-30 11:36:52',NULL,'2025-04-23 08:02:14'),(13,'ANGGUN LESTARI PRATAMA','5201146510916995',NULL,3,NULL,NULL,2,'SENGGIGI','1990-10-25',1,4,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'SADIRAH','HJ. ROHANI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140104166999',NULL,NULL,NULL,NULL,'KERANDANGAN','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(14,'DAHRI','5201143112797117',NULL,1,NULL,NULL,1,'MASBAGIK','1978-12-31',1,3,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'AMAQ SAHMINI','INAQ SAHMINI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140105136997',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(15,'FARIDAH','5201141107101724',NULL,4,NULL,NULL,1,'MASBAGIK','2000-07-11',1,3,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'DAHRI','ASMIATUN',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140105136997',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(16,'ERLANGGA DWIKO SAPUTRO','5201140705156994',NULL,4,NULL,NULL,1,'MENINTING','2014-05-07',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'DAHRI','ASMIATUN',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140105136997',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(17,'ASMIATUN','5201147112817188',NULL,3,NULL,NULL,2,'MASBAGIK','1980-12-31',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'AMAQ MUJAENI','INAQ SAHMINI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140105136997',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(18,'BAIQ OLIVIA APRILLIANI','5201145211486994',NULL,1,NULL,NULL,2,'SENGGIGI','1947-11-12',1,1,NULL,18,1,4,1,NULL,NULL,NULL,NULL,'AMAQ SINAREP','INAQ SINAREP',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140106166996',NULL,NULL,NULL,NULL,'SENGGIGI','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(19,'FAUZI','5201141210906998',NULL,1,NULL,NULL,1,'KERANDANGAN','1989-10-12',1,5,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'SABLI','RAOHUN',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140106167002',NULL,NULL,NULL,NULL,'KERANDANGAN','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(20,'DELLA MAHARANI NINGSIH','5201147112947048',NULL,9,NULL,NULL,2,'KERANDANGAN','1993-12-31',1,4,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'SABLI','RAOHUN',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140106167002',NULL,NULL,NULL,NULL,'KERANDANGAN','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(21,'HAERUL FATONI','5201142911936995',NULL,1,NULL,NULL,1,'SENGGIGI','1992-11-29',1,5,NULL,18,15,2,1,NULL,NULL,NULL,NULL,'ANGKASAH','MARJANAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140106167003',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(22,'DENATUL SUARTINI','3275014601977005',NULL,3,NULL,NULL,2,'JAKARTA','1996-01-06',1,5,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'G. AMIN. P','NGATI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140106167003',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(23,'HERI IRAWAN','5201140607636994',NULL,1,NULL,NULL,1,'TELOKE','1962-07-06',1,3,NULL,18,9,2,1,NULL,NULL,NULL,NULL,'AMAK MAJUMI','INAK MIDAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140107126996',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(24,'DEWI SAULINA','5201144808686994',NULL,3,NULL,NULL,2,'KEKERAN','1967-08-08',1,1,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'H. ZAENUDIN','INAK NAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140107126996',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(25,'HERMAN','5201140305936994',NULL,4,NULL,NULL,1,'SENGGIGI','1992-05-03',1,4,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'HERI IRAWAN','DEWI SAULINA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140107126996',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(26,'ELOK KHALISA SABRINA','5201144408886994',NULL,4,NULL,NULL,2,'SENGGIGI','1987-08-04',1,4,NULL,18,88,1,1,NULL,NULL,NULL,NULL,'SERIMAN','DEWI SAULINA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140107126996',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(27,'I KETUT PAHING','5201142210806997',NULL,1,NULL,NULL,1,'MATARAM','1979-10-22',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'-','-',NULL,2,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140108146995',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(28,'IDA BAGUS MAS BUJANA','5201143112707040',NULL,1,NULL,NULL,1,'APIT AIK','1969-12-31',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'SAHMIN','MAOSIN',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140109126996',NULL,NULL,NULL,NULL,'MANGSIT','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(29,'KOMANG SALUN','5201143105121724',NULL,4,NULL,NULL,1,'KAYANGAN','2002-05-31',1,2,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'AMILUDIN','FITRIANI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140109126996',NULL,NULL,NULL,NULL,'MANGSIT','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(30,'JOKO PATMOTO','5201141009146994',NULL,4,NULL,NULL,1,'MANGSIT','2013-09-10',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'IDA BAGUS MAS BUJANA','FITRIANI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140109126996',NULL,NULL,NULL,NULL,'MANGSIT','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(31,'FITRIANI','5201145107836994',NULL,3,NULL,NULL,2,'KAYANGAN','1982-07-11',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'REMBUK','SITIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140109126996',NULL,NULL,NULL,NULL,'MANGSIT','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(32,'LALU WAWAN DININGRAT','5201141206886994',NULL,1,NULL,NULL,1,'MANGSIT','1987-06-12',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'MAHSUN SUBUH','SARDIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140109156994',NULL,NULL,NULL,NULL,'MANGSIT','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(33,'FITRIANI','5271016801926995',NULL,3,NULL,NULL,2,'MATARAM','1991-01-28',1,5,NULL,18,15,2,1,NULL,NULL,NULL,NULL,'UMAR','RUMINSIH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140109156994',NULL,NULL,NULL,NULL,'MANGSIT','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(34,'HILMIATI','5201146402906994',NULL,3,NULL,NULL,2,'LOCO','1989-02-24',1,4,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'H. MANSYUR','HJ. SA\'ADAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140110137011',NULL,NULL,NULL,NULL,'LOCO','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(35,'M. FA\'IZ AZAMI','5201143112897123',NULL,1,NULL,NULL,1,'GEGELANG','1988-12-31',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'SAREH','SUTIMAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140110137011',NULL,NULL,NULL,NULL,'LOCO','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(36,'HJ. PARIDAH','5201144912146994',NULL,4,NULL,NULL,2,'MENINTING','2013-12-09',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'M. FA\'IZ AZAMI','HILMIATI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140110137011',NULL,NULL,NULL,NULL,'LOCO','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(37,'HJ. SAMIRAH','5201147112767266',NULL,1,NULL,NULL,2,'SENGGIGI','1975-12-31',1,3,NULL,18,15,3,1,NULL,NULL,NULL,NULL,'DAMSYAH','MARWIYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140110137038',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(38,'HUR MINAH','5201144504131726',NULL,4,NULL,NULL,2,'SENGGIGI','2003-04-05',1,3,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'MARSINI','KHODIJAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140110137038',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(39,'HUSNAH','5201145905936994',NULL,1,NULL,NULL,2,'LOTIM','1992-05-19',1,4,NULL,18,88,1,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140110156997',NULL,NULL,NULL,NULL,'SENGGIGI','-','005','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(40,'IDA AYU OKA SUKERTI','5201147112587053',NULL,1,NULL,NULL,2,'KERANDANGAN','1957-12-31',1,3,NULL,18,88,4,1,NULL,NULL,NULL,NULL,'ANGGRAH','HABIBAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140111126997',NULL,NULL,NULL,NULL,'KERANDANGAN','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(41,'M. JAYADI','5201143112837098',NULL,1,NULL,NULL,1,'SENGGIGI','1982-12-31',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'IKHSAN','SAIDAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140111126999',NULL,NULL,NULL,NULL,'SENGGIGI','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(42,'LIHAM SATUN','5201147112116995',NULL,4,NULL,NULL,2,'MATARAM','2010-12-31',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'M. JAYADI','JARIYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140111126999',NULL,NULL,NULL,NULL,'SENGGIGI','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(43,'JARIYAH','5201145406916994',NULL,3,NULL,NULL,2,'SENGGIGI','1990-06-14',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'SEGEP','HURNIWATI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140111126999',NULL,NULL,NULL,NULL,'SENGGIGI','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(44,'M. NUR SAHID','5201140507916996',NULL,1,NULL,NULL,1,'KERANDANGAN','1990-07-05',1,4,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112107003',NULL,NULL,NULL,NULL,'KERANDANGAN','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(45,'MAISAH','5201144605936994',NULL,3,NULL,NULL,2,'KERANDANGAN','1992-05-06',4,1,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112107003',NULL,NULL,NULL,NULL,'KERANDANGAN','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(46,'MADE ASTAWE','5201142503181724',NULL,4,NULL,NULL,1,'KERANDANGAN','2008-03-25',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'M. NUR SAHID','MAISAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112107003',NULL,NULL,NULL,NULL,'KERANDANGAN','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(47,'MIRA FANDA','5201146704906995',NULL,4,NULL,NULL,2,'LOCO','1989-04-27',1,5,NULL,18,88,4,1,NULL,NULL,NULL,NULL,'MARSUNIN YOGA PRATAMA','MARLIA SAJIDA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112126998',NULL,NULL,NULL,NULL,'LOCO','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(48,'MARZUKI','5201141003966996',NULL,4,NULL,NULL,1,'LOCO','1995-03-10',1,5,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'MARSUNIN YOGA PRATAMA','MARLIA SAJIDA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112126998',NULL,NULL,NULL,NULL,'LOCO','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(49,'MARLIA SAJIDA','5201147112707088',NULL,3,NULL,NULL,2,'PEJARAKAN','1969-12-31',1,3,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'H. ZAINUDIN','INAQ NAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112126998',NULL,NULL,NULL,NULL,'LOCO','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(50,'MUNAAH','5201146304171724',NULL,4,NULL,NULL,2,'LOCO','2007-04-23',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'MARSUNIN YOGA PRATAMA','MARLIA SAJIDA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112126998',NULL,NULL,NULL,NULL,'LOCO','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(51,'MARSUNIN YOGA PRATAMA','5201143112677056',NULL,1,NULL,NULL,1,'PEJARAKAN','1966-12-31',1,3,NULL,18,9,2,1,NULL,NULL,NULL,NULL,'MISRAH','INAQ MISDAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112126998',NULL,NULL,NULL,NULL,'LOCO','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(52,'MUHAMAD HAMDI','5201141706986996',NULL,4,NULL,NULL,1,'LOCO','1997-06-17',1,4,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'MARSUNIN YOGA PRATAMA','MARLIA SAJIDA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140112126998',NULL,NULL,NULL,NULL,'LOCO','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(53,'MUHAMAD KABIR','5201140107917031',NULL,1,NULL,NULL,1,'SENGGIGI','1985-12-31',1,3,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'MUNIAH','SALIKIN',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140202167000',NULL,NULL,NULL,NULL,'SENGGIGI','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(54,'MUHAMMAD HAIKAL FIRMANSYAH','5201140308151724',NULL,4,NULL,NULL,1,'LOCO','2005-08-03',1,2,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'MUHAMAD SUHAD','KHADIJAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140202167002',NULL,NULL,NULL,NULL,'LOCO','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(55,'MUHAMAD SUHAD','5201141704876995',NULL,1,NULL,NULL,1,'SENGGIGI','1982-12-10',1,5,NULL,18,15,2,1,NULL,NULL,NULL,NULL,'MUNIAH','HAJRIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140202167002',NULL,NULL,NULL,NULL,'LOCO','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(56,'MURNIAH','5201145904846994',NULL,3,NULL,NULL,2,'SETANGI','1991-03-04',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'SAHABUDIN','SAKMAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140202167002',NULL,NULL,NULL,NULL,'LOCO','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(57,'MURNIATI SAGITA','5201144112726996',NULL,1,NULL,NULL,2,'YOGYAKARTA','1971-12-01',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'UMAR SANTOSA','MIRANTI',NULL,1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140203136994',NULL,NULL,NULL,NULL,'SENGGIGI','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(58,'NI KOMANG PONIASIH','5201146206126994',NULL,4,NULL,NULL,2,'MATARAM','2011-06-22',4,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'MURNIATI SAGITA','NADIA ROSDIANA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140203136995',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(59,'NADIA ROSDIANA','5201144305936996',NULL,3,NULL,NULL,2,'MATARAM','1992-05-03',4,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'I WAYAN PARTA','NI NENGAH SUDINI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140203136995',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(60,'MUHAMMAD RIFAI','5201143105926995',NULL,1,NULL,NULL,1,'LOCO','1991-05-31',4,4,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'I WAYAN MERTI','NI NYOMAN RENI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140203136995',NULL,NULL,NULL,NULL,'LOCO','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(61,'MUHAMMAD WIRDA MAULANA IBRAHIM','5201143112417056',NULL,1,NULL,NULL,1,'SENGGIGI','1940-12-31',1,1,NULL,18,9,2,1,NULL,NULL,NULL,NULL,'AMAQ SUN -ALM-','INAQ SUN -ALM-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140203167003',NULL,NULL,NULL,NULL,'SENGGIGI','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(62,'NI LUH NITA SARI','5201147112466997',NULL,3,NULL,NULL,2,'SENTELUK','1945-12-31',1,1,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'AMAQ IRAH','INAQ IRAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140203167003',NULL,NULL,NULL,NULL,'SENGGIGI','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(63,'NI NENGAH AYU KARSINI','5201145505946996',NULL,1,NULL,NULL,2,'SENGGIGI','1993-05-15',1,2,NULL,18,15,1,1,NULL,NULL,NULL,NULL,'H HAMDANI','SANERIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140204166994',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(64,'NURHAYATI','5201145509146994',NULL,4,NULL,NULL,2,'MENINTING','2013-09-15',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'MUKSAN','NUR\'AINI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156994',NULL,NULL,NULL,NULL,'MANGSIT','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(65,'MUKSAN','5201143112957094',NULL,1,NULL,NULL,1,'MANGSIT','1994-12-31',1,4,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'MISDAH','RABIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156994',NULL,NULL,NULL,NULL,'MANGSIT','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(66,'NURHIDAYAH','5201144209766995',NULL,1,NULL,NULL,2,'MANGSIT','1975-09-02',1,3,NULL,18,2,4,1,NULL,NULL,NULL,NULL,'ISMAIL','JUMINAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156995',NULL,NULL,NULL,NULL,'MANGSIT','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(67,'NURUL AINUN','5201144108121724',NULL,4,NULL,NULL,2,'MANGSIT','2002-08-01',1,2,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'RUSNAH','NURHIDAYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156995',NULL,NULL,NULL,NULL,'MANGSIT','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(68,'MURSIDIN','5201142204966994',NULL,4,NULL,NULL,1,'MANGSIT','1995-04-22',1,3,NULL,18,11,1,1,NULL,NULL,NULL,NULL,'RUSNAH (ALM)','NURHIDAYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156995',NULL,NULL,NULL,NULL,'MANGSIT','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(69,'NURJANAH','5201145005101724',NULL,4,NULL,NULL,2,'MONTONG','2000-05-10',1,4,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'RUSNAH (ALM)','NURHIDAYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156995',NULL,NULL,NULL,NULL,'MANGSIT','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(70,'MUSAHAB','5201141607936996',NULL,1,NULL,NULL,1,'LOTENG','1992-07-16',1,6,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'LALU ROSIDI','BQ. ALISA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156996',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(71,'NURUL HIDAYATI','5201147004136996',NULL,4,NULL,NULL,2,'MATARAM','2012-04-30',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'MUSAHAB','NURUL FAIZAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156996',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:14'),(72,'NURUL FAIZAH','5201145003936994',NULL,3,NULL,NULL,2,'SENGGIGI','1992-03-10',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'SAHUR','SARE\'AH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156996',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(73,'RACHEL YULIANTI','5201146507966995',NULL,3,NULL,NULL,2,'MELASE','1995-07-25',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'LUKMAN','MUSNAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156997',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(74,'NAPIAH','5201141303906995',NULL,1,NULL,NULL,1,'SENGGIGI','1989-03-13',1,4,NULL,18,11,2,1,NULL,NULL,NULL,NULL,'MUNIAH','HAJARIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156997',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(75,'RAISHA MAULIDYA','5201144701156995',NULL,4,NULL,NULL,2,'MENINTING','2014-01-07',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'NAPIAH','RACHEL YULIANTI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140205156997',NULL,NULL,NULL,NULL,'LOCO','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(76,'RATNAWATY','5201145512796995',NULL,3,NULL,NULL,2,'KERANDANGAN','1978-12-15',1,5,NULL,18,84,2,1,NULL,NULL,NULL,NULL,'JUM','REMAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140206157000',NULL,NULL,NULL,NULL,'KERANDANGAN','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(77,'PATANUL HUSNUL','5201143112667000',NULL,1,NULL,NULL,1,'JAWA TIMUR','1965-12-31',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'AHMAD','ASIH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140206157000',NULL,NULL,NULL,NULL,'KERANDANGAN','-','001','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(78,'RABITAH','5201140312896994',NULL,1,NULL,NULL,1,'KERANDANGAN','1988-12-03',4,4,NULL,18,88,1,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140206157004',NULL,NULL,NULL,NULL,'KERANDANGAN','-','004','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(79,'ROMI FAISAL','5201141506856997',NULL,1,NULL,NULL,1,'MANGSIT','1984-06-15',1,3,NULL,18,15,2,1,NULL,NULL,NULL,NULL,'MUNTAHAR','MAKNAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140207156998',NULL,NULL,NULL,NULL,'MANGSIT','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(80,'ROHANI','5201144306116994',NULL,4,NULL,NULL,2,'MANGSIT','2010-06-03',1,1,NULL,18,1,1,1,NULL,NULL,NULL,NULL,'ROMI FAISAL','RAUDATUL ILMI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140207156998',NULL,NULL,NULL,NULL,'MANGSIT','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(81,'RAUDATUL ILMI','5201145808816994',NULL,3,NULL,NULL,2,'IRENG DAYE','1980-08-18',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'MUDAHIR','RUMISAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140207156998',NULL,NULL,NULL,NULL,'MANGSIT','-','003','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(82,'RUMALI','5201144507886994',NULL,9,NULL,NULL,2,'JAKARTA','1987-07-05',1,4,NULL,18,88,1,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140207157000',NULL,NULL,NULL,NULL,'SENGGIGI','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(83,'RUKIAH','5201145909946994',NULL,1,NULL,NULL,2,'SERANG','1993-09-19',1,4,NULL,18,88,3,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140207157000',NULL,NULL,NULL,NULL,'SENGGIGI','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(84,'RUSMAYANTI','5201145003546994',NULL,1,NULL,NULL,2,'DENPASAR','1953-03-10',4,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'IDA BAGUS MAS','IDA AYU RAKA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140209156996',NULL,NULL,NULL,NULL,'KERANDANGAN','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(85,'RONI','5201140301836997',NULL,4,NULL,NULL,1,'DENPASAR','1982-01-03',4,5,NULL,18,15,1,1,NULL,NULL,NULL,NULL,'IDA BAGUS PUTU WIADNYA','RUSMAYANTI',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140209156996',NULL,NULL,NULL,NULL,'KERANDANGAN','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(86,'RUSNI','5201143112707180',NULL,1,NULL,NULL,1,'KEKERAN','1969-12-31',1,3,NULL,18,9,2,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140210137022',NULL,NULL,NULL,NULL,'SENGGIGI','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(87,'SAPINAH','5201145701966994',NULL,4,NULL,NULL,2,'SENGGIGI','1995-01-17',1,5,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'RUSNI','SAPIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140210137022',NULL,NULL,NULL,NULL,'SENGGIGI','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(88,'SAPIAH','5201147011726994',NULL,3,NULL,NULL,2,'KEKERAN','1971-11-30',1,3,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'-','-',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140210137022',NULL,NULL,NULL,NULL,'SENGGIGI','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(89,'SARRA LANGELAND','5201145111946996',NULL,4,NULL,NULL,2,'SENGGIGI','1993-11-11',1,5,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'RUSNI','SAPIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140210137022',NULL,NULL,NULL,NULL,'SENGGIGI','-','006','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(90,'SAHRONI','5201143112617096',NULL,1,NULL,NULL,1,'MEDAS','1960-12-31',1,4,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'SADIYAH','INAQ SADIAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117001',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(91,'SUNYOTOH','5201143112817139',NULL,4,NULL,NULL,1,'MEDAS','1980-12-31',1,5,NULL,18,15,1,1,NULL,NULL,NULL,NULL,'SAHRONI','NURLAELA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117001',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(92,'SERIMAN','5201141012846995',NULL,4,NULL,NULL,1,'SENGGIGI','1983-12-10',1,5,NULL,18,15,1,1,NULL,NULL,NULL,NULL,'SAHRONI','NURLAELA',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117001',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(93,'SYARIFUL KALAM','5201141707776994',NULL,1,NULL,NULL,1,'SENGGIGI','1976-07-17',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'H. ABDURAHMAN','NAFISAH',NULL,1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117002',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(94,'SITI AISYAH','5201146210776994',NULL,3,NULL,NULL,2,'SUKARAJA','1976-10-22',1,4,NULL,18,2,2,1,NULL,NULL,NULL,NULL,'AMINALLOH','RAEHAN',NULL,2,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117002',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(95,'SUKMA UTAMI','5201144607996998',NULL,4,NULL,NULL,2,'SENGGIGI','1998-07-06',1,4,NULL,18,3,1,1,NULL,NULL,NULL,NULL,'SYARIFUL KALAM','SITI AISYAH',NULL,5,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117002',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(96,'WAHID ALIAS H. MAHSUN','5201141212816996',NULL,1,NULL,NULL,1,'SENGGIGI','1980-12-12',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'H. ABDURRAHMAN','NAFISAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117003',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15'),(97,'ULFA WIDIAWATI','5201145203896994',NULL,3,NULL,NULL,2,'JOHAR PELITA','1988-03-12',1,5,NULL,18,88,2,1,NULL,NULL,NULL,NULL,'ZAMHARIN','SITIYAH',NULL,13,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'5201140211117003',NULL,NULL,NULL,NULL,'SENGGIGI','-','002','53.06.13.2001',NULL,'2019-05-28 22:45:28','2019-05-28 22:45:28',NULL,'2025-04-23 08:02:15');
/*!40000 ALTER TABLE `das_penduduk` ENABLE KEYS */;

--
-- Table structure for table `das_penduduk_sex`
--

DROP TABLE IF EXISTS `das_penduduk_sex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_penduduk_sex` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_penduduk_sex`
--

/*!40000 ALTER TABLE `das_penduduk_sex` DISABLE KEYS */;
INSERT INTO `das_penduduk_sex` VALUES (1,'Laki-laki'),(2,'Perempuan');
/*!40000 ALTER TABLE `das_penduduk_sex` ENABLE KEYS */;

--
-- Table structure for table `das_pengurus`
--

DROP TABLE IF EXISTS `das_pengurus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_pengurus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `gelar_depan` varchar(255) DEFAULT NULL,
  `gelar_belakang` varchar(255) DEFAULT NULL,
  `nip` bigint(20) DEFAULT NULL,
  `nik` varchar(16) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `foto` varchar(255) DEFAULT NULL,
  `tempat_lahir` varchar(255) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `sex` tinyint(1) NOT NULL,
  `pendidikan_id` int(10) unsigned NOT NULL,
  `agama_id` int(10) unsigned NOT NULL,
  `no_sk` varchar(255) DEFAULT NULL,
  `tanggal_sk` date DEFAULT NULL,
  `masa_jabatan` varchar(255) NOT NULL,
  `pangkat` varchar(255) DEFAULT NULL,
  `no_henti` varchar(255) DEFAULT NULL,
  `tanggal_henti` date DEFAULT NULL,
  `jabatan_id` int(10) unsigned NOT NULL,
  `bagan_tingkat` int(11) DEFAULT NULL,
  `bagan_offset` int(11) DEFAULT NULL,
  `bagan_layout` varchar(50) DEFAULT NULL,
  `bagan_warna` varchar(20) DEFAULT NULL,
  `atasan` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_pengurus_nik_unique` (`nik`),
  UNIQUE KEY `das_pengurus_nip_unique` (`nip`),
  KEY `das_pengurus_jabatan_id_foreign` (`jabatan_id`),
  CONSTRAINT `das_pengurus_jabatan_id_foreign` FOREIGN KEY (`jabatan_id`) REFERENCES `ref_jabatan` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_pengurus`
--

/*!40000 ALTER TABLE `das_pengurus` DISABLE KEYS */;
INSERT INTO `das_pengurus` VALUES (1,'H. Hadi Fathurrahman, S.Sos, M.AP',NULL,NULL,NULL,'16',1,NULL,'Mangsit','2025-04-23',1,1,1,NULL,'2025-04-23','5','Camat',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2025-04-23 08:02:16',NULL);
/*!40000 ALTER TABLE `das_pengurus` ENABLE KEYS */;

--
-- Table structure for table `das_pesan`
--

DROP TABLE IF EXISTS `das_pesan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_pesan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `das_data_desa_id` int(10) unsigned NOT NULL,
  `jenis` enum('Pesan Masuk','Pesan Keluar') NOT NULL,
  `sudah_dibaca` tinyint(1) NOT NULL DEFAULT 0,
  `diarsipkan` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `das_pesan_das_data_desa_id_foreign` (`das_data_desa_id`),
  CONSTRAINT `das_pesan_das_data_desa_id_foreign` FOREIGN KEY (`das_data_desa_id`) REFERENCES `das_data_desa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_pesan`
--

/*!40000 ALTER TABLE `das_pesan` DISABLE KEYS */;
INSERT INTO `das_pesan` VALUES (1,'Eos adipisci illum est.',12,'Pesan Keluar',1,0,'2025-03-03 15:19:09','2025-02-10 05:38:24'),(2,'Amet pariatur minus consequatur illo magni ipsam.',15,'Pesan Masuk',1,0,'2025-03-30 23:50:11','2025-04-04 05:06:31'),(3,'Consectetur cupiditate voluptatibus ea molestias.',5,'Pesan Masuk',0,0,'2025-01-31 23:09:33','2025-04-06 22:23:26'),(4,'Vel aperiam maxime voluptas alias architecto.',2,'Pesan Masuk',0,1,'2025-04-05 11:14:06','2025-02-20 00:12:34'),(5,'Magni non accusantium perspiciatis eius.',13,'Pesan Masuk',0,1,'2025-01-07 04:54:02','2025-02-09 01:16:09'),(6,'Quisquam excepturi cumque hic aut.',10,'Pesan Keluar',1,1,'2025-03-13 04:20:58','2025-01-12 14:26:40'),(7,'Quia facere praesentium dolores.',8,'Pesan Keluar',1,1,'2025-02-15 04:00:44','2025-03-20 08:23:53'),(8,'Aspernatur nulla ut doloremque iste molestias et.',8,'Pesan Masuk',0,0,'2025-01-29 16:51:43','2025-03-12 00:50:09'),(9,'Dolores ut molestiae quam odit ut fuga.',1,'Pesan Masuk',1,0,'2025-04-02 23:36:17','2025-01-28 15:50:01'),(10,'Ut eligendi ut et dolore aut non animi.',10,'Pesan Keluar',0,1,'2025-03-01 07:23:53','2025-04-13 09:04:30'),(11,'Quod eligendi numquam aut eius.',20,'Pesan Masuk',1,0,'2025-02-17 21:28:02','2025-03-22 12:34:58'),(12,'Vero ipsum quidem qui eligendi non.',19,'Pesan Masuk',1,1,'2025-02-23 08:51:43','2025-04-05 07:28:28'),(13,'Eius dicta aliquam ab et quia non et.',10,'Pesan Keluar',0,0,'2025-02-07 06:13:51','2025-01-23 17:45:23'),(14,'Cum fugiat et temporibus et adipisci magnam.',2,'Pesan Masuk',1,1,'2025-02-11 01:16:26','2025-02-19 19:59:59'),(15,'Porro velit saepe dolores.',9,'Pesan Keluar',1,0,'2025-03-11 15:14:43','2025-03-30 16:37:25'),(16,'Id tenetur deleniti est. A sint est neque omnis.',10,'Pesan Keluar',0,1,'2025-04-12 15:42:36','2025-03-22 00:56:15'),(17,'Natus quidem animi ex eveniet soluta enim.',8,'Pesan Masuk',0,0,'2025-01-24 15:40:15','2025-02-15 08:19:52'),(18,'Omnis et praesentium est tenetur eveniet commodi.',14,'Pesan Masuk',0,0,'2025-02-28 15:16:36','2025-01-20 16:55:51'),(19,'Quia quis aut molestiae tempore ducimus.',20,'Pesan Keluar',1,0,'2025-02-21 16:00:41','2025-01-06 20:45:09'),(20,'Cum ut unde voluptas aliquam numquam qui.',15,'Pesan Keluar',0,0,'2025-03-21 09:20:47','2025-02-24 08:56:16'),(21,'Quia quis esse nulla voluptates velit.',11,'Pesan Masuk',0,0,'2025-02-19 11:06:56','2025-01-25 00:43:53'),(22,'Vitae quam aut non recusandae eveniet.',17,'Pesan Masuk',1,0,'2025-01-06 13:58:52','2025-03-24 15:14:38'),(23,'In aut maxime dignissimos vel et iste dolorum.',11,'Pesan Keluar',1,1,'2025-01-21 17:15:53','2025-03-25 06:30:41'),(24,'Ea sunt rerum nemo.',12,'Pesan Keluar',0,0,'2025-04-05 01:28:45','2025-03-08 03:03:41'),(25,'Omnis earum voluptatem est placeat voluptatem.',12,'Pesan Masuk',1,1,'2025-04-14 21:56:50','2025-01-16 08:26:38'),(26,'Libero natus adipisci eum sint.',10,'Pesan Masuk',1,1,'2025-03-15 18:40:09','2025-03-05 01:40:28'),(27,'Quaerat facilis cupiditate quidem id.',18,'Pesan Keluar',1,1,'2025-03-21 18:31:58','2025-01-16 15:30:25'),(28,'Velit fugiat facere hic beatae deleniti.',12,'Pesan Masuk',1,0,'2025-03-17 06:26:20','2025-01-24 00:56:08'),(29,'Eos ut qui vero odio voluptas in.',6,'Pesan Keluar',0,0,'2025-01-06 08:28:18','2025-04-09 20:11:38'),(30,'Id tempora et quo odio consequuntur.',19,'Pesan Masuk',1,0,'2025-01-23 20:40:35','2025-03-11 11:55:25'),(31,'Aliquid corrupti veritatis et corporis.',10,'Pesan Masuk',0,1,'2025-02-19 22:59:44','2025-04-21 20:27:40'),(32,'Doloribus et at quis quo ut sapiente qui.',1,'Pesan Keluar',0,1,'2025-03-05 18:08:59','2025-01-27 14:56:59'),(33,'Quia exercitationem eveniet molestiae architecto.',12,'Pesan Masuk',1,0,'2025-02-17 02:29:18','2025-02-17 02:36:35'),(34,'Labore repellat autem neque et deserunt nihil.',10,'Pesan Masuk',1,0,'2025-04-07 04:27:15','2025-01-21 16:49:57'),(35,'Deserunt sint et amet expedita.',2,'Pesan Keluar',1,1,'2025-01-06 00:43:42','2025-02-15 17:45:18'),(36,'Quia omnis facere quidem et omnis.',16,'Pesan Masuk',0,1,'2025-02-25 13:51:02','2025-03-11 14:07:07'),(37,'Quis incidunt aliquid facilis nobis amet.',19,'Pesan Masuk',1,0,'2025-01-24 09:04:29','2025-02-28 14:56:45'),(38,'Aspernatur est dignissimos facere saepe.',12,'Pesan Keluar',1,1,'2025-04-17 05:20:33','2025-04-21 06:13:30'),(39,'Quibusdam sed autem nulla qui.',10,'Pesan Keluar',1,1,'2025-03-22 10:24:11','2025-01-20 05:34:42'),(40,'Similique quod dolores totam vel in quaerat.',8,'Pesan Keluar',0,0,'2025-02-18 17:16:42','2025-03-02 09:36:31'),(41,'Esse in nesciunt et nihil nihil.',2,'Pesan Masuk',1,1,'2025-03-10 07:48:19','2025-01-19 16:45:36'),(42,'Aut occaecati est cupiditate aspernatur ut.',14,'Pesan Masuk',1,1,'2025-04-14 10:10:50','2025-03-23 09:34:40'),(43,'Eius ex asperiores cum voluptatem.',6,'Pesan Keluar',1,0,'2025-02-12 18:09:41','2025-02-14 17:26:16'),(44,'Aut reiciendis nesciunt magnam.',2,'Pesan Keluar',1,1,'2025-03-27 17:33:36','2025-04-04 23:19:04'),(45,'Et et aut ea maxime.',5,'Pesan Keluar',0,1,'2025-01-10 11:42:04','2025-01-19 16:20:11'),(46,'Voluptatem omnis velit accusantium maiores enim.',20,'Pesan Keluar',1,1,'2025-03-21 03:35:48','2025-03-17 18:04:14'),(47,'Officiis aut aliquam quia.',9,'Pesan Keluar',1,0,'2025-02-08 22:11:09','2025-02-02 04:23:18'),(48,'Porro aliquam hic nemo dolor.',16,'Pesan Masuk',0,0,'2025-01-31 14:30:26','2025-02-14 18:04:31'),(49,'Eum assumenda qui laborum praesentium vel sequi.',20,'Pesan Masuk',0,0,'2025-01-20 22:37:27','2025-03-16 10:47:25'),(50,'Ut sint quasi voluptas et dignissimos.',7,'Pesan Masuk',0,1,'2025-03-11 13:03:29','2025-02-14 03:18:51');
/*!40000 ALTER TABLE `das_pesan` ENABLE KEYS */;

--
-- Table structure for table `das_pesan_detail`
--

DROP TABLE IF EXISTS `das_pesan_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_pesan_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pesan_id` int(10) unsigned NOT NULL,
  `text` text DEFAULT NULL,
  `pengirim` varchar(20) NOT NULL,
  `nama_pengirim` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `das_pesan_detail_pesan_id_foreign` (`pesan_id`),
  CONSTRAINT `das_pesan_detail_pesan_id_foreign` FOREIGN KEY (`pesan_id`) REFERENCES `das_pesan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_pesan_detail`
--

/*!40000 ALTER TABLE `das_pesan_detail` DISABLE KEYS */;
INSERT INTO `das_pesan_detail` VALUES (1,50,'Eveniet aut voluptas eum aperiam ex asperiores facilis. Quos dolor voluptas possimus magni non. Laboriosam aut velit animi unde excepturi sunt.','desa','Miss Danyka Murray V','2025-02-08 14:30:57','2025-04-01 10:24:31'),(2,4,'Rerum pariatur maiores nemo et maxime esse sit. Accusamus rerum minima similique repellendus. Est sapiente quos fugiat quia repellat. Asperiores ipsa voluptatem molestiae neque nam dolores.','desa','Otis Littel','2025-04-19 06:17:57','2025-03-01 23:25:10'),(3,32,'Dolores unde exercitationem beatae. Iste enim et et voluptates dolorem qui qui. Quia ab laboriosam corrupti.','desa','Damion Sanford','2025-01-15 21:46:22','2025-01-18 14:13:44'),(4,44,'Porro non odit eius consectetur laboriosam ea dolorum quia. Assumenda ut cum nulla debitis enim quia. Ea omnis eum ut ut quos. Reprehenderit dolorum eos totam excepturi maiores aut.','desa','Rosella Hayes','2025-01-10 08:56:28','2025-04-11 21:01:35'),(5,17,'Laborum quo hic nostrum maxime commodi et adipisci. Corporis cupiditate id itaque non. Deserunt consectetur odit et numquam quos. Odit dolore omnis rerum exercitationem vero.','desa','Jerrell Batz','2025-02-14 20:43:52','2025-03-16 16:09:50'),(6,7,'Aut totam voluptatem fugiat molestiae praesentium reprehenderit aut ipsam. Vel quia natus ut reprehenderit debitis. Qui consectetur quisquam odio iste. Vel optio repellat tenetur quidem.','desa','Jaiden Armstrong','2025-01-21 23:24:19','2025-01-01 20:03:10'),(7,40,'Ipsum facere recusandae dolor ex. Officiis consequatur non esse.','desa','Clare Ebert V','2025-02-10 05:29:38','2025-04-12 17:19:07'),(8,41,'Temporibus consequatur expedita quia nihil in facilis natus. Officia reprehenderit nihil sint dolorum illo. Quos nesciunt minus possimus tempore deleniti doloribus.','desa','Miss Mayra Grimes Sr.','2025-01-28 18:54:35','2025-04-06 06:03:17'),(9,50,'Ea repellendus atque est laboriosam molestias. Odit voluptatem provident voluptatem quisquam autem. Quo voluptatem minus fugiat odit mollitia possimus in.','desa','Jacquelyn Lemke','2025-01-24 01:07:44','2025-01-14 21:28:49'),(10,43,'Dolor culpa corporis rerum beatae. Illo ut provident quo minima. Rerum sint voluptas enim libero ut numquam veritatis aut.','desa','Javier Kilback','2025-01-02 10:07:17','2025-02-15 10:39:21'),(11,8,'Voluptate nemo totam iure ratione. Magni optio quia enim aliquam et ea. Nostrum atque eligendi quia. Consequatur id alias reprehenderit laborum qui aperiam qui.','desa','Amelia Greenholt','2025-03-03 01:12:51','2025-02-19 03:10:23'),(12,3,'Et laborum possimus nulla sed aut qui. A et ut quo atque ipsum consequuntur rem. Cupiditate quia vitae quis. Ut placeat rerum in ut placeat quisquam asperiores.','desa','Prof. Scottie Littel Sr.','2025-03-09 13:24:07','2025-02-17 18:13:54'),(13,29,'Quos et velit optio corrupti autem eaque fuga. Et facilis facere asperiores ut corporis. Labore quis sit et rerum.','desa','Ned Rath','2025-03-09 21:42:39','2025-04-13 00:31:44'),(14,15,'Itaque natus occaecati est et magnam labore. Mollitia non aspernatur est atque maiores cupiditate blanditiis. Corrupti qui tempora iste ut a cupiditate et. Autem ab porro et est officia quia veniam.','desa','Marion Hegmann','2025-02-11 06:27:12','2025-04-03 11:43:04'),(15,3,'Blanditiis est ea quibusdam. Corrupti voluptas consequatur reiciendis quaerat repellendus. Quis illum aut sequi.','desa','Mrs. Petra Crona','2025-03-09 13:44:14','2025-02-12 18:52:42'),(16,41,'Nihil alias optio ea placeat illum. Ut possimus fugiat iste neque aperiam. Voluptates accusamus non tempora voluptatem temporibus et quis. Cumque ipsam officia et quod exercitationem ad repellendus.','desa','Prof. Isom Brown','2025-03-03 05:16:25','2025-03-09 02:12:59'),(17,8,'Optio ea quas enim laborum officia. Ut dolore ipsa autem qui est. Et rerum ipsam suscipit et et. Quos recusandae occaecati iusto aspernatur maiores sit nihil.','desa','Monte Doyle','2025-02-17 02:24:36','2025-01-08 22:23:38'),(18,15,'Voluptatem eos eligendi maiores est. Necessitatibus impedit est voluptatum dolor tempore laudantium. Et officia et id non. Eius qui tempore incidunt et.','desa','Prof. Rossie Schinner DVM','2025-01-29 12:34:20','2025-01-18 14:57:40'),(19,43,'Et quis accusamus voluptatem assumenda et totam quis. Sit autem aperiam beatae sed. Aut nulla dolor beatae voluptatum similique velit ut alias. Ipsum unde eaque accusantium sint quo sed voluptatem.','desa','Jerrold Beier','2025-01-01 00:58:59','2025-02-05 15:40:07'),(20,35,'Totam ratione porro maxime possimus ut. Perferendis totam numquam quos eveniet voluptatum. Fuga quisquam inventore quia consectetur est qui animi commodi.','desa','George McGlynn','2025-01-10 14:05:50','2025-03-22 03:47:39'),(21,41,'Voluptatem ratione aut voluptate rerum. Aliquid sint maxime ut laboriosam. Est voluptatem ad recusandae quae. Aut et dolorum voluptatem ab.','desa','Sage Trantow','2025-04-16 05:36:58','2025-01-28 16:03:45'),(22,40,'Quisquam mollitia accusamus alias qui id exercitationem debitis. Ipsam autem et vero dolores quia qui. Qui ab neque dolores in aut.','desa','Miss Heidi Rice','2025-02-22 18:39:46','2025-03-19 11:24:49'),(23,10,'Dolor totam et magni consequatur sunt. Ipsa aut sed incidunt et veritatis. Commodi molestiae tenetur tempore debitis facere iste. Consequatur alias ex placeat nam consequatur.','desa','Buford Ledner','2025-03-28 00:47:35','2025-01-15 15:54:43'),(24,10,'Et aspernatur aut et. Maxime est corrupti aut velit.','desa','Rylee Keebler','2025-04-13 23:12:52','2025-01-09 14:48:03'),(25,43,'Cupiditate hic eum et facere officiis voluptatibus ut. Consequatur eligendi veritatis sed eos. Ea nam et et beatae.','desa','Tara Schultz','2025-01-17 17:43:42','2025-01-03 03:12:20'),(26,8,'Exercitationem dolores sed doloremque dolores commodi quis. Neque soluta autem quis rerum saepe aspernatur molestiae. Odio molestias doloribus et tempora qui amet.','desa','Brooklyn Kohler','2025-03-08 12:58:40','2025-03-23 10:21:29'),(27,47,'Sint explicabo aliquid aut molestiae molestiae dolorem. Sapiente dolorum enim veniam omnis reiciendis qui accusamus. Quia magnam sint perferendis dolore quibusdam quasi qui ullam.','desa','Prof. Eliezer Bernhard Sr.','2025-01-08 21:32:23','2025-02-01 12:46:44'),(28,40,'Error animi suscipit vel non. Impedit quis hic aut doloribus qui sed ducimus. Eum nihil alias molestiae reiciendis illo laboriosam.','desa','Dr. Carlee Roob','2025-04-02 08:36:34','2025-02-28 07:23:20'),(29,4,'Facilis quos repellendus assumenda et voluptatem minus. Et necessitatibus excepturi mollitia doloribus aut. Et eos dolores soluta necessitatibus fugit et aut.','desa','Mrs. Zena Marquardt','2025-01-26 22:46:30','2025-01-06 21:58:12'),(30,29,'Praesentium libero deleniti ullam vitae occaecati. Ut vero suscipit labore.','desa','Ozella Kshlerin','2025-02-26 04:48:30','2025-01-13 08:10:45'),(31,14,'Deserunt et laudantium dolore. Cupiditate odio sunt magnam tempore rerum magni. Commodi repudiandae consequatur animi. Nihil quod ut non delectus ex sed omnis.','desa','Dr. Casey Kulas PhD','2025-03-26 06:22:19','2025-03-15 22:10:22'),(32,29,'Et ut quaerat qui sint similique facilis at id. Culpa et esse odit nemo mollitia quod. Sunt autem fugit delectus dolorem explicabo similique. Aut ipsam eum unde.','desa','Cordell Huels','2025-02-19 04:01:24','2025-04-20 14:21:34'),(33,14,'Dicta corrupti beatae iusto ut. Molestias nobis ad in labore dicta delectus. Reiciendis consequatur est praesentium vero omnis ipsum harum. Quia voluptatum aut sequi sed quod aut dolorem.','desa','Mr. Erling Ullrich IV','2025-01-26 19:35:49','2025-01-18 08:30:39'),(34,32,'Ut dolorem alias mollitia sequi sit ut excepturi sit. Ut ducimus natus sapiente expedita quae beatae. Ut est reprehenderit repudiandae modi. Esse excepturi ea enim vero quaerat.','desa','Baylee Jenkins','2025-02-08 01:30:16','2025-03-11 06:41:34'),(35,43,'Aspernatur aspernatur sed amet reprehenderit minima laboriosam consectetur. Ipsa minus tenetur quidem accusamus blanditiis qui. Quia molestiae quae et quidem molestiae expedita.','desa','Francisca Emard','2025-04-03 02:21:14','2025-03-19 23:03:27'),(36,6,'Ducimus voluptatem harum deleniti ut in nisi. Et eligendi qui animi excepturi in laborum doloribus. Incidunt unde adipisci saepe est alias. Fugiat quia officiis cumque incidunt.','desa','Mrs. Earline Weissnat','2025-03-10 10:59:31','2025-04-03 21:25:53'),(37,14,'Reprehenderit dolorem odio id distinctio vitae. Ut expedita omnis beatae. Nam accusamus ut sit qui eius ex beatae. Vel ipsam sit dolorem sequi adipisci.','desa','Karine Bernhard','2025-03-13 20:18:44','2025-04-14 08:10:13'),(38,40,'Recusandae dolorem officia repellat optio necessitatibus vel. Error optio veritatis quae cupiditate qui repudiandae deserunt. Et totam nesciunt excepturi ut et quo itaque facere.','desa','Mateo Parisian IV','2025-02-10 05:24:04','2025-03-15 03:32:28'),(39,6,'Itaque et voluptas aut ipsum voluptatem dolores. Cupiditate enim quos veniam in occaecati expedita repellat. Libero tempora dignissimos voluptates expedita ex aspernatur voluptatem voluptate.','desa','Macey Lowe','2025-03-23 05:18:09','2025-01-31 14:14:21'),(40,17,'Ut vero aut nulla. Recusandae suscipit molestiae in cumque et nostrum. Inventore vel doloribus rerum culpa. Labore est a eum qui.','desa','Dr. Fabian Bayer II','2025-01-03 05:39:36','2025-02-03 10:36:19'),(41,40,'Exercitationem impedit et quisquam reiciendis accusantium rem dolorem. Iusto odit tempore exercitationem velit. Qui aliquid eius quisquam quidem occaecati inventore praesentium.','desa','Mr. Felix Brakus','2025-01-22 04:57:08','2025-01-24 11:39:24'),(42,35,'Architecto error quo optio asperiores itaque nemo. Quis et enim quos sit sunt. Voluptatum cumque quisquam odit ea quibusdam quo. Sunt in molestiae numquam qui.','desa','Mr. Earnest Christiansen','2025-01-20 11:06:46','2025-01-18 16:20:43'),(43,45,'Vero accusantium eos et voluptatem deleniti et omnis. Dolores nulla est corrupti minus aliquam mollitia quas. Dolor vel magni autem quas. Atque iste dolorem est hic.','desa','Prince Deckow','2025-03-22 14:13:25','2025-01-28 20:02:51'),(44,44,'Veniam quia eos dicta est. Alias labore recusandae eveniet. Vel voluptatem suscipit occaecati et quis. Aliquid sint vel aut nihil.','desa','Jamil Brakus','2025-02-22 04:15:20','2025-01-30 01:05:24'),(45,40,'Deleniti delectus ut culpa ut culpa. Nihil aut in omnis eius. Ullam quia voluptatem exercitationem autem qui. Autem alias dignissimos ullam illum repellendus.','desa','Sandy Kiehn','2025-04-08 04:16:11','2025-02-04 22:39:12'),(46,4,'Atque nihil architecto sit dolorum ratione. Ut similique autem qui doloremque. Porro quis maxime suscipit soluta excepturi. Atque aut et odio.','desa','Barry Bahringer','2025-01-18 20:44:46','2025-03-19 13:07:14'),(47,43,'Fugiat a ut ut et quia neque. Neque voluptas occaecati similique sed natus. Et qui aut vero. Odit aperiam ut molestiae ad accusantium earum mollitia. Cum a nam porro illum quod.','desa','Bailee Quitzon','2025-01-06 03:42:22','2025-02-10 21:00:25'),(48,41,'Harum vel voluptate quidem aut praesentium repudiandae voluptas. Laborum natus facere voluptatem eum minima mollitia recusandae. Et nesciunt incidunt quis distinctio id et ipsam rem.','desa','Nettie Weber','2025-04-07 05:15:54','2025-01-19 01:52:39'),(49,35,'Maiores qui et adipisci nisi. Dignissimos quia aut mollitia. Nemo rerum quas et excepturi aspernatur. Numquam in ut quo ut error sed.','desa','Mr. Chelsey Schneider IV','2025-03-02 22:37:36','2025-03-10 16:05:00'),(50,45,'Consequatur qui voluptatibus laboriosam et nesciunt omnis non. Vitae labore voluptatibus et atque nisi. Assumenda nostrum cum natus et.','desa','Brannon Schinner Sr.','2025-03-17 15:47:17','2025-01-13 15:54:58'),(51,40,'Eos sapiente doloribus libero nemo sed. Vitae vero possimus ut nobis. Consectetur omnis nihil optio non est cumque. Placeat qui incidunt at velit eum sunt.','desa','Brent Reichel','2025-04-14 05:00:37','2025-04-08 16:52:29'),(52,3,'Aut quia iste qui necessitatibus. Maiores sapiente qui error placeat quia. Quas ipsam rerum fugit vero nam qui.','desa','Mr. Kris Batz','2025-02-23 17:28:02','2025-02-06 20:08:44'),(53,29,'Et sint totam quae quas neque velit. Quis quas aut quo magni numquam corporis illum.','desa','Sincere Koss','2025-01-19 22:28:40','2025-03-10 10:59:56'),(54,10,'Repudiandae molestias modi tenetur possimus repellat unde excepturi. A dolorem impedit dolore aut cupiditate veniam distinctio nam. Et ullam sint odit minus sed. Sint sit aperiam sapiente in.','desa','Norwood Jacobi','2025-02-13 13:50:23','2025-03-23 07:30:42'),(55,40,'Tempora et rem non velit vitae. Sed quidem ducimus nulla sed ut. Et perferendis labore ratione amet. Cum occaecati quae fugit.','desa','Lamar Schmeler','2025-01-19 11:31:05','2025-03-20 21:49:23'),(56,35,'Laudantium eum quia sit optio molestias at. Animi facere optio ipsum id. Modi eveniet qui et ullam maiores quaerat accusamus. Qui dolor sequi aut et.','desa','Dr. Lindsey Leuschke Jr.','2025-02-09 16:25:44','2025-03-12 03:20:33'),(57,50,'Non dolor omnis qui ea corrupti vero eligendi reiciendis. Minus in animi repudiandae dolore quasi veritatis. Nobis pariatur alias quae tenetur rerum.','desa','Dr. Gage Goyette','2025-03-31 14:48:08','2025-01-25 18:19:01'),(58,29,'Dolor nobis numquam temporibus possimus ex autem. Ab veritatis aut consequuntur delectus. Est tempora voluptates quae et adipisci aut.','desa','Noel Deckow','2025-01-08 07:06:45','2025-03-21 15:48:13'),(59,14,'Quia dolor aut deserunt expedita eaque asperiores porro. Ratione qui minus et aliquid officiis tempora. Qui autem ipsam voluptatum nostrum. Omnis voluptates rerum necessitatibus omnis enim.','desa','Mr. Sebastian Kovacek V','2025-01-12 18:53:35','2025-01-14 17:34:50'),(60,45,'Molestiae deserunt deleniti ea eius hic vel. Nisi totam voluptas reprehenderit voluptatibus fugiat iusto. Porro eveniet et earum est error et.','desa','Prof. Vallie McLaughlin II','2025-02-07 17:12:12','2025-04-19 03:27:23'),(61,8,'Consequatur fugiat et labore. Architecto magni quo facere consectetur sunt dicta. Suscipit aliquam labore repellat animi aut sapiente voluptatem.','desa','Lura Block','2025-04-16 07:41:56','2025-04-20 06:27:43'),(62,45,'Nesciunt corrupti non assumenda eaque sed. Eius commodi labore quaerat ex iusto soluta. Id dolores quidem sit quam neque. Saepe autem similique sed et possimus dolores inventore aliquid.','desa','Libby Hirthe','2025-03-16 21:44:56','2025-03-02 03:15:09'),(63,43,'Est consequatur dolores libero excepturi aliquam. Ex officiis minus pariatur adipisci quo. Dolorem dicta impedit ea. Cum fugit tenetur ut reiciendis est error. Eaque culpa atque deserunt rerum et.','desa','Conor Howe','2025-03-18 20:31:32','2025-03-12 16:28:33'),(64,50,'Minima pariatur est aut ullam omnis voluptas ipsa et. Architecto totam qui est. Non nihil in ipsum dolor enim voluptas.','desa','Mr. Jovani Lowe Jr.','2025-02-10 19:46:47','2025-01-07 11:28:42'),(65,6,'Aut voluptate est qui sunt sed in. Cupiditate cupiditate nihil ab. Maxime cumque praesentium inventore cum quibusdam. Occaecati voluptatum libero eius minus.','desa','Ms. Corrine McDermott','2025-02-02 07:56:52','2025-01-19 07:52:55'),(66,4,'Voluptas atque dolorum est dicta odit repellendus. Necessitatibus quos magnam illum est consequatur consectetur.','desa','Dovie Von Jr.','2025-04-17 22:18:18','2025-03-09 22:29:59'),(67,43,'Aliquid non exercitationem quidem. Aut est officia dolorum. Dicta sapiente quia eius at non recusandae corporis. Alias saepe laborum sint error at consequatur ratione.','desa','Hettie Shanahan Jr.','2025-02-25 11:41:29','2025-04-09 17:41:22'),(68,35,'Nisi quis maxime tenetur. Et quo voluptatem libero enim doloremque iusto voluptates. Blanditiis consequatur nesciunt ex distinctio incidunt.','desa','Jalyn Turner','2025-01-19 10:55:46','2025-03-20 19:15:51'),(69,29,'Et perferendis officiis et nam omnis commodi et. Ipsa sit explicabo rerum laudantium animi ullam nostrum. Minus incidunt laboriosam modi sit.','desa','Lorenz Conn','2025-02-15 19:15:11','2025-01-10 21:57:12'),(70,15,'Quia minima cum sit vel eveniet blanditiis nostrum. Voluptatem non magnam beatae velit. Corporis qui dolorem nostrum minus quo ipsam et eum.','desa','Bret Hackett','2025-04-22 21:01:25','2025-03-16 17:51:51'),(71,32,'Consequatur labore aperiam dolorem provident dolorem. Quibusdam velit molestiae qui incidunt nihil. Laborum qui eaque harum quis voluptas iusto cupiditate. Minima eum autem repellendus non hic quos.','desa','Lilyan Walter','2025-01-21 04:15:06','2025-01-04 12:20:12'),(72,14,'Consequatur voluptatem autem cumque. Commodi hic dolorem enim aliquid. Necessitatibus vel sint qui blanditiis vero impedit.','desa','Bettye Price II','2025-03-30 14:14:06','2025-02-17 23:08:15'),(73,40,'Est velit ullam iure sit. Harum possimus autem quo ut ea tempore. Suscipit non ipsum et eligendi ut. Sed in rerum voluptas.','desa','Clementina Feest IV','2025-02-24 11:03:48','2025-02-18 03:46:28'),(74,9,'Quae dolore sunt facere accusamus ipsa ratione. Et hic velit commodi dicta totam ea deleniti.','desa','Prof. Rhett Runolfsdottir MD','2025-04-19 12:12:10','2025-01-26 22:46:00'),(75,47,'Aspernatur sit est odio perferendis. Autem voluptas et suscipit suscipit nesciunt pariatur sint animi. Et voluptas animi molestiae distinctio.','desa','Dave Stark','2025-03-15 07:43:15','2025-01-21 07:54:41'),(76,8,'Animi vitae blanditiis est earum odio. Rerum laudantium praesentium iusto debitis pariatur sint consectetur. Beatae tempore dolore eaque optio vel.','desa','Mr. Jed Howell Jr.','2025-01-21 13:03:56','2025-04-03 03:23:35'),(77,43,'Voluptatem corrupti ut sit doloremque mollitia nam. Eius minus in consequuntur nemo. Repellat ipsam recusandae asperiores et.','desa','Angela Kshlerin','2025-03-19 15:19:42','2025-04-10 02:08:37'),(78,6,'Voluptas recusandae vitae occaecati fuga magni doloremque rerum. Ipsum dicta quis aut sed. Et officia odio dolorum ut at. Fugit cum doloribus magni aliquam nihil qui quia.','desa','Torey Larkin','2025-01-26 22:08:30','2025-04-13 18:14:39'),(79,44,'Aut perspiciatis quos est maiores quam. Dolorem sit minima eveniet quia sit officiis fugiat sequi. Magni corrupti quia in autem et.','desa','Prof. Talon Dickens MD','2025-01-25 04:26:55','2025-01-17 21:49:22'),(80,8,'Nihil dolorem et similique maiores. Fugit aut voluptas quae nihil repellendus in aut. Qui libero id natus et. Unde et nemo quae provident tempora in vero natus. Eum vitae libero voluptatem.','desa','Princess McClure','2025-04-04 09:24:15','2025-04-07 04:38:54'),(81,47,'Enim sit occaecati voluptates ut ut ex id facere. Repellat quae quia illo eos velit ut expedita ducimus. Consectetur odio repudiandae omnis aut.','desa','Wilmer Fisher Jr.','2025-03-05 23:21:10','2025-01-10 20:47:31'),(82,35,'Cum aut sit magni pariatur. Et quis laborum aliquam accusantium perferendis. Officia velit magni tempora ipsam officiis libero ea. Et quibusdam ipsa enim illum voluptas nesciunt occaecati.','desa','Mr. Shad Welch','2025-02-04 06:19:15','2025-04-18 19:38:31'),(83,3,'Possimus at voluptate eligendi itaque. Facilis in aut ut nulla et.','desa','Mr. Dejon Larkin','2025-02-20 20:31:32','2025-03-04 02:53:33'),(84,35,'Error cumque qui in possimus modi in. Quam quo et aut deleniti dolorum. In voluptas vitae sed et.','desa','Sylvester Grady','2025-02-05 12:48:17','2025-03-14 11:35:46'),(85,50,'Quis quas sit sit et cupiditate sequi. Et corporis est blanditiis velit. Exercitationem corrupti ut aperiam perspiciatis exercitationem autem.','desa','Ms. Lenore Rodriguez','2025-03-16 11:20:37','2025-01-19 00:33:42'),(86,4,'Rem quidem commodi et saepe. Voluptatem et repellendus quas totam molestiae odio id. Qui ut et dolor est fugit.','desa','John Effertz','2025-04-01 12:37:38','2025-03-23 03:34:47'),(87,8,'Asperiores rerum et expedita aliquam sunt. Dignissimos iusto voluptatibus est est praesentium ipsa. Eum ut facere distinctio dolore ad dignissimos voluptatem.','desa','Patricia Kuphal','2025-03-15 09:41:19','2025-02-21 23:59:07'),(88,40,'Accusamus quasi nesciunt excepturi in est consequatur. Amet voluptas sunt et ut et. Sunt ut voluptatem harum eum.','desa','Aleen Funk Sr.','2025-03-14 07:55:13','2025-01-15 01:12:08'),(89,15,'Et a iste porro et. Ipsum quia odit magni voluptatibus doloribus id. Dolorem eum assumenda quia eius sed dolorum ipsam. Id deleniti nobis perspiciatis illum asperiores quisquam.','desa','Clovis Lakin','2025-02-15 00:44:08','2025-01-21 05:07:43'),(90,44,'Molestiae nulla facere aut amet deleniti. Qui tempore eos distinctio ut sunt quia. Et quis quidem vitae dolor quia accusamus excepturi voluptas. In placeat quaerat et cumque perferendis blanditiis.','desa','Lucious Powlowski','2025-03-08 12:43:26','2025-02-21 14:00:15'),(91,9,'Earum et dolore error autem modi cupiditate. Nihil quae hic voluptatem ipsum voluptatem vero nulla sunt. Et libero consequatur nobis eos consequatur.','desa','Prof. Pablo Bogan II','2025-02-17 01:56:40','2025-02-11 11:44:11'),(92,8,'Doloribus incidunt soluta vel dolores in ipsa. Facilis velit nihil nisi perferendis. Est dignissimos delectus vel tenetur porro commodi natus.','desa','Zetta Jakubowski IV','2025-03-02 13:39:04','2025-02-12 01:07:08'),(93,41,'Odio debitis quaerat quae quis aut rerum. Eum eos ut laboriosam. Vel et illo laudantium beatae itaque tempore. Inventore earum repellendus laudantium aut.','desa','Damaris Barton','2025-01-27 07:46:05','2025-02-12 21:17:57'),(94,9,'Sed veniam et optio fugit sint saepe. Quaerat aliquam culpa amet neque nisi nesciunt sint. Labore officia inventore eum quisquam quo illo rerum.','desa','Dr. Colton Heaney II','2025-01-20 02:58:54','2025-02-03 22:30:34'),(95,7,'Et assumenda rerum sed magnam ea dolores. Voluptatibus et similique perspiciatis qui qui aperiam non id. Veniam eveniet veritatis porro quis culpa consequuntur. Fuga modi harum ut numquam animi quo.','desa','Carrie Hudson','2025-02-13 00:52:30','2025-01-22 23:32:16'),(96,44,'Laudantium est officiis distinctio ducimus ab. Voluptatem architecto maxime pariatur ipsum. Porro similique quis fuga qui ut dolorem. Voluptatem recusandae tenetur repellendus error neque.','desa','Lucie Conn','2025-01-07 23:11:24','2025-02-03 14:23:54'),(97,17,'Voluptatum maxime eius quia ut. Saepe soluta rerum architecto. Libero magni est nemo quidem nulla sit. Magnam ut alias consequatur.','desa','Lowell Turcotte','2025-01-23 13:15:29','2025-04-15 23:10:25'),(98,7,'Aperiam voluptas suscipit qui ut voluptatem nihil. Sed nesciunt et amet dolor qui. Officia voluptatem soluta suscipit assumenda aut id et.','desa','Jalyn Nolan','2025-03-07 03:45:36','2025-03-02 13:27:37'),(99,9,'Sit quia sunt quibusdam dicta asperiores debitis doloribus. Alias aut eaque minima laboriosam non molestias. Sit adipisci dolor modi dolor accusantium.','desa','Mrs. Katelyn Morar I','2025-03-13 17:29:32','2025-01-18 12:00:33'),(100,7,'Laboriosam expedita molestiae porro debitis et cumque. Consequuntur quam voluptates fugiat doloremque pariatur veniam. Est reprehenderit quam odio quisquam. Similique voluptatem amet facere numquam.','desa','Garnet Lowe','2025-03-01 09:56:04','2025-02-25 18:24:45'),(101,35,'Delectus ea minus illum omnis nihil voluptatibus. Aut nihil nulla reiciendis reprehenderit. Aliquam beatae consequuntur est vel qui doloribus repellendus.','desa','Mrs. Eleanora Dietrich II','2025-04-14 14:04:56','2025-04-09 17:08:47'),(102,32,'Est officia placeat nemo maiores non. Molestias et porro est deserunt accusantium.','desa','Nico Parker','2025-01-20 08:36:10','2025-04-20 13:50:21'),(103,35,'Illo neque sint ratione molestias modi odio. Id voluptatum hic quidem ratione. A veniam laborum accusamus vero ut quidem odit aut. Vitae et unde deserunt autem optio.','desa','Chelsie Jakubowski','2025-03-22 07:27:06','2025-02-02 11:20:58'),(104,8,'Nihil sint magnam quidem blanditiis illum debitis voluptatem. Sit explicabo illum animi numquam. Cumque molestiae harum laudantium beatae. Id ducimus et odio non ut.','desa','Felicita Kozey I','2025-02-23 07:43:37','2025-01-21 07:58:55'),(105,32,'Blanditiis omnis aspernatur sequi quidem est quis est necessitatibus. Mollitia aliquam in harum. Distinctio et corrupti iusto et laudantium a.','desa','Chris Heidenreich','2025-04-20 00:58:45','2025-04-07 23:58:05'),(106,47,'Ducimus architecto dolorem omnis. Sunt rem esse quaerat reprehenderit. Illum dolorem suscipit facilis exercitationem vitae cupiditate voluptatum. Provident fugit sit veniam consectetur.','desa','Audie Thiel','2025-03-07 08:22:31','2025-03-11 13:11:29'),(107,4,'Est quibusdam veritatis est quis quae nihil. Aliquid est adipisci quo ipsam aperiam omnis rerum. Doloribus et est facilis rerum fugiat hic. Facere quo quos delectus suscipit.','desa','Dagmar Friesen','2025-02-11 03:16:30','2025-02-16 06:03:35'),(108,35,'Quae voluptas aut in minima. Eos repudiandae est dolores. Commodi quos porro et quia. Beatae iste voluptatum quae recusandae consequatur explicabo.','desa','Ms. Della Hyatt DDS','2025-01-26 04:12:25','2025-02-17 23:36:27'),(109,32,'Porro eligendi nemo sint aut. Velit rerum est aut magnam ea quas enim sequi. Et explicabo sit placeat voluptates provident consectetur aut soluta.','desa','Claudie Brakus','2025-03-15 16:59:58','2025-02-14 05:44:15'),(110,47,'Laudantium qui est harum natus vel accusamus. Libero voluptates quia est pariatur iure sequi sint similique. Architecto et corporis ad omnis accusantium.','desa','Mollie Ferry DVM','2025-03-23 08:38:12','2025-03-10 10:20:02'),(111,8,'Optio et provident commodi ut nihil explicabo qui similique. Laborum quia aut cum fuga et. Magnam aut ea repudiandae rerum et unde hic hic. Ea aut in ut et laudantium et.','desa','Mustafa Casper','2025-02-24 02:55:35','2025-01-06 18:19:54'),(112,40,'Cumque amet eos aperiam quo eveniet ex quam deleniti. Earum ullam earum rem officia. Et placeat sit voluptatem dolore.','desa','Curtis Mertz','2025-01-14 04:08:26','2025-01-14 21:30:04'),(113,40,'Sapiente sapiente commodi unde qui harum. Corrupti ut nesciunt illo dolore. Neque unde non id dolorum non temporibus iusto.','desa','Mr. Sanford Gulgowski V','2025-01-09 06:24:22','2025-02-27 20:40:20'),(114,45,'Inventore beatae aperiam culpa aliquid. Est alias mollitia quos voluptatibus ut id. Praesentium eos reiciendis est molestias mollitia iure. In possimus consectetur maiores facere.','desa','Enid Brown I','2025-04-23 04:24:34','2025-04-18 06:37:09'),(115,47,'Quas dolores rerum facere expedita officia sed. Non repellat ut doloremque voluptatem perspiciatis. Cupiditate placeat quia quibusdam unde. Quis iste quo aut est sed est excepturi.','desa','Dr. Nigel Connelly I','2025-03-11 09:01:18','2025-04-04 05:07:12'),(116,6,'Eum quae accusamus voluptatem sed aliquam. Sit aperiam voluptatum provident aliquid.','desa','Dr. Sheridan Bruen III','2025-03-03 23:35:16','2025-03-03 09:02:34'),(117,50,'Ab deserunt sint quae corrupti ducimus eveniet. Nisi illo quia quia suscipit iste dignissimos. Minima quidem labore harum velit corrupti nam.','desa','Fannie Wiza','2025-04-14 03:27:13','2025-02-06 21:50:44'),(118,9,'Doloremque corporis accusamus ducimus dolor vel repudiandae. Aut neque minima delectus quis eos. Non officia nihil commodi veritatis.','desa','Wilhelmine Christiansen','2025-03-09 05:06:48','2025-04-01 07:00:22'),(119,41,'Ab et aliquid itaque et. Nemo est consequatur minus ab. Eligendi voluptates explicabo quas qui omnis fugit.','desa','Mrs. Maurine Koelpin Jr.','2025-04-19 00:06:22','2025-01-30 15:38:15'),(120,32,'Qui repudiandae sunt fuga qui. Aut expedita molestiae voluptas et omnis. Repellendus et pariatur corrupti nihil.','desa','Katelyn Wisozk','2025-03-22 08:31:50','2025-02-16 19:30:06'),(121,35,'A sequi non nihil excepturi dolore. Porro aut id qui et nostrum. Perspiciatis tempore illum consequatur dolorem possimus tenetur qui. Numquam eius veritatis aut non odit amet.','desa','Bonita Hansen','2025-01-08 02:44:02','2025-04-21 15:23:48'),(122,4,'Doloribus eos rerum consequatur voluptas expedita. Occaecati error sed non sint adipisci dolorem culpa. Sapiente nostrum architecto cupiditate et dolorem omnis.','desa','Lue Quitzon','2025-04-14 14:31:25','2025-01-26 13:24:42'),(123,43,'Et et minima quidem nostrum repellendus reiciendis. Illo voluptatum dolor reiciendis eius aut. Sint natus tempore vitae et et porro cupiditate.','desa','Ms. Millie Wintheiser III','2025-01-02 21:26:06','2025-04-14 12:18:50'),(124,10,'Ex illo fugit et quia quos itaque. Maiores repellat modi impedit tenetur sequi. Dolores voluptatibus eos tempora. Autem nam laboriosam sint et ducimus non itaque.','desa','Ms. Aimee Kirlin IV','2025-02-13 14:39:08','2025-01-17 02:43:40'),(125,41,'Quis doloremque quaerat officiis dicta ad exercitationem. Consequatur qui ratione voluptatem quos in vel animi. Sunt adipisci iure qui minima veritatis quia aliquam.','desa','Prof. Alysson Hermann','2025-01-16 05:04:16','2025-04-13 15:38:08'),(126,8,'Quis blanditiis debitis sed illo rem perferendis. Saepe assumenda aperiam autem perspiciatis. Vel in consequatur voluptas et quia consequatur ab dolores.','desa','Prof. Eino Klocko','2025-03-18 11:00:21','2025-01-14 19:48:31'),(127,17,'Ducimus beatae reiciendis aut porro aliquid numquam. Saepe ipsa ut sed ratione praesentium quasi. Veritatis explicabo facilis iste aliquam qui voluptate.','desa','Noe Lemke','2025-02-02 22:24:05','2025-04-02 10:54:34'),(128,10,'Enim rerum culpa iure aut nihil maiores. Dolor laudantium consequatur necessitatibus facilis. Eveniet nam molestias quia dolor laboriosam. Qui ipsam at quos sapiente doloribus.','desa','Mr. Mario Lemke PhD','2025-01-02 06:08:55','2025-01-13 09:05:02'),(129,9,'Itaque vel cumque voluptas facilis. Excepturi et vero mollitia autem voluptas vel quas. Beatae quae dolorem ut rerum quis dolorem autem ea.','desa','Shakira Stehr','2025-04-01 09:32:39','2025-04-07 19:30:23'),(130,15,'Voluptatem dolorum placeat fugit qui vel consectetur. Sed odit non ea ipsam saepe quis blanditiis. Quam ea est blanditiis nihil.','desa','Dr. Keven Abbott','2025-02-16 03:53:39','2025-02-25 16:20:37'),(131,3,'Sunt quo dolores aut quibusdam ipsa. Aut suscipit neque quibusdam iure esse amet et. Sed ipsum voluptatibus doloribus distinctio atque fugiat eos.','desa','Amely Mohr','2025-03-19 06:56:10','2025-03-21 13:35:52'),(132,32,'Eum autem ad voluptatem quae. Consequatur dolor pariatur adipisci qui nisi aliquid molestiae. Quibusdam eos excepturi consequatur qui id quia quod.','desa','Lyda Upton I','2025-01-19 13:11:00','2025-03-14 02:25:10'),(133,10,'Officia nihil nesciunt rem aut placeat eius. Ipsum sunt nulla inventore officia. Expedita voluptates atque sit molestiae.','desa','Dr. Sabrina Upton IV','2025-03-03 10:41:33','2025-03-23 07:00:22'),(134,8,'Saepe aut tempore rem et ex. Et ut expedita maiores illum consequuntur laudantium quo.','desa','Mr. Marc Stehr PhD','2025-04-18 06:18:44','2025-01-21 15:11:36'),(135,8,'Necessitatibus temporibus aliquid magni. Qui debitis doloribus in quasi repellat atque deserunt quibusdam. Adipisci sed non molestias.','desa','Madilyn Price','2025-02-03 15:57:21','2025-01-15 21:59:16'),(136,7,'Voluptas ut ut harum aut quidem dolorem. Atque ut dolore odio qui. Facilis quia dignissimos ut temporibus. Natus voluptatibus sint fuga.','desa','Mr. Morton Schuppe','2025-01-22 03:07:43','2025-04-02 09:48:02'),(137,47,'Debitis reiciendis nemo est nesciunt praesentium. Repudiandae molestiae quae incidunt atque qui porro molestiae. Modi consequuntur quia atque omnis sint voluptatem ut.','desa','Daren Emard','2025-03-17 06:00:37','2025-04-12 16:29:10'),(138,8,'Deleniti deleniti architecto necessitatibus et est. Alias rem eum praesentium dicta.','desa','Amani Fay','2025-01-26 21:10:42','2025-04-01 11:57:37'),(139,15,'In deserunt est alias ea quia nostrum. Explicabo laborum sit tempore et repudiandae impedit autem. Eum vel unde quidem quisquam. Ex eius voluptatibus quos.','desa','Leilani Greenholt IV','2025-03-03 13:19:35','2025-04-06 22:03:51'),(140,45,'Ea odio eius enim et tempora rerum iste. Sunt magnam autem dolorem deserunt. Est ab qui aut ut fugit eos.','desa','Winnifred Quitzon','2025-01-17 18:37:09','2025-01-30 01:05:15'),(141,35,'Debitis ut voluptates nihil debitis. Veniam quia nihil architecto in temporibus a rem velit.','desa','Martin Bednar','2025-02-27 20:13:27','2025-01-08 04:36:28'),(142,41,'Reiciendis unde maiores corrupti ut vero. Repudiandae sunt voluptate laudantium recusandae dolorem sed atque aliquam. Voluptatem et provident ut sint nihil alias et. Dolore voluptatibus a aut velit.','desa','Raleigh Lind','2025-01-18 23:25:26','2025-02-06 18:24:25'),(143,32,'Consequatur voluptatum ab in eum corporis eveniet sed. Ex enim voluptatibus et molestiae maiores nulla eos. Et magni ipsum aut ut repudiandae dolorem temporibus.','desa','Sherman Kozey','2025-01-23 02:15:08','2025-02-03 05:58:15'),(144,10,'Amet laudantium accusantium optio enim repellendus ex esse. Vel iure accusamus at eveniet provident voluptatem. Autem tempore omnis qui aperiam modi. Perspiciatis placeat quia porro eligendi id.','desa','Prof. Gay Towne III','2025-04-20 08:06:51','2025-03-04 14:55:57'),(145,47,'Quibusdam sit earum qui dolorem. Qui aut omnis est mollitia. Officiis corporis expedita ea eum nam sed ducimus. Voluptatem eos voluptas et atque vel.','desa','Dakota O\'Connell','2025-03-24 16:26:01','2025-03-19 22:43:24'),(146,41,'Voluptatem quos est doloribus optio perspiciatis et. Rem voluptate similique est deleniti aperiam soluta nostrum. Et odio est repellat est non ipsam cumque.','desa','Dr. Jayme Yost','2025-03-04 07:45:33','2025-04-17 21:45:06'),(147,29,'Quas cumque voluptatum sapiente dignissimos. Neque id illum ut aut dolores aut qui. Ea vel reiciendis tenetur.','desa','Zella Cremin DVM','2025-03-01 14:02:54','2025-01-27 21:43:05'),(148,14,'Voluptatem ut molestiae numquam repellendus facilis ratione qui. Eligendi ratione consequatur qui voluptatem consequuntur. Delectus aut qui tempore qui quisquam cupiditate.','desa','Bruce Lueilwitz','2025-03-28 03:31:43','2025-01-09 00:51:47'),(149,29,'Voluptatum eaque est corrupti dolorem necessitatibus culpa maxime. Et aut quia fuga architecto voluptas. Aut omnis qui doloribus consequuntur temporibus mollitia aperiam. Occaecati et hic nesciunt.','desa','Cordie Gusikowski','2025-04-06 22:52:41','2025-04-21 16:28:22'),(150,41,'Quibusdam voluptatem et et vel praesentium exercitationem praesentium. Aut est cum ut nisi pariatur.','desa','Winona Mertz','2025-03-06 05:34:57','2025-04-13 14:04:12');
/*!40000 ALTER TABLE `das_pesan_detail` ENABLE KEYS */;

--
-- Table structure for table `das_peserta_program`
--

DROP TABLE IF EXISTS `das_peserta_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_peserta_program` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `peserta` char(16) NOT NULL,
  `program_id` int(11) NOT NULL,
  `sasaran` tinyint(3) unsigned DEFAULT NULL,
  `no_id_kartu` varchar(100) DEFAULT NULL,
  `kartu_nik` char(16) DEFAULT NULL,
  `kartu_nama` varchar(100) DEFAULT NULL,
  `kartu_tempat_lahir` varchar(100) DEFAULT NULL,
  `kartu_tanggal_lahir` date DEFAULT NULL,
  `kartu_alamat` varchar(200) DEFAULT NULL,
  `kartu_peserta` varchar(100) DEFAULT NULL,
  `desa_id` char(13) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_peserta_program`
--

/*!40000 ALTER TABLE `das_peserta_program` DISABLE KEYS */;
INSERT INTO `das_peserta_program` VALUES (1,'5201140105136997',1,2,'1','5201143112797117','DAHRI','MASBAGIK','1978-12-31','RT 003  RW - Dusun Loco',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(2,'5201140104126994',1,2,'2','5201142005716996','AHLUL','MANGSIT','1970-05-20','RT 004  RW - Dusun Mangsit',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(3,'5201140104126995',2,2,'1','5201141003666996','AHYAR','JAKARTA','1965-03-10','RT 001  RW - Dusun Senggigi',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(4,'5201140105136997',2,2,'2','5201143112797117','DAHRI','MASBAGIK','1978-12-31','RT 003  RW - Dusun Loco',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(5,'5201140104126995',3,2,'1','5201141003666996','AHYAR','JAKARTA','1965-03-10','RT 001  RW - Dusun Senggigi',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(6,'5201140105136997',3,2,'2','5201143112797117','DAHRI','MASBAGIK','1978-12-31','RT 003  RW - Dusun Loco',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(7,'5201140104166999',4,2,'1','5201140107867064','ASHARI','KERANDANGAN','1985-12-30','RT 002  RW - Dusun Kerandangan',NULL,'53.06.13.2001','2025-04-23 08:02:15','2025-04-23 08:02:15'),(8,'5201140105136997',4,2,'2','5201143112797117','DAHRI','MASBAGIK','1978-12-31','RT 003  RW - Dusun Loco',NULL,'53.06.13.2001','2025-04-23 08:02:16','2025-04-23 08:02:16'),(9,'5201142005716996',5,1,'1','5201142005716996','AHLUL','MANGSIT','1970-05-20','RT 004  RW - Dusun Mangsit',NULL,'53.06.13.2001','2025-04-23 08:02:16','2025-04-23 08:02:16'),(10,'5201140706966997',5,1,'2','5201140706966997','AHMAD ALLIF RIZKI','MANGSIT','1995-06-07','RT 004  RW - Dusun Mangsit',NULL,'53.06.13.2001','2025-04-23 08:02:16','2025-04-23 08:02:16');
/*!40000 ALTER TABLE `das_peserta_program` ENABLE KEYS */;

--
-- Table structure for table `das_potensi`
--

DROP TABLE IF EXISTS `das_potensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_potensi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `kategori_id` int(11) NOT NULL,
  `nama_potensi` varchar(200) NOT NULL,
  `deskripsi` text NOT NULL,
  `lokasi` varchar(200) NOT NULL,
  `file_gambar` varchar(255) DEFAULT NULL,
  `long` decimal(15,12) DEFAULT NULL,
  `lat` decimal(15,12) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_potensi`
--

/*!40000 ALTER TABLE `das_potensi` DISABLE KEYS */;
INSERT INTO `das_potensi` VALUES (1,1,'Potensi 1','Deskripsi potensi 1','Lokasi potensi 1','/img/no-image.png',NULL,NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26'),(2,1,'Potensi 2','Deskripsi potensi 2','Lokasi potensi 2','/img/no-image.png',NULL,NULL,'2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_potensi` ENABLE KEYS */;

--
-- Table structure for table `das_profil`
--

DROP TABLE IF EXISTS `das_profil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_profil` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `provinsi_id` char(2) DEFAULT NULL,
  `nama_provinsi` varchar(255) DEFAULT NULL,
  `kabupaten_id` char(5) DEFAULT NULL,
  `nama_kabupaten` varchar(255) DEFAULT NULL,
  `kecamatan_id` char(8) DEFAULT NULL,
  `nama_kecamatan` varchar(255) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `kode_pos` char(12) DEFAULT NULL,
  `telepon` char(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `tahun_pembentukan` int(11) DEFAULT NULL,
  `dasar_pembentukan` varchar(50) DEFAULT NULL,
  `nama_camat` varchar(150) DEFAULT NULL,
  `sekretaris_camat` varchar(150) DEFAULT NULL,
  `kepsek_pemerintahan_umum` varchar(150) DEFAULT NULL,
  `kepsek_kesejahteraan_masyarakat` varchar(150) DEFAULT NULL,
  `kepsek_pemberdayaan_masyarakat` varchar(150) DEFAULT NULL,
  `kepsek_pelayanan_umum` varchar(150) DEFAULT NULL,
  `kepsek_trantib` varchar(150) DEFAULT NULL,
  `file_struktur_organisasi` varchar(255) DEFAULT NULL,
  `file_logo` varchar(255) DEFAULT NULL,
  `visi` longtext DEFAULT NULL,
  `misi` longtext DEFAULT NULL,
  `foto_kepala_wilayah` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `sambutan` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_profil`
--

/*!40000 ALTER TABLE `das_profil` DISABLE KEYS */;
INSERT INTO `das_profil` VALUES (1,'51','BALI','51.02','TABANAN','51.02.06','Kediri','Jl. Koperasi No. 1, Kab Tabanan ','83653','0212345234','admin@mail.com',2025,'PEREGUB No 4 1990','H. Hadi Fathurrahman, S.Sos, M.AP','Drs. Zaenal Abidin','Musyayad, S.Sos','Suhartono, S.Sos','Asrarudin, SE','Masturi, ST','Mastur Idris, SH',NULL,NULL,'<p>Ini adalah kalimat visi</p>','<p>Ini adalah kalimat visi</p>',NULL,'2025-04-23 08:02:12','2025-04-23 08:02:12',NULL);
/*!40000 ALTER TABLE `das_profil` ENABLE KEYS */;

--
-- Table structure for table `das_program`
--

DROP TABLE IF EXISTS `das_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_program` (
  `id` int(10) unsigned NOT NULL,
  `nama` varchar(100) NOT NULL,
  `sasaran` tinyint(3) unsigned DEFAULT NULL,
  `desa_id` char(13) DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `das_program_id_desa_id_unique` (`id`,`desa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_program`
--

/*!40000 ALTER TABLE `das_program` DISABLE KEYS */;
INSERT INTO `das_program` VALUES (1,'BPNT',2,'53.06.13.2001',NULL,'2015-12-13','2021-12-13','Program KESOS memberi bantuan sosial pangan dalam bentuk non tunai dari pemerintah yang diberikan kepada KPM setiap bulannya melalui mekanisme akun elektronik yang digunakan hanya untuk membeli bahan pangan di pedagang bahan pangan/e-warong yang bekerjasama dengan bank.','2025-04-23 08:02:15','2025-04-23 08:02:15'),(2,'BLSM',2,'53.06.13.2001',NULL,'2015-12-13','2017-12-13','Bantuan Langsung Sementara Masyarakat atau BLSM (kadang disebut juga balsem) adalah bantuan yang diberikan Pemerintah Indonesia menyambut kenaikan harga BBM yang terjadi pada 22 Juni 2013 pada jam 00.00','2025-04-23 08:02:15','2025-04-23 08:02:15'),(3,'PKH',2,'53.06.13.2001',1,'2015-12-13','2022-12-13','Program Keluarga Harapan yang selanjutnya disebut PKH adalah program pemberian bantuan sosial bersyarat kepada Keluarga Miskin (KM) yang ditetapkan sebagai keluarga penerima manfaat PKH.\n\nSebagai sebuah program bantuan sosial bersyarat, PKH membuka akses keluarga miskin terutama ibu hamil dan anak untuk memanfaatkan berbagai fasilitas layanan kesehatan (faskes) dan fasilitas layanan pendidikan (fasdik) yang tersedia di sekitar mereka.','2025-04-23 08:02:15','2025-04-23 08:02:15'),(4,'Bedah Rumah',2,'53.06.13.2001',NULL,'2015-12-13','2021-12-13','Bantuan Stimulan Perumahan Swadaya (BSPS). Program ini lebih dikenal sebagai program Bedah Rumah.\n\nKementrian Pekerjaan Umum dan Perumahan Rakyat (KemenPUPR) menjalankan BSPS untuk membantu Masyarakat Berpenghasilan Rendah (MBR), agar dapat memiliki rumah yang layak huni.','2025-04-23 08:02:15','2025-04-23 08:02:15'),(5,'JAMKESMAS',1,'53.06.13.2001',NULL,'2008-12-13','2010-12-13','Jamkesmas ( akronim dari Jaminan Kesehatan Masyarakat ) adalah sebuah program jaminan kesehatan untuk warga Indonesia yang memberikan perlindungan sosial dibidang kesehatan untuk menjamin masyarakat miskin dan tidak mampu yang iurannya dibayar oleh pemerintah agar kebutuhan dasar kesehatannya yang layak dapat terpenuhi.Program ini dijalankan oleh Departemen Kesehatan sejak 2008.','2025-04-23 08:02:15','2025-04-23 08:02:15');
/*!40000 ALTER TABLE `das_program` ENABLE KEYS */;

--
-- Table structure for table `das_prosedur`
--

DROP TABLE IF EXISTS `das_prosedur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_prosedur` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `judul_prosedur` varchar(150) NOT NULL,
  `slug` char(150) NOT NULL,
  `file_prosedur` varchar(255) NOT NULL,
  `mime_type` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_prosedur`
--

/*!40000 ALTER TABLE `das_prosedur` DISABLE KEYS */;
INSERT INTO `das_prosedur` VALUES (1,'Prosedur 1','prosedur-1','storage/template_upload/Panduan_Pengguna_Kecamatan_Dashboard.pdf','pdf','2025-04-23 08:03:26','2025-04-23 08:03:26'),(2,'Prosedur 2','prosedur-2','storage/template_upload/Panduan_Pengguna_Kecamatan_Dashboard.pdf','pdf','2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_prosedur` ENABLE KEYS */;

--
-- Table structure for table `das_putus_sekolah`
--

DROP TABLE IF EXISTS `das_putus_sekolah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_putus_sekolah` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `semester` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `siswa_paud` int(11) NOT NULL,
  `anak_usia_paud` int(11) NOT NULL,
  `siswa_sd` int(11) NOT NULL,
  `anak_usia_sd` int(11) NOT NULL,
  `siswa_smp` int(11) NOT NULL,
  `anak_usia_smp` int(11) NOT NULL,
  `siswa_sma` int(11) NOT NULL,
  `anak_usia_sma` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_putus_sekolah`
--

/*!40000 ALTER TABLE `das_putus_sekolah` DISABLE KEYS */;
INSERT INTO `das_putus_sekolah` VALUES (1,'53.06.13.2001',1,2025,34,23,44,45,3,2,45,3,'2025-04-23 08:02:16','2025-04-23 08:02:16');
/*!40000 ALTER TABLE `das_putus_sekolah` ENABLE KEYS */;

--
-- Table structure for table `das_regulasi`
--

DROP TABLE IF EXISTS `das_regulasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_regulasi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `profil_id` int(11) DEFAULT 1,
  `tipe_regulasi` varchar(30) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `deskripsi` text NOT NULL,
  `file_regulasi` varchar(255) NOT NULL,
  `mime_type` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_regulasi`
--

/*!40000 ALTER TABLE `das_regulasi` DISABLE KEYS */;
INSERT INTO `das_regulasi` VALUES (1,1,'2','Regulasi 1','Deskripsi regulasi 1','storage/template_upload/Panduan_Pengguna_Kecamatan_Dashboard.pdf','pdf','2025-04-23 08:03:26','2025-04-23 08:03:26'),(2,1,'2','Regulasi 2','Deskripsi regulasi 2','storage/template_upload/Panduan_Pengguna_Kecamatan_Dashboard.pdf','pdf','2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_regulasi` ENABLE KEYS */;

--
-- Table structure for table `das_setting`
--

DROP TABLE IF EXISTS `das_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_setting` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `type` varchar(30) NOT NULL,
  `description` varchar(200) NOT NULL,
  `kategori` varchar(200) NOT NULL,
  `option` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_setting_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_setting`
--

/*!40000 ALTER TABLE `das_setting` DISABLE KEYS */;
INSERT INTO `das_setting` VALUES (1,'judul_aplikasi','Kecamatan','input','Judul halaman aplikasi.','sistem','{}'),(2,'artikel_kecamatan_perhalaman','10','number','Jumlah artikel kecamatan dalam satu halaman yang ditampilkan','web','{}'),(3,'artikel_desa_perhalaman','10','number','Jumlah artikel desa dalam satu halaman yang ditampilkan','web','{}'),(4,'jumlah_artikel_desa','150','number','Jumlah semua artikel desa yang ditampilkan','web','{}'),(5,'tte','0','boolean','Mengaktifkan modul TTE','surat','{}'),(6,'tte_api','','input','URL API TTE','surat','{}'),(7,'tte_username','','input','Username API TTE','surat','{}'),(8,'tte_password','','input','Password API TTE','surat','{}'),(9,'pemeriksaan_camat','0','boolean','Mengaktifkan pemeriksaan camat pada alur pemeriksaan surat','surat','{}'),(10,'pemeriksaan_sekretaris','0','boolean','Mengaktifkan pemeriksaan sekretaris pada alur pemeriksaan surat','surat','{}'),(11,'mode_maintenance','0','boolean','Mode maintenance.','web','{}'),(12,'sinkronisasi_database_gabungan','1','boolean','Aktifkan Sinkronisasi ke Database Gabungan.','sinkronisasi','{}'),(13,'api_server_database_gabungan','http://127.0.0.1:8001','input','Alamat Server Database Gabungan.','sinkronisasi','{}'),(14,'api_key_database_gabungan','17|Bbzi6EToVLxftRuZ136kgfXBEaPpY0a8iqzgzXIc818dbd36','textarea','API Key Untuk Sinkronisasi Data Dari Database Gabungan.','sinkronisasi','{}'),(15,'api_key_opendk','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjgwMDAvc2V0dGluZy9hcGxpa2FzaS90b2tlbiIsImlhdCI6MTczNzE1Mzc3MCwiZXhwIjoyMDUyNTEzNzcwLCJuYmYiOjE3MzcxNTM3NzAsImp0aSI6Ik5FVTE1d2RhU1doOFg1RXYiLCJzdWIiOiIxIiwicHJ2IjoiMjNiZDVjODk0OWY2MDBhZGIzOWU3MDFjNDAwODcyZGI3YTU5NzZmNyJ9.YfM3I5ovN52-pnGiqc2CHtLSOduEdMviuROn2A0tWtw','textarea','OpenDK API Key Untuk Sinkronisasi Data.','sinkronisasi','{\"readonly\":true}'),(18,'login_2fa','0','boolean','Aktifkan login dengan 2FA.','sistem','{}'),(19,'google_recaptcha','0','boolean','Gunakan Aktif untuk Google reCAPTCHA atau Tidak Aktif untuk reCAPTCHA bawaan sistem','sistem','{}');
/*!40000 ALTER TABLE `das_setting` ENABLE KEYS */;

--
-- Table structure for table `das_sinergi_program`
--

DROP TABLE IF EXISTS `das_sinergi_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_sinergi_program` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) NOT NULL,
  `url` text NOT NULL,
  `nama` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `urutan` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_sinergi_program`
--

/*!40000 ALTER TABLE `das_sinergi_program` DISABLE KEYS */;
INSERT INTO `das_sinergi_program` VALUES (1,'/img/opendesa.png','https://opendesa.id/','Open Desa',1,1,'2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_sinergi_program` ENABLE KEYS */;

--
-- Table structure for table `das_suplemen`
--

DROP TABLE IF EXISTS `das_suplemen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_suplemen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `sasaran` tinyint(1) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `das_suplemen_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_suplemen`
--

/*!40000 ALTER TABLE `das_suplemen` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_suplemen` ENABLE KEYS */;

--
-- Table structure for table `das_suplemen_terdata`
--

DROP TABLE IF EXISTS `das_suplemen_terdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_suplemen_terdata` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suplemen_id` int(10) unsigned NOT NULL,
  `penduduk_id` int(10) unsigned NOT NULL,
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `das_suplemen_terdata_suplemen_id_foreign` (`suplemen_id`),
  KEY `das_suplemen_terdata_penduduk_id_foreign` (`penduduk_id`),
  CONSTRAINT `das_suplemen_terdata_penduduk_id_foreign` FOREIGN KEY (`penduduk_id`) REFERENCES `das_penduduk` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `das_suplemen_terdata_suplemen_id_foreign` FOREIGN KEY (`suplemen_id`) REFERENCES `das_suplemen` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_suplemen_terdata`
--

/*!40000 ALTER TABLE `das_suplemen_terdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_suplemen_terdata` ENABLE KEYS */;

--
-- Table structure for table `das_themes`
--

DROP TABLE IF EXISTS `das_themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_themes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `vendor` varchar(191) NOT NULL,
  `version` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `path` varchar(191) NOT NULL,
  `screenshot` varchar(191) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `system` tinyint(1) NOT NULL DEFAULT 0,
  `options` mediumtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_themes`
--

/*!40000 ALTER TABLE `das_themes` DISABLE KEYS */;
INSERT INTO `das_themes` VALUES (1,'default','opendk','1.0.0','Tema bawaan OpenDK','/data/docker/opendesa/OpenDK/themes/opendk/default/','http://localhost:8000/themes/opendk/default/screenshot.png',1,1,NULL,'2025-04-23 08:02:04','2025-04-23 08:04:56');
/*!40000 ALTER TABLE `das_themes` ENABLE KEYS */;

--
-- Table structure for table `das_tingkat_pendidikan`
--

DROP TABLE IF EXISTS `das_tingkat_pendidikan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_tingkat_pendidikan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `semester` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `tidak_tamat_sekolah` int(11) NOT NULL DEFAULT 0,
  `tamat_sd` int(11) NOT NULL DEFAULT 0,
  `tamat_smp` int(11) NOT NULL DEFAULT 0,
  `tamat_sma` int(11) NOT NULL DEFAULT 0,
  `tamat_diploma_sederajat` int(11) NOT NULL DEFAULT 0,
  `import_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_tingkat_pendidikan`
--

/*!40000 ALTER TABLE `das_tingkat_pendidikan` DISABLE KEYS */;
INSERT INTO `das_tingkat_pendidikan` VALUES (1,'53.06.13.2001',1,2025,34,23,12,11,3,1,'2025-04-23 01:02:16','2025-04-23 01:02:16');
/*!40000 ALTER TABLE `das_tingkat_pendidikan` ENABLE KEYS */;

--
-- Table structure for table `das_tipe_potensi`
--

DROP TABLE IF EXISTS `das_tipe_potensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_tipe_potensi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(40) NOT NULL,
  `slug` varchar(40) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_tipe_potensi`
--

/*!40000 ALTER TABLE `das_tipe_potensi` DISABLE KEYS */;
INSERT INTO `das_tipe_potensi` VALUES (1,'Kategori 1','kategori-1','2025-04-23 08:03:26','2025-04-23 08:03:26'),(2,'Kategori 2','kategori-2','2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `das_tipe_potensi` ENABLE KEYS */;

--
-- Table structure for table `das_tipe_regulasi`
--

DROP TABLE IF EXISTS `das_tipe_regulasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_tipe_regulasi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_tipe_regulasi`
--

/*!40000 ALTER TABLE `das_tipe_regulasi` DISABLE KEYS */;
INSERT INTO `das_tipe_regulasi` VALUES (2,'Regulasi Nasional','regulasi-nasional','2018-04-25 19:26:51','2018-04-25 19:26:51'),(3,'Regulasi Daerah','regulasi-daerah','2018-04-25 19:27:00','2018-04-25 19:27:00');
/*!40000 ALTER TABLE `das_tipe_regulasi` ENABLE KEYS */;

--
-- Table structure for table `das_toilet_sanitasi`
--

DROP TABLE IF EXISTS `das_toilet_sanitasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_toilet_sanitasi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `desa_id` char(13) NOT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `toilet` int(11) NOT NULL,
  `sanitasi` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_toilet_sanitasi`
--

/*!40000 ALTER TABLE `das_toilet_sanitasi` DISABLE KEYS */;
INSERT INTO `das_toilet_sanitasi` VALUES (1,'53.06.13.2001',4,2025,12,34,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(2,'53.06.13.2002',4,2025,3,44,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(3,'53.06.13.2003',4,2025,67,12,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(4,'53.06.13.2004',4,2025,3,3,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(5,'53.06.13.2005',4,2025,34,67,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(6,'53.06.13.2006',4,2025,44,3,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(7,'53.06.13.2007',4,2025,12,3,'2025-04-23 08:02:16','2025-04-23 08:02:16'),(8,'53.06.13.2008',4,2025,6,3,'2025-04-23 08:02:16','2025-04-23 08:02:16');
/*!40000 ALTER TABLE `das_toilet_sanitasi` ENABLE KEYS */;

--
-- Table structure for table `das_wil_clusterdesa`
--

DROP TABLE IF EXISTS `das_wil_clusterdesa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `das_wil_clusterdesa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rt` varchar(10) DEFAULT NULL,
  `rw` varchar(10) DEFAULT NULL,
  `dusun` varchar(50) DEFAULT NULL,
  `id_kepala` int(11) DEFAULT NULL,
  `lat` varchar(20) DEFAULT NULL,
  `lng` varchar(20) DEFAULT NULL,
  `zoom` int(11) DEFAULT NULL,
  `path` text DEFAULT NULL,
  `map_tipe` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `das_wil_clusterdesa`
--

/*!40000 ALTER TABLE `das_wil_clusterdesa` DISABLE KEYS */;
/*!40000 ALTER TABLE `das_wil_clusterdesa` ENABLE KEYS */;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

--
-- Table structure for table `galeris`
--

DROP TABLE IF EXISTS `galeris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `galeris` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` bigint(20) unsigned NOT NULL,
  `judul` varchar(191) NOT NULL,
  `gambar` text DEFAULT NULL,
  `link` varchar(191) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0=tidak aktif, 1=aktif',
  `jenis` enum('file','url') NOT NULL DEFAULT 'file',
  `slug` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `galeris_slug_unique` (`slug`),
  KEY `galeris_album_id_foreign` (`album_id`),
  CONSTRAINT `galeris_album_id_foreign` FOREIGN KEY (`album_id`) REFERENCES `albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galeris`
--

/*!40000 ALTER TABLE `galeris` DISABLE KEYS */;
/*!40000 ALTER TABLE `galeris` ENABLE KEYS */;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;

--
-- Table structure for table `kategoris`
--

DROP TABLE IF EXISTS `kategoris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kategoris` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(191) NOT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategoris`
--

/*!40000 ALTER TABLE `kategoris` DISABLE KEYS */;
INSERT INTO `kategoris` VALUES (1,'Kebijakan Publik','kebijakan-publik',NULL,NULL),(2,'Hukum dan Regulasi','hukum-dan-regulasi',NULL,NULL),(3,'Pemerintahan Daerah','pemerintahan-daerah',NULL,NULL),(4,'Politik dan Demokrasi','politik-dan-demokrasi',NULL,NULL),(5,'Pelayanan Publik','pelayanan-publik',NULL,NULL),(6,'Keuangan dan Anggaran','keuangan-dan-anggaran',NULL,NULL),(7,'Reformasi Birokrasi','reformasi-birokrasi',NULL,NULL),(8,'Pembangunan dan Infrastruktur','pembangunan-dan-infrastruktur',NULL,NULL),(9,'Keamanan dan Pertahanan','keamanan-dan-pertahanan',NULL,NULL),(10,'Lingkungan dan Energi','lingkungan-dan-energi',NULL,NULL),(11,'Hubungan Internasional','hubungan-internasional',NULL,NULL),(12,'Pendidikan dan Kebudayaan','pendidikan-dan-kebudayaan',NULL,NULL),(13,'Kesejahteraan Sosial','kesejahteraan-sosial',NULL,NULL),(14,'Tenaga Kerja dan Ketenagakerjaan','tenaga-kerja-dan-ketenagakerjaan',NULL,NULL),(15,'Kesehatan Masyarakat','kesehatan-masyarakat',NULL,NULL);
/*!40000 ALTER TABLE `kategoris` ENABLE KEYS */;

--
-- Table structure for table `log_imports`
--

DROP TABLE IF EXISTS `log_imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_imports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama_tabel` varchar(100) NOT NULL,
  `desa_id` char(13) DEFAULT NULL,
  `bulan` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_imports`
--

/*!40000 ALTER TABLE `log_imports` DISABLE KEYS */;
INSERT INTO `log_imports` VALUES (1,'das_tingkat_pendidikan','53.06.13.2001',4,2025,'2025-04-23 08:02:16','2025-04-23 08:02:16');
/*!40000 ALTER TABLE `log_imports` ENABLE KEYS */;

--
-- Table structure for table `log_penduduk`
--

DROP TABLE IF EXISTS `log_penduduk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_penduduk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `nik` char(16) NOT NULL,
  `id_kk` int(11) DEFAULT NULL,
  `kk_level` tinyint(4) DEFAULT NULL,
  `id_rtm` int(11) DEFAULT NULL,
  `rtm_level` int(11) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama_id` int(11) NOT NULL,
  `pendidikan_kk_id` int(11) DEFAULT NULL,
  `pendidikan_id` int(11) DEFAULT NULL,
  `pendidikan_sedang_id` int(11) DEFAULT NULL,
  `pekerjaan_id` int(11) DEFAULT NULL,
  `status_kawin` tinyint(4) DEFAULT NULL,
  `warga_negara_id` int(11) DEFAULT NULL,
  `dokumen_pasport` varchar(45) DEFAULT NULL,
  `dokumen_kitas` varchar(45) DEFAULT NULL,
  `ayah_nik` varchar(16) DEFAULT NULL,
  `ibu_nik` varchar(16) DEFAULT NULL,
  `nama_ayah` varchar(100) DEFAULT NULL,
  `nama_ibu` varchar(100) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `golongan_darah_id` int(11) DEFAULT NULL,
  `id_cluster` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `alamat_sebelumnya` varchar(255) DEFAULT NULL,
  `alamat_sekarang` varchar(255) DEFAULT NULL,
  `status_dasar` tinyint(4) NOT NULL,
  `hamil` int(11) DEFAULT NULL,
  `cacat_id` int(11) DEFAULT NULL,
  `sakit_menahun_id` int(11) DEFAULT NULL,
  `akta_lahir` varchar(40) DEFAULT NULL,
  `akta_perkawinan` varchar(40) DEFAULT NULL,
  `tanggal_perkawinan` date DEFAULT NULL,
  `akta_perceraian` varchar(40) DEFAULT NULL,
  `tanggal_perceraian` date DEFAULT NULL,
  `cara_kb_id` tinyint(4) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `tanggal_akhir_pasport` date DEFAULT NULL,
  `no_kk` varchar(30) DEFAULT NULL,
  `no_kk_sebelumnya` varchar(30) DEFAULT NULL,
  `desa_id` char(10) DEFAULT NULL,
  `kecamatan_id` char(7) DEFAULT NULL,
  `kabupaten_id` char(4) DEFAULT NULL,
  `provinsi_id` char(2) DEFAULT NULL,
  `tahun` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `log_penduduk_nik_unique` (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_penduduk`
--

/*!40000 ALTER TABLE `log_penduduk` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_penduduk` ENABLE KEYS */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_07_02_230147_migration_cartalyst_sentinel',1),(2,'2017_10_31_165346_create_menus_tables',1),(3,'2017_10_31_165347_create_nav_menus_table',1),(4,'2018_01_19_231052_create_prosedur_table',1),(5,'2018_01_21_194204_create_faq_table',1),(6,'2018_01_22_113639_create_events_table',1),(7,'2018_01_24_183803_create_regulasi_table',1),(8,'2018_01_27_084715_create_kecamatan_table',1),(9,'2018_01_27_084807_create_provinsi_table',1),(10,'2018_01_27_084828_create_kabupaten_table',1),(11,'2018_01_27_091024_create_desa_table',1),(12,'2018_01_27_143943_create_profils_table',1),(13,'2018_02_01_083021_create_data_umum_table',1),(14,'2018_02_07_041730_create_penduduk_table',1),(15,'2018_02_07_044425_create_pekerjaan_table',1),(16,'2018_02_07_061956_create_agama_table',1),(17,'2018_02_07_081809_create_kawin_table',1),(18,'2018_02_07_120658_create_hubungan_keluarga_table',1),(19,'2018_02_07_132847_create_pendidikan_kk_table',1),(20,'2018_02_07_132956_create_pendidikan_table',1),(21,'2018_02_07_141701_create_warganegara_table',1),(22,'2018_02_07_161046_create_golongan_darah_table',1),(23,'2018_02_07_161652_create_cacat_table',1),(24,'2018_02_07_162450_create_sakit_menahun_table',1),(25,'2018_02_07_163236_create_cara_kb_table',1),(26,'2018_02_11_173433_create_proses_ektp_table',1),(27,'2018_02_13_043336_create_proses_kk_table',1),(28,'2018_02_13_065923_create_proses_akta_lahir_table',1),(29,'2018_02_13_111006_create_proses_domisili_table',1),(30,'2018_02_27_030954_create_keluarga_table',1),(31,'2018_02_27_033644_create_wil_clusterdesa_table',1),(32,'2018_02_28_094700_create_umur_table',1),(33,'2018_04_11_164146_create_komplain_table',1),(34,'2018_04_19_131534_create_kategori_komplain_table',1),(35,'2018_04_25_183835_create_tipe_regulasi_table',1),(36,'2018_04_28_053520_create_counter_page_table',1),(37,'2018_04_28_053738_create_counter_visitor_table',1),(38,'2018_04_28_053847_create_counter_page_visitor',1),(39,'2018_05_03_101258_create_form_dokumen_table',1),(40,'2018_05_04_232147_create_data_desa_table',1),(41,'2018_05_10_054617_create_akib_table',1),(42,'2018_05_10_125321_create_imunisasi_table',1),(43,'2018_05_10_192220_create_penyakit_table',1),(44,'2018_05_11_045417_create_epidemi_penyakit_table',1),(45,'2018_05_11_062834_create_toilet_sanitasi_table',1),(46,'2018_05_15_175503_create_tingkat_pendidikan_table',1),(47,'2018_05_15_180306_create_failitas_paud_table',1),(48,'2018_05_22_154137_create_jawab_komplain_table',1),(49,'2018_05_23_002258_create_coa_type_table',1),(50,'2018_05_23_002514_create_sub_coa_table',1),(51,'2018_05_23_002657_create_sub_sub_coa_table',1),(52,'2018_05_23_002747_create_coa_table',1),(53,'2018_05_29_145439_create_putus_sekolah_table',1),(54,'2018_05_31_094821_create_potensi_table',1),(55,'2018_06_01_021440_create_anggaran_realisasi_table',1),(56,'2018_06_01_221500_create_anggaran_desa_table',1),(57,'2018_06_04_042538_create_log_penduduk_table',1),(58,'2018_06_05_013340_create_program_table',1),(59,'2018_06_05_014323_create_peserta_program_table',1),(60,'2018_07_07_143736_create_tipe_potensis_table',1),(61,'2018_07_12_020005_create_log_imports_table',1),(62,'2019_05_29_214911_add_fields_penduduk_table',1),(63,'2019_07_19_220717_create_wilayahs_table',1),(64,'2019_07_19_223025_alter_table_profile',1),(65,'2019_07_19_223731_alter_table_data_umum',1),(66,'2019_07_19_224320_alter_table_data_desa',1),(67,'2019_07_19_225118_alter_table_penduduk',1),(68,'2019_07_19_225315_alter_table_keluarga',1),(69,'2019_07_19_233413_alter_table_aki_akb',1),(70,'2019_07_19_234452_alter_table_imunisasi',1),(71,'2019_07_19_234613_alter_table_epidemi_penyakit',1),(72,'2019_07_19_234748_alter_table_toilet_sanitasi',1),(73,'2019_07_19_235703_alter_table_tingkat_pendidikan',1),(74,'2019_07_20_001401_alter_table_putus_sekolah',1),(75,'2019_07_20_001605_alter_table_fasilitas_paud',1),(76,'2019_07_20_002322_alter_table_anggaran_realisasi',1),(77,'2020_11_21_185545_drop_tabel_ref_desa',1),(78,'2020_11_21_185837_drop_tabel_ref_kecamatan',1),(79,'2020_11_21_185950_drop_tabel_ref_kabupaten',1),(80,'2020_11_21_190021_drop_tabel_ref_provinsi',1),(81,'2020_11_28_205956_create_jobs_table',1),(82,'2020_11_28_210237_create_failed_jobs_table',1),(83,'2020_11_29_183342_alter_table_profil',1),(84,'2020_12_08_101049_alter_table_log_impor',1),(85,'2020_12_14_155941_alter_table_das_penduduk',1),(86,'2020_12_30_141825_alter__table_das_profil',1),(87,'2020_12_30_205207_create_slides_table',1),(88,'2021_01_02_055931_dropcolomn_data_umum_table',1),(89,'2021_06_28_142557_create_setting_aplikasis_table',1),(90,'2021_07_09_014633_create_apbdes_table',1),(91,'2021_07_12_190018_alter_das_regulasi_table',1),(92,'2021_07_13_164303_drop_layanan_kecamatan_table',1),(93,'2021_07_15_214814_add_field_sumber_luas_wilayah',1),(94,'2021_07_19_095319_alter_table_user',1),(95,'2021_08_28_153130_crete_laporan_penduduk_table',1),(96,'2021_09_22_235156_alter_table_das_profil_add_name',1),(97,'2021_09_23_070308_drop_table_ref_wilayah',1),(98,'2021_10_07_130420_add_slug_event',1),(99,'2021_10_12_081718_alter_table_das_data_umum',1),(100,'2021_10_12_083709_alter_table_das_data_desa',1),(101,'2021_10_12_110152_alter_table_das_regulasi',1),(102,'2021_10_13_112449_alter_table_das_keluarga',1),(103,'2021_10_14_075357_alter_table_das_akib',1),(104,'2021_10_14_081042_alter_table_das_imunisasi',1),(105,'2021_10_14_083252_alter_table_das_epidemi_penyakit',1),(106,'2021_10_14_084924_alter_table_das_toilet_sanitasi',1),(107,'2021_10_14_090123_alter_table_das_tingkat_pendidikan',1),(108,'2021_10_14_100339_alter_table_das_putus_sekolah',1),(109,'2021_10_14_101450_alter_table_das_fasilitas_paud',1),(110,'2021_10_14_105228_alter_table_das_anggaran_realisasi',1),(111,'2021_10_15_100729_create_kategoris_table',1),(112,'2021_10_15_100730_create_das_artikel_table',1),(113,'2021_11_17_123148_alter_table_dash_penduduk',1),(114,'2021_11_17_203124_alter_table_artike_change_field_gambar',1),(115,'2021_12_06_071737_alter_table_das_keluarga_remove_fields',1),(116,'2022_01_09_190536_modify_fields_das_tingkat_pendidikan',1),(117,'2022_01_12_004443_alter_dasar_pembentukan_table_das_profil',1),(118,'2022_02_08_000016_tambahkan_data_setting_aplikasi',1),(119,'2022_03_09_134418_create_permission_tables',1),(120,'2022_03_13_103220_add_remember_user',1),(121,'2022_04_12_103357_alter_table_das_faq',1),(122,'2022_04_12_194536_alter_table_das_data_umum_modify_tipologi',1),(123,'2022_04_17_002342_tambah_kolom_desa',1),(124,'2022_04_17_203223_import_log_nullable',1),(125,'2022_04_17_225617_create_table_das_pembangunan',1),(126,'2022_04_18_070823_create_table_das_pembangunan_dokumentasi',1),(127,'2022_04_19_074746_create_role_api',1),(128,'2022_04_20_105732_tambahkan_kolom_programbantuan',1),(129,'2022_04_20_115358_alter_programbantuan',1),(130,'2022_04_20_122309_add_kolom_daspesertabantuan',1),(131,'2022_04_21_224806_data_umum_path',1),(132,'2022_04_22_230021_add_path_desa',1),(133,'2022_04_24_144702_role_kontributor_artikel',1),(134,'2022_04_25_202316_create_table_pesan',1),(135,'2022_04_25_202406_create_table_detail_pesan',1),(136,'2022_05_15_121032_default_sebutan_desa',1),(137,'2022_06_22_205014_add_slug_prosedur',1),(138,'2022_07_14_102805_create_media_sosial_table',1),(139,'2022_07_18_040936_create_suplemen_table',1),(140,'2022_07_18_044041_create_suplemen_terdata_table',1),(141,'2022_08_22_062136_create_sinergi_program_table',1),(142,'2022_11_06_191838_create_ref_jabatan_table',1),(143,'2022_11_09_143029_create_pengurus_table',1),(144,'2022_11_14_131235_add_pengurus_user',1),(145,'2022_11_24_181234_update_id_kartu_program_bantuan',1),(146,'2022_11_26_160652_delete_perangkat_profil',1),(147,'2022_12_15_195013_add_tte_setting',1),(148,'2022_12_16_182906_create_log_surat_table',1),(149,'2023_01_12_151140_change_slug_prosedur',1),(150,'2023_01_17_154739_create_log_tte_table',1),(151,'2023_01_20_153011_change_pengurus_nik_type',1),(152,'2023_02_06_061656_add_back_missing_das_pengurus_columns',1),(153,'2023_02_27_122959_rename_data_umum_tipologi',1),(154,'2023_03_29_224214_delete_duplicate_penduduk',1),(155,'2023_04_18_131637_update_status_keluhan',1),(156,'2023_10_19_154602_maintenance_mode',1),(157,'2024_02_02_131925_add_lat_lng_data_umum',1),(158,'2024_06_03_042202_create_themes',1),(159,'2024_06_25_131925_add_tipologi_data_umum',1),(160,'2024_07_01_101314_create_navigations_table',1),(161,'2024_07_21_024936_delete_socialmedia_tbl_profil',1),(162,'2024_08_18_155051_update_komplain_anonim',1),(163,'2024_08_22_213619_add_type_das_navigation',1),(164,'2024_08_23_222334_create_das_artikel_comment_table',1),(165,'2024_08_26_071006_delete_duplicate_penduduk_by_nik',1),(166,'2024_09_09_105521_create_albums_table',1),(167,'2024_09_09_121409_create_galeris_table',1),(168,'2024_09_10_141546_add_ip_and_device_to_das_artikel_comment__table',1),(169,'2024_09_30_112202_create_artikel_kategoris_table',1),(170,'2024_10_03_113405_add_id_kategori_to_das_artikel_table',1),(171,'2024_10_03_203704_add_field_kategori_id_in_table_artikel',1),(172,'2024_10_04_101813_add_field_type_in_table_nav_menus',1),(173,'2024_10_22_120555_add_menu_dinamis',1),(174,'2024_11_01_161123_remove_foreign_key_kategori',1),(175,'2024_11_20_163753_create_kategori_lembagas_table',1),(176,'2024_11_23_114706_create_lembaga_table',1),(177,'2024_11_23_114718_create_lembaga_anggota_table',1),(178,'2024_11_25_133116_create_penduduk_sex_table',1),(179,'2025_01_16_162721_create_setting_sinkronisasi',1),(180,'2025_03_04_132643_remove_data_publikasi_galeri_table_das_counter_page',1),(181,'2025_03_07_090812_add_mobile_to_users_table',1),(182,'2025_03_07_090812_create_two_factor_auths_table',1),(183,'2025_03_07_091749_create_setting_2fa',1),(184,'2025_03_07_144327_create_setting_capctha',1),(185,'2025_03_18_095947_add_column_detail_penduduk_table_das_komplain',1),(186,'2025_03_27_085103_setting_mapbox',1),(187,'2025_03_28_204738_add_bagan_fields_to_das_pengurus_table',1),(188,'2025_03_28_235514_add_atasan_to_das_pengurus_table',1),(189,'2025_04_02_163116_create_jenis_dokumen_table',1),(190,'2025_04_04_142924_add_multiple_column_to_form_dokumen_table',1),(191,'2025_04_06_121528_update_enum_type_in_table_nav_menus',1),(192,'2025_04_10_223421_add_foreign_constraint_form_dokumen_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;

--
-- Table structure for table `nav_menus`
--

DROP TABLE IF EXISTS `nav_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `nav_menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `url` varchar(191) NOT NULL COMMENT 'bisa berisi link atau url',
  `target` enum('_self','_blank','_top') NOT NULL DEFAULT '_self',
  `type` enum('link','halaman','kategori','modul','dokumen') NOT NULL DEFAULT 'modul',
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `is_show` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Status ditampilkan',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nav_menus`
--

/*!40000 ALTER TABLE `nav_menus` DISABLE KEYS */;
INSERT INTO `nav_menus` VALUES (25,'Beranda','/','_self','modul',NULL,1,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(26,'Publikasi','#','_self','modul',NULL,2,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(27,'Galeri','/publikasi/galeri','_self','modul',26,1,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(28,'Berita Desa','/berita-desa','_self','modul',NULL,3,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(29,'Profil','#','_self','modul',NULL,4,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(30,'Sejarah','/profil/sejarah','_self','modul',29,1,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(31,'Letak Geografis','/profil/letak-geografis','_self','modul',29,2,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(32,'Struktur Pemerintahan','/profil/struktur-pemerintahan','_self','modul',29,3,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(33,'Visi & Misi','/profil/visi-misi','_self','modul',29,4,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(34,'Potensi','#','_self','modul',NULL,5,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(35,'Statistik','#','_self','modul',NULL,6,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(36,'Penduduk','/statistik/kependudukan','_self','modul',35,1,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(37,'Pendidikan','/statistik/pendidikan','_self','modul',35,2,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(38,'Kesehatan','/statistik/kesehatan','_self','modul',35,3,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(39,'Program dan Bantuan','/statistik/program-dan-bantuan','_self','modul',35,4,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(40,'Anggaran dan Realisasi','/statistik/anggaran-dan-realisasi','_self','modul',35,5,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(41,'Anggaran Desa','/statistik/anggaran-desa','_self','modul',35,6,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(42,'Unduhan','/statistik/anggaran-desa','_self','modul',NULL,7,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(43,'Prosedur','/unduhan/prosedur','_self','modul',42,1,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(44,'Regulasi','/unduhan/regulasi','_self','modul',42,2,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(45,'Dokumen','/unduhan/form-dokumen','_self','modul',42,3,1,'2025-04-23 08:25:25','2025-04-23 08:25:25'),(46,'FAQ','/faq','_blank','link',NULL,8,1,'2025-04-23 08:25:25','2025-04-23 08:25:25');
/*!40000 ALTER TABLE `nav_menus` ENABLE KEYS */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(125) NOT NULL,
  `guard_name` varchar(125) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(2,'create','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(3,'edit','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(4,'delete','web','2025-04-23 08:02:10','2025-04-23 08:02:10');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

--
-- Table structure for table `ref_agama`
--

DROP TABLE IF EXISTS `ref_agama`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_agama` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_agama`
--

/*!40000 ALTER TABLE `ref_agama` DISABLE KEYS */;
INSERT INTO `ref_agama` VALUES (1,'ISLAM'),(2,'KRISTEN'),(3,'KATHOLIK'),(4,'HINDU'),(5,'BUDHA'),(6,'KHONGHUCU'),(7,'Lainnya');
/*!40000 ALTER TABLE `ref_agama` ENABLE KEYS */;

--
-- Table structure for table `ref_cacat`
--

DROP TABLE IF EXISTS `ref_cacat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_cacat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_cacat`
--

/*!40000 ALTER TABLE `ref_cacat` DISABLE KEYS */;
INSERT INTO `ref_cacat` VALUES (1,'CACAT FISIK'),(2,'CACAT NETRA/BUTA'),(3,'CACAT RUNGU/WICARA'),(4,'CACAT MENTAL/JIWA'),(5,'CACAT FISIK DAN MENTAL'),(6,'CACAT LAINNYA'),(7,'TIDAK CACAT');
/*!40000 ALTER TABLE `ref_cacat` ENABLE KEYS */;

--
-- Table structure for table `ref_cara_kb`
--

DROP TABLE IF EXISTS `ref_cara_kb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_cara_kb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `sex` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_cara_kb`
--

/*!40000 ALTER TABLE `ref_cara_kb` DISABLE KEYS */;
INSERT INTO `ref_cara_kb` VALUES (1,'Pil',2),(2,'IUD',2),(3,'Suntik',2),(4,'Kondom',1),(5,'Susuk KB',2),(6,'Sterilisasi Wanita',2),(7,'Sterilisasi Pria',1),(99,'Lainnya',3);
/*!40000 ALTER TABLE `ref_cara_kb` ENABLE KEYS */;

--
-- Table structure for table `ref_coa`
--

DROP TABLE IF EXISTS `ref_coa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_coa` (
  `id` char(5) NOT NULL,
  `type_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `sub_sub_id` int(11) NOT NULL,
  `coa_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_coa`
--

/*!40000 ALTER TABLE `ref_coa` DISABLE KEYS */;
INSERT INTO `ref_coa` VALUES ('01',4,1,1,'Bagi Hasil BUMDes'),('90-99',4,1,1,'Lain-lain'),('01',4,1,2,'Pengelolaan Tanah Kas Desa'),('02',4,1,2,'Tambatan Perahu'),('03',4,1,2,'Pasar Desa'),('04',4,1,2,'Tempat Pemandian Umum'),('05',4,1,2,'Jaringan Irigasi Desa'),('06',4,1,2,'Pelelangan Ikan Milik Desa'),('07',4,1,2,'Kios Milik Desa'),('08',4,1,2,'Pemanfaatan Lapangan/Prasarana Olah raga Milik Desa'),('90-99',4,1,2,'Lain-lain'),('01',4,1,3,'Swadaya, partisipasi dan gotong royong'),('90-99',4,1,3,'Lain-lain Swadaya, Partisipasi dan Gotong Royong'),('01',4,1,4,'Hasil Pungutan Desa'),('90-99',4,1,4,'Lain-lain'),('01',4,2,1,'Dana Desa'),('01',4,2,2,'Bagian dari Hasil Pajak dan Retribusi Daerah Kabupaten/kota'),('01',4,2,3,'Alokasi Dana Desa'),('01',4,2,4,'Bantuan Keuangan dari APBD Provinsi'),('90-99',4,2,4,'Lain-lain Bantuan Keuangan dari APBD Provinsi'),('01',4,2,5,'Bantuan Keuangan APBD Kabupaten/Kota'),('90-99',4,2,5,'Lain-lain Bantuan Keuangan dari APBD Kabupaten/Kota'),('01',4,3,1,'Penerimaan dari Hasil Kerjasama antar Desa '),('01',4,3,2,'Penerimaan dari Hasil Kerjasama Desa dengan Pihak Ketiga'),('01',4,3,3,'Penerimaan dari Bantuan Perusahaan yang berlokasi di Desa'),('01',4,3,4,'Hibah dan sumbangan dari Pihak Ketiga'),('01',4,3,5,'Koreksi kesalahan belanja tahun-tahun anggaran sebelumnya yang mengakibatkan penerimaan di kas Desa pada tahun anggaran berjalan'),('01',4,3,6,'Bunga Bank'),('90-99',4,3,9,'Lain-lain pendapatan Desa yang sah'),('01',5,1,1,'Penghasilan Tetap Kepala Desa'),('02',5,1,1,'Tunjangan Kepala Desa'),('90-99',5,1,1,'Penerimaan Lain Kepala Desa yang Sah'),('01',5,1,2,'Penghasilan Tetap Perangkat Desa'),('02',5,1,2,'Tunjangan Perangkat Desa'),('90-99',5,1,2,'Penerimaan Lain Perangkat Desa yang Sah'),('01',5,1,3,'Jaminan Kesehatan Kepala Desa'),('02',5,1,3,'Jaminan Kesehatan Perangkat Desa'),('03',5,1,3,'Jaminan Ketenagakerjaan Kepala Desa'),('04',5,1,3,'Jaminan Ketenagakerjaan Perangkat Desa'),('01',5,1,4,'Tunjangan Kedudukan BPD'),('02',5,1,4,'Tunjangan Kinerja BPD'),('01',5,2,1,'Belanja Perlengkapan Alat Tulis Kantor dan Benda Pos'),('02',5,2,1,'Belanja Perlengkapan Alat-alat Listrik'),('03',5,2,1,'Belanja Perlengkapan Alat-alat Rumah Tangga/Peralatan dan Bahan Kebersihan'),('04',5,2,1,'Belanja Bahan Bakar Minyak/Gas/Isi Ulang Tabung Pemadam Kebakaran'),('05',5,2,1,'Belanja Perlengkapan Cetak/Penggandaan - Belanja Barang Cetak dan Penggandaan'),('06',5,2,1,'Belanja Perlengkapan Barang Konsumsi (Makan/minum) - Belanja Barang Konsumsi'),('07',5,2,1,'Belanja Bahan/Material'),('08',5,2,1,'Belanja Bendera/Umbul-umbul/Spanduk'),('09',5,2,1,'Belanja Pakaian Dinas/Seragam/Atribut'),('10',5,2,1,'Belanja Obat-obatan'),('11',5,2,1,'Belanja Pakan Hewan/Ikan, Obat-obatan Hewan'),('12',5,2,1,'Belanja Pupuk/Obat-obatan Pertanian'),('90-99',5,2,1,'Belanja Barang Perlengkapan Lainnya'),('01',5,2,2,'Belanja Jasa Honorarium Tim yang Melaksanakan Kegiatan'),('02',5,2,2,'Belanja Jasa Honorarium Pembantu Tugas Umum Desa/Operator'),('03',5,2,2,'Belanja Jasa Honorarium/Insentif Pelayanan Desa'),('04',5,2,2,'Belanja Jasa Honorarium Ahli/Profesi/Konsultan/Narasumber'),('05',5,2,2,'Belanja Jasa Honorarium Petugas'),('90-99',5,2,2,'Belanja Jasa Honorarium Lainnya'),('01',5,2,3,'Belanja Perjalanan Dinas Dalam Kabupaten/Kota'),('02',5,2,3,'Belanja Perjalanan Dinas Luar Kabupaten/Kota'),('03',5,2,3,'Belanja Kursus/Pelatihan'),('01',5,2,4,'Belanja Jasa Sewa Bangunan/Gedung/Ruang'),('02',5,2,4,'Belanja Jasa Sewa Peralatan/Perlengkapan'),('03',5,2,4,'Belanja Jasa Sewa Sarana Mobilitas'),('90-99',5,2,4,'Belanja Jasa Sewa Lainnya'),('01',5,2,5,'Belanja Jasa Langganan Listrik'),('02',5,2,5,'Belanja Jasa Langganan Air Bersih'),('03',5,2,5,'Belanja Jasa Langganan Majalah/Surat Kabar'),('04',5,2,5,'Belanja Jasa Langganan Telepon'),('05',5,2,5,'Belanja Jasa Langganan Internet'),('06',5,2,5,'Belanja Jasa Kurir/Pos/Giro'),('07',5,2,5,'Belanja Jasa Perpanjangan Ijin/Pajak'),('90-99',5,2,5,'Belanja Operasional Perkantoran Lainnya'),('01',5,2,6,'Belanja Pemeliharaan Mesin dan Peralatan Berat'),('02',5,2,6,'Belanja Pemeliharaan Kendaraan Bermotor'),('03',5,2,6,'Belanja Pemeliharaan Peralatan'),('04',5,2,6,'Belanja Pemeliharaan Bangunan'),('05',5,2,6,'Belanja Pemeliharaan Jalan'),('06',5,2,6,'Belanja Pemeliharaan Jembatan'),('07',5,2,6,'Belanja Pemeliharaan Irigasi/Saluran Sungai/Embung/Air Bersih, jaringan Air Limbah, Persampahan, dll)'),('08',5,2,6,'Belanja Pemeliharaan Jaringan dan Instalasi (Listrik, Telepon, Internet, Komunikasi, dll)'),('90-99',5,2,6,'Belanja Pemeliharaan Lainnya'),('01',5,2,7,'Belanja Bahan Perlengkapan yang Diserahkan ke masyarakat'),('02',5,2,7,'Belanja Bantuan Mesin/Kendaraaan bermotor/Peralatan yang diserahkan ke masyarakat'),('03',5,2,7,'Belanja Bantuan Bangunan yang diserahkan ke masyarakat'),('04',5,2,7,'Belanja Beasiswa Berprestasi/Masyarakat Miskin'),('05',5,2,7,'Belanja Bantuan Bibit Tanaman/Hewan/Ikan'),('90-99',5,2,7,'Belanja Barang dan Jasa yang Diserahkan kepada Masyarakat Lainnya'),('01',5,3,1,'Belanja Modal Pembebasan/Pembelian Tanah'),('02',5,3,1,'Belanja Modal Pembayaran Honorarium Tim Tanah'),('03',5,3,1,'Belanja Modal Pengukuran dan Pembuatan Sertifikat Tanah'),('04',5,3,1,'Belanja Modal Pengurukan dan Pematangan Tanah'),('05',5,3,1,'Belanja Modal Perjalanan Pengadaan Tanah'),('90-99',5,3,1,'Belanja Modal Pengadaan Tanah Lainnya'),('01',5,3,2,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,2,'Belanja Modal Peralatan Elektronik dan Alat Studio'),('03',5,3,2,'Belanja Modal Peralatan Komputer'),('04',5,3,2,'Belanja Modal Peralatan Mebeulair dan Aksesori Ruangan'),('05',5,3,2,'Belanja Modal Peralatan Dapur'),('06',5,3,2,'Belanja Modal Peralatan Alat Ukur/Rambu-rambu'),('07',5,3,2,'Belanja Modal Peralatan Rambu-rambu/Patok Tanah'),('08',5,3,2,'Belanja Modal Peralatan khusus Kesehatan'),('09',5,3,2,'Belanja Modal Peralatan khusus Pertanian/Perikanan/Peternakan'),('10',5,3,2,'Belanja Modal Mesin'),('11',5,3,2,'Belanja Modal Pengadaan Alat-Alat Berat'),('90-99',5,3,2,'Belanja Modal Peralatan, Mesin, dan Alat Berat Lainnya'),('01',5,3,3,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,3,'Belanja Modal Kendaraan Darat Bermotor'),('03',5,3,3,'Belanja Modal Angkutan Darat Tidak Bermotor'),('04',5,3,3,'Belanja Modal Kendaraan Air Bermotor'),('05',5,3,3,'Belanja Modal Angkutan Air Tidak Bermotor'),('90-99',5,3,3,'Belanja Modal Kendaraan Lainnya'),('',5,0,0,''),('1',5,3,4,'Belanja Modal Gedung dan Bangunan'),('',5,0,0,''),('01',5,3,4,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,4,'Belanja Modal Upah Tenaga Kerja'),('03',5,3,4,'Belanja Modal Bahan Baku '),('04',5,3,4,'Belanja Modal Sewa Peralatan  '),('01',5,3,5,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,5,'Belanja Modal Upah Tenaga Kerja'),('03',5,3,5,'Belanja Modal Bahan Baku '),('04',5,3,5,'Belanja Modal Sewa Peralatan  '),('01',5,3,6,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,6,'Belanja Modal Upah Tenaga Kerja'),('03',5,3,6,'Belanja Modal Bahan Baku '),('04',5,3,6,'Belanja Modal Sewa Peralatan  '),('01',5,3,7,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,7,'Belanja Modal Upah Tenaga Kerja'),('03',5,3,7,'Belanja Modal Bahan Baku '),('04',5,3,7,'Belanja Modal Sewa Peralatan  '),('01',5,3,8,'Belanja Modal Honor Tim yang Melaksanakan Kegiatan'),('02',5,3,8,'Belanja Modal Upah Tenaga Kerja'),('03',5,3,8,'Belanja Modal Bahan Baku '),('04',5,3,8,'Belanja Modal Sewa Peralatan  '),('01',5,3,9,'Belanja Modal khusus Pendidikan dan Perpustakaan'),('02',5,3,9,'Belanja Modal khusus Olahraga'),('03',5,3,9,'Belanja Modal khusus Kesenian/Kebudayaan/keagamaan'),('04',5,3,9,'Belanja Modal Tumbuhan/Tanaman'),('05',5,3,9,'Belanja Modal Hewan'),('90-99',5,3,9,'Belanja Modal Lainnya'),('01',5,4,1,'Belanja Tak Terduga'),('01',6,1,1,'SILPA Tahun Sebelumnya'),('01',6,1,2,'Pencairan Dana Cadangan'),('01',6,1,3,'Hasil Penjualan Kekayaan Desa yang Dipisahkan'),('90-99',6,1,9,'Penerimaan Pembiayaan Lainnya'),('01',6,2,1,'Pembentukan Dana Cadangan'),('01',6,2,2,'Penyertaan Modal Desa'),('90-99',6,2,9,'Pengeluaran Pembiayaan lainnya');
/*!40000 ALTER TABLE `ref_coa` ENABLE KEYS */;

--
-- Table structure for table `ref_coa_type`
--

DROP TABLE IF EXISTS `ref_coa_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_coa_type` (
  `id` int(11) NOT NULL,
  `type_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_coa_type`
--

/*!40000 ALTER TABLE `ref_coa_type` DISABLE KEYS */;
INSERT INTO `ref_coa_type` VALUES (4,'PENDAPATAN'),(5,'BELANJA'),(6,'PEMBIAYAAN');
/*!40000 ALTER TABLE `ref_coa_type` ENABLE KEYS */;

--
-- Table structure for table `ref_golongan_darah`
--

DROP TABLE IF EXISTS `ref_golongan_darah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_golongan_darah` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_golongan_darah`
--

/*!40000 ALTER TABLE `ref_golongan_darah` DISABLE KEYS */;
INSERT INTO `ref_golongan_darah` VALUES (1,'A'),(2,'B'),(3,'AB'),(4,'O'),(13,'TIDAK TAHU');
/*!40000 ALTER TABLE `ref_golongan_darah` ENABLE KEYS */;

--
-- Table structure for table `ref_hubungan_keluarga`
--

DROP TABLE IF EXISTS `ref_hubungan_keluarga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_hubungan_keluarga` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_hubungan_keluarga`
--

/*!40000 ALTER TABLE `ref_hubungan_keluarga` DISABLE KEYS */;
INSERT INTO `ref_hubungan_keluarga` VALUES (1,'KEPALA KELUARGA'),(2,'SUAMI'),(3,'ISTRI'),(4,'ANAK'),(5,'MENANTU'),(6,'CUCU'),(7,'ORANGTUA'),(8,'MERTUA'),(9,'FAMILI LAIN'),(10,'PEMBANTU'),(11,'LAINNYA');
/*!40000 ALTER TABLE `ref_hubungan_keluarga` ENABLE KEYS */;

--
-- Table structure for table `ref_jabatan`
--

DROP TABLE IF EXISTS `ref_jabatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_jabatan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `tupoksi` text DEFAULT NULL,
  `jenis` int(11) NOT NULL DEFAULT 3,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_jabatan`
--

/*!40000 ALTER TABLE `ref_jabatan` DISABLE KEYS */;
INSERT INTO `ref_jabatan` VALUES (1,'Camat',NULL,1,NULL,NULL),(2,'Sekretaris',NULL,2,NULL,NULL);
/*!40000 ALTER TABLE `ref_jabatan` ENABLE KEYS */;

--
-- Table structure for table `ref_kawin`
--

DROP TABLE IF EXISTS `ref_kawin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_kawin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_kawin`
--

/*!40000 ALTER TABLE `ref_kawin` DISABLE KEYS */;
INSERT INTO `ref_kawin` VALUES (1,'BELUM KAWIN'),(2,'KAWIN'),(3,'CERAI HIDUP'),(4,'CERAI MATI');
/*!40000 ALTER TABLE `ref_kawin` ENABLE KEYS */;

--
-- Table structure for table `ref_pekerjaan`
--

DROP TABLE IF EXISTS `ref_pekerjaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_pekerjaan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_pekerjaan`
--

/*!40000 ALTER TABLE `ref_pekerjaan` DISABLE KEYS */;
INSERT INTO `ref_pekerjaan` VALUES (1,'BELUM/TIDAK BEKERJA'),(2,'MENGURUS RUMAH TANGGA'),(3,'PELAJAR/MAHASISWA'),(4,'PENSIUNAN'),(5,'PEGAWAI NEGERI SIPIL (PNS)'),(6,'TENTARA NASIONAL INDONESIA (TNI)'),(7,'KEPOLISIAN RI (POLRI)'),(8,'PERDAGANGAN'),(9,'PETANI/PERKEBUNAN'),(10,'PETERNAK'),(11,'NELAYAN/PERIKANAN'),(12,'INDUSTRI'),(13,'KONSTRUKSI'),(14,'TRANSPORTASI'),(15,'KARYAWAN SWASTA'),(16,'KARYAWAN BUMN'),(17,'KARYAWAN BUMD'),(18,'KARYAWAN HONORER'),(19,'BURUH HARIAN LEPAS'),(20,'BURUH TANI/PERKEBUNAN'),(21,'BURUH NELAYAN/PERIKANAN'),(22,'BURUH PETERNAKAN'),(23,'PEMBANTU RUMAH TANGGA'),(24,'TUKANG CUKUR'),(25,'TUKANG LISTRIK'),(26,'TUKANG BATU'),(27,'TUKANG KAYU'),(28,'TUKANG SOL SEPATU'),(29,'TUKANG LAS/PANDAI BESI'),(30,'TUKANG JAHIT'),(31,'TUKANG GIGI'),(32,'PENATA RIAS'),(33,'PENATA BUSANA'),(34,'PENATA RAMBUT'),(35,'MEKANIK'),(36,'SENIMAN'),(37,'TABIB'),(38,'PARAJI'),(39,'PERANCANG BUSANA'),(40,'PENTERJEMAH'),(41,'IMAM MASJID'),(42,'PENDETA'),(43,'PASTOR'),(44,'WARTAWAN'),(45,'USTADZ/MUBALIGH'),(46,'JURU MASAK'),(47,'PROMOTOR ACARA'),(48,'ANGGOTA DPR-RI'),(49,'ANGGOTA DPD'),(50,'ANGGOTA BPK'),(51,'PRESIDEN'),(52,'WAKIL PRESIDEN'),(53,'ANGGOTA MAHKAMAH KONSTITUSI'),(54,'ANGGOTA KABINET KEMENTERIAN'),(55,'DUTA BESAR'),(56,'GUBERNUR'),(57,'WAKIL GUBERNUR'),(58,'BUPATI'),(59,'WAKIL BUPATI'),(60,'WALIKOTA'),(61,'WAKIL WALIKOTA'),(62,'ANGGOTA DPRD PROVINSI'),(63,'ANGGOTA DPRD KABUPATEN/KOTA'),(64,'DOSEN'),(65,'GURU'),(66,'PILOT'),(67,'PENGACARA'),(68,'NOTARIS'),(69,'ARSITEK'),(70,'AKUNTAN'),(71,'KONSULTAN'),(72,'DOKTER'),(73,'BIDAN'),(74,'PERAWAT'),(75,'APOTEKER'),(76,'PSIKIATER/PSIKOLOG'),(77,'PENYIAR TELEVISI'),(78,'PENYIAR RADIO'),(79,'PELAUT'),(80,'PENELITI'),(81,'SOPIR'),(82,'PIALANG'),(83,'PARANORMAL'),(84,'PEDAGANG'),(85,'PERANGKAT DESA'),(86,'KEPALA DESA'),(87,'BIARAWATI'),(88,'WIRASWASTA'),(89,'LAINNYA');
/*!40000 ALTER TABLE `ref_pekerjaan` ENABLE KEYS */;

--
-- Table structure for table `ref_pendidikan`
--

DROP TABLE IF EXISTS `ref_pendidikan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_pendidikan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_pendidikan`
--

/*!40000 ALTER TABLE `ref_pendidikan` DISABLE KEYS */;
INSERT INTO `ref_pendidikan` VALUES (1,'BELUM MASUK TK/KELOMPOK BERMAIN'),(2,'SEDANG TK/KELOMPOK BERMAIN'),(3,'TIDAK PERNAH SEKOLAH'),(4,'SEDANG SD/SEDERAJAT'),(5,'TIDAK TAMAT SD/SEDERAJAT'),(6,'SEDANG SLTP/SEDERAJAT'),(7,'SEDANG SLTA/SEDERAJAT'),(8,'SEDANG  D-1/SEDERAJAT'),(9,'SEDANG D-2/SEDERAJAT'),(10,'SEDANG D-3/SEDERAJAT'),(11,'SEDANG  S-1/SEDERAJAT'),(12,'SEDANG S-2/SEDERAJAT'),(13,'SEDANG S-3/SEDERAJAT'),(14,'SEDANG SLB A/SEDERAJAT'),(15,'SEDANG SLB B/SEDERAJAT'),(16,'SEDANG SLB C/SEDERAJAT'),(17,'TIDAK DAPAT MEMBACA DAN MENULIS HURUF LATIN/ARAB'),(18,'TIDAK SEDANG SEKOLAH');
/*!40000 ALTER TABLE `ref_pendidikan` ENABLE KEYS */;

--
-- Table structure for table `ref_pendidikan_kk`
--

DROP TABLE IF EXISTS `ref_pendidikan_kk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_pendidikan_kk` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_pendidikan_kk`
--

/*!40000 ALTER TABLE `ref_pendidikan_kk` DISABLE KEYS */;
INSERT INTO `ref_pendidikan_kk` VALUES (1,'TIDAK / BELUM SEKOLAH'),(2,'BELUM TAMAT SD/SEDERAJAT'),(3,'TAMAT SD / SEDERAJAT'),(4,'SLTP/SEDERAJAT'),(5,'SLTA / SEDERAJAT'),(6,'DIPLOMA I / II'),(7,'AKADEMI/ DIPLOMA III/S. MUDA'),(8,'DIPLOMA IV/ STRATA I'),(9,'STRATA II'),(10,'STRATA III');
/*!40000 ALTER TABLE `ref_pendidikan_kk` ENABLE KEYS */;

--
-- Table structure for table `ref_penyakit`
--

DROP TABLE IF EXISTS `ref_penyakit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_penyakit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(200) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_penyakit`
--

/*!40000 ALTER TABLE `ref_penyakit` DISABLE KEYS */;
INSERT INTO `ref_penyakit` VALUES (1,'Demam Berdarah','2025-04-23 08:02:11','2025-04-23 08:02:11'),(2,'Kolera','2025-04-23 08:02:11','2025-04-23 08:02:11'),(3,'Malaria','2025-04-23 08:02:11','2025-04-23 08:02:11'),(4,'Influensa','2025-04-23 08:02:11','2025-04-23 08:02:11');
/*!40000 ALTER TABLE `ref_penyakit` ENABLE KEYS */;

--
-- Table structure for table `ref_sakit_menahun`
--

DROP TABLE IF EXISTS `ref_sakit_menahun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_sakit_menahun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_sakit_menahun`
--

/*!40000 ALTER TABLE `ref_sakit_menahun` DISABLE KEYS */;
INSERT INTO `ref_sakit_menahun` VALUES (1,'JANTUNG'),(2,'LEVER'),(3,'PARU-PARU'),(4,'KANKER'),(5,'STROKE'),(6,'DIABETES MELITUS'),(7,'GINJAL'),(8,'MALARIA'),(9,'LEPRA/KUSTA'),(10,'HIV/AIDS'),(11,'GILA/STRESS'),(12,'TBC'),(13,'ASTHMA'),(14,'TIDAK ADA/TIDAK SAKIT');
/*!40000 ALTER TABLE `ref_sakit_menahun` ENABLE KEYS */;

--
-- Table structure for table `ref_sub_coa`
--

DROP TABLE IF EXISTS `ref_sub_coa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_sub_coa` (
  `id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `sub_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_sub_coa`
--

/*!40000 ALTER TABLE `ref_sub_coa` DISABLE KEYS */;
INSERT INTO `ref_sub_coa` VALUES (1,4,'Pendapatan Asli Desa\n'),(2,4,'Transfer'),(3,4,'Pendapatan Lain-lain'),(1,5,'Belanja Pegawai'),(2,5,'Belanja Barang dan Jasa'),(3,5,'Belanja Modal'),(4,5,'Belanja Tak Terduga'),(1,6,'Penerimaan Pembiayaan'),(2,6,'Pengeluaran Pembiayaan');
/*!40000 ALTER TABLE `ref_sub_coa` ENABLE KEYS */;

--
-- Table structure for table `ref_sub_sub_coa`
--

DROP TABLE IF EXISTS `ref_sub_sub_coa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_sub_sub_coa` (
  `id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `sub_sub_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_sub_sub_coa`
--

/*!40000 ALTER TABLE `ref_sub_sub_coa` DISABLE KEYS */;
INSERT INTO `ref_sub_sub_coa` VALUES (1,4,1,'Hasil Usaha'),(2,4,1,'Hasil Aset'),(3,4,1,'Swadaya'),(4,4,1,'Lain-lain Pendapatan Asli Desa'),(1,4,2,'Dana Desa'),(2,4,2,'Bagian dari Hasil Pajak dan Retribusi Daerah Kabupaten/kota'),(3,4,2,'Alokasi Dana Desa'),(4,4,2,'Bantuan Keuangan Provinsi'),(5,4,2,'Bantuan Keuangan APBD Kabupaten/Kota'),(1,4,3,'Penerimaan dari Hasil Kerjasama antar Desa '),(2,4,3,'Penerimaan dari Hasil Kerjasama Desa dengan Pihak Ketiga'),(3,4,3,'Penerimaan dari Bantuan Perusahaan yang berlokasi di Desa'),(4,4,3,'Hibah dan sumbangan dari Pihak Ketiga'),(5,4,3,'Koreksi kesalahan belanja tahun-tahun anggaran sebelumnya yang mengakibatkan penerimaan di kas Desa pada tahun anggaran berjalan'),(6,4,3,'Bunga Bank'),(9,4,3,'Lain-lain pendapatan Desa yang sah'),(1,5,1,'Penghasilan Tetap dan Tunjangan Kepala Desa'),(2,5,1,'Penghasilan Tetap dan Tunjangan Perangkat Desa'),(3,5,1,'Jaminan Sosial Kepala Desa dan Perangkat Desa'),(4,5,1,'Tunjangan BPD'),(2,5,2,'Belanja Jasa Honorarium'),(3,5,2,'Belanja Perjalanan Dinas'),(4,5,2,'Belanja Jasa Sewa'),(5,5,2,'Belanja Operasional Perkantoran'),(6,5,2,'Belanja Pemeliharaan'),(7,5,2,'Belanja Barang dan Jasa yang Diserahkan kepada Masyarakat'),(1,5,3,'Belanja Modal Pengadaan Tanah'),(2,5,3,'Belanja Modal Peralatan, Mesin, dan Alat Berat'),(3,5,3,'Belanja Modal Kendaraan '),(4,5,3,'Belanja Modal Gedung, Bangunan dan Taman'),(5,5,3,'Belanja Modal Jalan/Prasarana Jalan'),(6,5,3,'Belanja Modal Jembatan'),(7,5,3,'Belanja Modal Irigasi/Embung/Air Sungai/Drainase/Air Limbah/Persampahan'),(8,5,3,'Belanja Modal Jaringan/Instalasi'),(9,5,3,'Belanja Modal lainnya'),(1,5,4,'Belanja Tak Terduga'),(1,6,1,'SILPA Tahun Sebelumya'),(2,6,1,'Pencairan Dana Cadangan'),(3,6,1,'Hasil Penjualan Kekayaan Desa yang Dipisahkan'),(9,6,1,'Penerimaan Pembiayaan Lainnya'),(1,6,2,'Pembentukan Dana Cadangan'),(2,6,2,'Penyertaan Modal Desa'),(9,6,2,'Pengeluaran Pembiayaan lainnya');
/*!40000 ALTER TABLE `ref_sub_sub_coa` ENABLE KEYS */;

--
-- Table structure for table `ref_umur`
--

DROP TABLE IF EXISTS `ref_umur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_umur` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `dari` int(11) NOT NULL,
  `sampai` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_umur`
--

/*!40000 ALTER TABLE `ref_umur` DISABLE KEYS */;
INSERT INTO `ref_umur` VALUES (1,'BAYI',0,5,1),(2,'BALITA',1,5,2),(3,'ANAK-ANAK',6,14,1),(4,'REMAJA',15,24,1),(5,'DEWASA',25,44,1),(6,'TUA',45,74,1),(7,'LANSIA',75,130,1);
/*!40000 ALTER TABLE `ref_umur` ENABLE KEYS */;

--
-- Table structure for table `ref_warganegara`
--

DROP TABLE IF EXISTS `ref_warganegara`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ref_warganegara` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ref_warganegara`
--

/*!40000 ALTER TABLE `ref_warganegara` DISABLE KEYS */;
INSERT INTO `ref_warganegara` VALUES (1,'WNI'),(2,'WNA'),(3,'DUA KEWARGANEGARAAN');
/*!40000 ALTER TABLE `ref_warganegara` ENABLE KEYS */;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(2,1),(2,2),(2,3),(2,4),(2,5),(2,6),(2,7),(3,1),(3,2),(3,3),(3,4),(3,5),(3,6),(3,7),(4,1),(4,2),(4,3),(4,4),(4,5),(4,6),(4,7);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(125) NOT NULL,
  `guard_name` varchar(125) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super-admin','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(2,'admin-desa','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(3,'admin-kecamatan','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(4,'admin-puskesmas','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(5,'admin-pendidikan','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(6,'admin-komplain','web','2025-04-23 08:02:10','2025-04-23 08:02:10'),(7,'administrator-website','web','2025-04-23 08:02:11','2025-04-23 08:02:11');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

--
-- Table structure for table `slides`
--

DROP TABLE IF EXISTS `slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `slides` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gambar` longtext NOT NULL,
  `judul` varchar(191) DEFAULT NULL,
  `deskripsi` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slides`
--

/*!40000 ALTER TABLE `slides` DISABLE KEYS */;
INSERT INTO `slides` VALUES (1,'https://github.com/OpenSID/OpenDK/assets/14155050/6e15ddc5-cf52-490b-b997-5e8b57f1e446','Pantai Garassikang','Lokasi: Bulu Jaya, Kecamatan Bangkala Barat, Kabupaten Jeneponto, Sulawesi Selatan','2025-04-23 08:03:26','2025-04-23 08:03:26'),(2,'https://github.com/OpenSID/OpenDK/assets/14155050/b9a3ba56-8916-4820-ac50-8961a40a279e','Batu Siping','Lokasi: Karampuang, Desa Garassikang, Kecamatan Bangkala Barat, Kabupaten Jeneponto, Sulawesi Selatan','2025-04-23 08:03:26','2025-04-23 08:03:26'),(3,'https://github.com/OpenSID/OpenDK/assets/14155050/83fcdfde-07eb-4d58-a57f-689b76bcbaa3','Bukit Sinalu Bulu Jaya','Lokasi: Bulu Jaya, Kecamatan Bangkala Barat, Kabupaten Jeneponto, Sulawesi Selatan','2025-04-23 08:03:26','2025-04-23 08:03:26'),(4,'https://github.com/OpenSID/OpenDK/assets/14155050/2eac1709-fa16-4f14-9bde-9853df9d2534','Pantai Tamarunang','Lokasi: Tamarunang, Pabiringa, Kecamatan Binamu, Kabupaten Jeneponto, Sulawesi Selatan','2025-04-23 08:03:26','2025-04-23 08:03:26');
/*!40000 ALTER TABLE `slides` ENABLE KEYS */;

--
-- Table structure for table `throttle`
--

DROP TABLE IF EXISTS `throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(191) NOT NULL,
  `ip` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `throttle`
--

/*!40000 ALTER TABLE `throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `throttle` ENABLE KEYS */;

--
-- Table structure for table `two_factor_auths`
--

DROP TABLE IF EXISTS `two_factor_auths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_auths` (
  `id` varchar(191) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  KEY `two_factor_auths_user_id_foreign` (`user_id`),
  CONSTRAINT `two_factor_auths_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_auths`
--

/*!40000 ALTER TABLE `two_factor_auths` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_auths` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pengurus_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_mobile_unique` (`mobile`),
  KEY `users_pengurus_id_foreign` (`pengurus_id`),
  CONSTRAINT `users_pengurus_id_foreign` FOREIGN KEY (`pengurus_id`) REFERENCES `das_pengurus` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'admin@mail.com',NULL,'$2y$10$UPG0IUTzOwFN20G9aLMhqewdz7B7kibIodz33pO1jPxP6iUy8Ab3u',NULL,NULL,NULL,'Administrator',NULL,NULL,'Jakarta',NULL,NULL,'Male',1,'2025-04-23 08:02:01','2025-04-23 08:02:01',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Dumping routines for database 'opendk_demo'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-23  8:35:26
